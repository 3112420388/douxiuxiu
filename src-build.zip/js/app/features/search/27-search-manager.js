/* v3 semantic split: class from js/app/08-settings-search-circle-page.js | keep script order */
        class SearchManager {
            constructor() {
                this.HISTORY_KEY = 'dxx_search_history';
                this.history = []; // 初始为空，异步加载
                this.currentTab = 'local-video';
                this.keyword = '';
                this.inputEl = document.getElementById('global-search-input');

                this.debounceTimer = null;
                this.currentLocalResults = [];
                this.currentOnlineResults = [];
                this.bannerSwiper = null;
                this.localScopeWorks = null;
                this.localScopeName = '';
                this.defaultSuggestTags = ['美女', '风景', '情感', '4K', '游戏'];

                // 初始化加载历史
                this.initHistory();

                if (this.inputEl) {
                    this.inputEl.addEventListener('keyup', (e) => {
                        if (e.key === 'Enter') this.doSearch();
                    });
                    this.inputEl.addEventListener('input', (e) => {
                        this.onInput(e.target.value);
                    });
                }
            }

            async initHistory() {
                this.history = await StorageService.get(this.HISTORY_KEY, []);
            }

            setLocalScope(works, name) {
                this.localScopeWorks = Array.isArray(works) ? works : null;
                this.localScopeName = name || '';
                if (this.inputEl) {
                    this.inputEl.placeholder = this.localScopeWorks
                        ? `搜索 @${this.localScopeName || '该博主'} 的作品...`
                        : '本地 / 联网搜索...';
                }
                this.updateScopeTabs();
                this.updateScopeDefaultView();
            }

            clearLocalScope() {
                this.setLocalScope(null, '');
            }

            updateScopeTabs() {
                const onlineTab = document.getElementById('search-tab-online');
                if (onlineTab) {
                    onlineTab.style.display = this.localScopeWorks ? 'none' : '';
                }
                const labelMap = {
                    'local-video': this.localScopeWorks ? '他的视频' : '本地视频',
                    'local-image': this.localScopeWorks ? '他的图集' : '本地图集',
                    'local-music': this.localScopeWorks ? '他的音乐' : '本地音乐'
                };
                document.querySelectorAll('#search-result-view .view-btn').forEach(btn => {
                    const onclick = btn.getAttribute('onclick') || '';
                    if (onclick.includes('local-video')) btn.innerText = labelMap['local-video'];
                    if (onclick.includes('local-image')) btn.innerText = labelMap['local-image'];
                    if (onclick.includes('local-music')) btn.innerText = labelMap['local-music'];
                });
            }

            updateScopeDefaultView() {
                const hotSection = document.getElementById('search-hot-section');
                if (hotSection) {
                    hotSection.style.display = this.localScopeWorks ? 'none' : '';
                }
                this.renderSuggestTags();
            }

            renderSuggestTags() {
                const container = document.getElementById('search-suggest-tags');
                if (!container) return;

                let tags = [];
                if (this.localScopeWorks && this.localScopeWorks.length > 0) {
                    const tagSet = new Set();
                    this.localScopeWorks.forEach(w => {
                        const title = (w.title || w.desc || '');
                        const musicTitle = (w.music_info?.title || '');
                        const author = (w.author || '');
                        const matches = title.match(/#([^#\\s]+)/g) || [];
                        matches.forEach(t => tagSet.add(t.replace('#', '').trim()));
                        if (musicTitle) tagSet.add(musicTitle.trim());
                        if (author) tagSet.add(author.trim());
                    });
                    tags = Array.from(tagSet).filter(Boolean).slice(0, 6);
                }

                if (tags.length === 0) tags = [...this.defaultSuggestTags];

                container.innerHTML = tags.map((t, i) => {
                    const fireClass = i === 0 ? ' fire' : '';
                    const fireIcon = i === 0 ? '<i class="fa-solid fa-fire"></i> ' : '';
                    return `<div class="search-tag${fireClass}" onclick="app.searchManager.quickSearch(${jsStringArg(t)})">${fireIcon}${escapeHTML(t)}</div>`;
                }).join('');
            }

            open() {
                app.pageManager.pushState('search');
                document.getElementById('search-page').classList.add('active');

                // 1. 渲染历史 (确保数据已加载)
                this.renderHistory();

                // 2. 初始化轮播
                this.initBanner();

                // 3. 初始化热榜
                this.renderHotList();

                const val = this.inputEl.value;
                this.toggleClearBtn();
                if (val) {
                    this.onInput(val);
                } else {
                    this.showDefaultView();
                }
                this.updateScopeTabs();
                this.updateScopeDefaultView();
                setTimeout(() => this.inputEl.focus(), 300);
            }

            openProfileSearch() {
                this.setLocalScope(app.currentProfileWorks || [], app.currentProfileName || '');
                this.open();
                const firstTab = document.querySelector('#search-result-view .view-btn');
                this.switchTab('local-video', firstTab);
            }

            // --- 历史记录操作 (异步化) ---
            renderHistory() {
                const container = document.getElementById('search-history-tags');
                if (!container) return;

                if (this.history.length === 0) {
                    container.innerHTML = '<div style="font-size:12px;color:#666;padding:10px;">暂无搜索记录</div>';
                    return;
                }
                container.innerHTML = this.history.map(k => `<div class="search-tag" onclick="app.searchManager.quickSearch(${jsStringArg(k)})">${escapeHTML(k)}</div>`).join('');
            }

            async saveHistory(val) {
                // 内存操作
                this.history = this.history.filter(h => h !== val);
                this.history.unshift(val);
                if (this.history.length > 10) this.history.pop();

                // 渲染更新
                this.renderHistory();

                // 异步存入 DB
                await StorageService.set(this.HISTORY_KEY, this.history);
            }

            async clearHistory() {
                if (confirm('清空所有搜索历史？')) {
                    this.history = [];
                    await StorageService.remove(this.HISTORY_KEY);
                    this.renderHistory();
                }
            }

            // ... 以下方法保持不变，直接复制即可 ...
            // onInput, showDefaultView, toggleClearBtn, clearInput, quickSearch, doSearch, switchTab
            // initBanner, renderHotList, searchLocal, searchOnline, renderList, playLocalWork, playOnlineWork
            // 为了节省篇幅，请保留你原有代码中这些方法的实现，不需要改动

            onInput(val) {
                val = val.trim();
                this.keyword = val;
                this.toggleClearBtn();
                if (this.debounceTimer) clearTimeout(this.debounceTimer);
                if (val) {
                    document.getElementById('search-default-view').style.display = 'none';
                    document.getElementById('search-result-view').style.display = 'flex';
                    this.debounceTimer = setTimeout(() => {
                        if (this.currentTab === 'online') return;
                        this.searchLocal(this.currentTab);
                    }, 300);
                } else {
                    this.showDefaultView();
                }
            }
            showDefaultView() {
                document.getElementById('search-default-view').style.display = 'block';
                document.getElementById('search-result-view').style.display = 'none';
            }
            toggleClearBtn() {
                const btn = document.getElementById('search-clear-btn');
                if (btn) btn.style.display = this.inputEl.value ? 'block' : 'none';
            }
            clearInput() {
                this.inputEl.value = '';
                this.keyword = '';
                this.toggleClearBtn();
                this.showDefaultView();
                this.inputEl.focus();
            }
            quickSearch(kw) {
                this.inputEl.value = kw;
                this.doSearch();
            }
            doSearch() {
                const val = this.inputEl.value.trim();
                if (!val) return app.interaction.showToast('请输入关键词');
                this.keyword = val;
                this.inputEl.blur();
                this.saveHistory(val); // 调用新的异步保存
                document.getElementById('search-default-view').style.display = 'none';
                document.getElementById('search-result-view').style.display = 'flex';
                if (this.currentTab === 'online') {
                    this.searchOnline();
                } else {
                    this.searchLocal(this.currentTab);
                }
            }
            switchTab(tab, btn) {
                if (tab === 'online' && this.localScopeWorks) {
                    app.interaction.showToast('当前为博主内搜索，暂不支持联网');
                    return;
                }
                this.currentTab = tab;
                document.querySelectorAll('#search-result-view .view-btn').forEach(b => b.classList.remove('active'));
                if (btn) btn.classList.add('active');
                if (!this.keyword) return;
                if (tab === 'online') {
                    this.searchOnline();
                } else {
                    this.searchLocal(tab);
                }
            }
            initBanner() {
                if (this.bannerSwiper) return;
                const container = document.getElementById('search-banner-list');
                if (!container) return;
                const banners = [
                    { img: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=800&q=80', title: '2025 城市夜景摄影大赛' },
                    { img: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?auto=format&fit=crop&w=800&q=80', title: '追逐北极光：治愈之旅' },
                    { img: 'https://images.unsplash.com/photo-1501612780327-45045538702b?auto=format&fit=crop&w=800&q=80', title: '独立音乐人新歌首发' },
                    { img: 'https://images.unsplash.com/photo-1555680202-c86f0e12f086?auto=format&fit=crop&w=800&q=80', title: 'AI绘画技术新突破' }
                ];
                let html = banners.map(b => `
            <div class="swiper-slide banner-slide-item" 
                 style="background-image: url('${b.img}'); background-size: cover; background-position: center;" 
                 onclick="app.searchManager.quickSearch(${jsStringArg(b.title.split(' ')[1])})">
                <div class="banner-text-overlay">${escapeHTML(b.title)}</div>
            </div>`).join('');
                container.innerHTML = html;
                this.bannerSwiper = new Swiper('.search-banner-swiper', {
                    loop: true, speed: 600, autoplay: { delay: 4000, disableOnInteraction: false },
                    pagination: { el: '.swiper-pagination', clickable: true }, observer: true, observeParents: true
                });
            }
            renderHotList() {
                let container = document.getElementById('hot-search-list');
                if (!container) {
                    const defaultView = document.getElementById('search-default-view');
                    if (defaultView) {
                        const section = document.createElement('div');
                        section.className = 'hot-list-section';
                        section.innerHTML = `
                    <div class="settings-group-title" style="margin-top: 25px; margin-bottom: 10px; display:flex; align-items:center; gap:6px;">
                        <i class="fa-brands fa-hotjar" style="color: #ff4d4f;"></i> 抖音热榜
                        <span style="font-size:10px; color:#666; font-weight:normal; margin-left:auto;">每10分钟更新</span>
                    </div>
                    <div class="hot-list-card" id="hot-search-list"></div>
                    <div style="height: 60px;"></div>`;
                        defaultView.appendChild(section);
                        container = document.getElementById('hot-search-list');
                    } else return;
                }
                if (container.children.length > 0) return;
                const hotData = [
                    { title: "周杰伦新歌首发", score: "982.1w", tag: "爆" },
                    { title: "熊猫花花又长胖了", score: "830.5w", tag: "热" },
                    { title: "特种兵旅游攻略", score: "766.2w", tag: "热" },
                    { title: "这谁顶得住啊", score: "650.3w", tag: "新" },
                    { title: "修狗的迷惑行为", score: "520.1w", tag: "" },
                    { title: "2025年第一场雪", score: "480.9w", tag: "新" },
                    { title: "好听的背景音乐", score: "420.5w", tag: "" },
                    { title: "科目三舞蹈教学", score: "390.0w", tag: "" },
                    { title: "极简主义生活", score: "330.2w", tag: "" },
                    { title: "AI生成的二次元", score: "290.8w", tag: "" }
                ];
                let html = hotData.map((item, index) => {
                    const rank = index + 1;
                    let rankClass = 'rank-other';
                    if (rank === 1) rankClass = 'rank-1';
                    if (rank === 2) rankClass = 'rank-2';
                    if (rank === 3) rankClass = 'rank-3';
                    let tagHtml = item.tag ? `<span class="hot-tag tag-${item.tag}">${item.tag}</span>` : '';
                    return `
            <div class="hot-item" onclick="app.searchManager.quickSearch(${jsStringArg(item.title)})" style="display:flex; align-items:center; padding:12px 15px; border-bottom:1px solid rgba(255,255,255,0.05); cursor:pointer;">
                <div class="hot-rank ${rankClass}" style="width:24px; font-weight:bold; font-style:italic; margin-right:10px; text-align:center;">${rank}</div>
                <div class="hot-content" style="flex:1; color:#ddd; font-size:14px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
                    ${escapeHTML(item.title)} ${tagHtml}
                </div>
                <div class="hot-score" style="font-size:12px; color:#666;">${escapeHTML(item.score)}</div>
            </div>`;
                }).join('');
                container.innerHTML = html;
            }
            searchLocal(type) {
                const listContainer = document.getElementById('search-result-list');
                const emptyTip = document.getElementById('search-empty');
                const loading = document.getElementById('search-loading');
                listContainer.innerHTML = '';
                loading.style.display = 'none';
                emptyTip.style.display = 'none';
                let allWorks = [];
                if (this.localScopeWorks && this.localScopeWorks.length > 0) {
                    allWorks = this.localScopeWorks.map(w => ({ ...w }));
                    if (this.localScopeName) {
                        const creator = app.dataLoader.globalCreators[this.localScopeName];
                        if (creator && creator.info && creator.info.avatar) {
                            allWorks.forEach(w => { if (!w.avatar) w.avatar = creator.info.avatar; });
                        }
                    }
                } else {
                    const creators = app.dataLoader.globalCreators;
                    Object.values(creators).forEach(c => {
                        c.works.forEach(w => {
                            if (!w.avatar) w.avatar = c.info.avatar;
                            allWorks.push(w);
                        });
                    });
                    // 追加本地扫描资源（视频/音乐）
                    if (window.app && app.localMediaCache) {
                        const seenIds = new Set(allWorks.map(w => String(w.id || '')));
                        ['video', 'music'].forEach((t) => {
                            const cacheWorks = (app.localMediaCache[t] && Array.isArray(app.localMediaCache[t].works))
                                ? app.localMediaCache[t].works
                                : [];
                            cacheWorks.forEach(w => {
                                const id = String(w.id || '');
                                if (id && seenIds.has(id)) return;
                                if (id) seenIds.add(id);
                                allWorks.push(w);
                            });
                        });
                    }
                }
                const q = this.keyword.toLowerCase().trim();
                if (!q) return;
                let scoredResults = allWorks.map(w => {
                    if (type === 'local-video' && w.type !== '视频') return null;
                    if (type === 'local-image' && w.type !== '图集') return null;
                    if (type === 'local-music') {
                        if (!w.music_info || !w.music_info.url) return null;
                        const mTitle = (w.music_info.title || '').toLowerCase();
                        const mAuthor = (w.music_info.author || '').toLowerCase();
                        let mScore = 0;
                        if (mTitle.includes(q)) mScore += 20;
                        if (mAuthor.includes(q)) mScore += 10;
                        if (mScore > 0) return { work: w, score: mScore };
                        return null;
                    }
                    let score = 0;
                    const title = (w.title || '').toLowerCase();
                    const author = (w.author || '').toLowerCase();
                    const musicTitle = (w.music_info?.title || '').toLowerCase();
                    const musicAuthor = (w.music_info?.author || '').toLowerCase();
                    const hashtags = (title.match(/#(\S+)/g) || []).map(t => t.toLowerCase());
                    hashtags.forEach(tag => {
                        if (tag === '#' + q) score += 100;
                        else if (tag.includes(q)) score += 50;
                    });
                    if (title.includes(q)) { score += 20; if (title.startsWith(q)) score += 10; }
                    if (author.includes(q)) { score += 10; if (author === q) score += 15; }
                    if (musicTitle.includes(q) || musicAuthor.includes(q)) score += 5;
                    if (score > 0) return { work: w, score: score };
                    return null;
                });
                scoredResults = scoredResults.filter(i => i !== null);
                scoredResults.sort((a, b) => b.score - a.score);
                const results = scoredResults.map(item => item.work);
                this.currentLocalResults = results;
                if (results.length === 0) {
                    emptyTip.style.display = 'block';
                    emptyTip.querySelector('div').innerText = '本地未找到相关资源';
                } else {
                    this.renderList(results, type === 'local-music', false);
                }
            }
            async searchOnline() {
                const listContainer = document.getElementById('search-result-list');
                const emptyTip = document.getElementById('search-empty');
                const loading = document.getElementById('search-loading');
                listContainer.innerHTML = '';
                loading.style.display = 'block';
                emptyTip.style.display = 'none';
                try {
                    const json = await Api.External.searchDouyin(this.keyword);
                    loading.style.display = 'none';
                    // 兼容新旧API格式：新API返回 {code:200, data:[...]}，旧API返回 {aweme_list:[...]}
                    const dataList = json.data || json.aweme_list || [];
                    if (json.code === 200 && dataList.length > 0) {
                        const onlineWorks = dataList.map(item => ({
                            type: (item.type === 1 || item.video_url) ? '视频' : '图集',
                            title: item.title || item.desc || '',
                            author: item.author || item.nickname || '网络用户',
                            avatar: item.avatar || '',
                            cover: item.cover || item.img_url || '',
                            url: item.video_url || item.play_url || '',
                            images: item.images || [],
                            like: item.like || 0,
                            comment: 0,
                            music_info: { title: item.music_title || '原声', author: item.music_author || '未知', url: item.music_url || '' },
                            isOnlineResult: true,
                            share_url: item.share_url || item.url || ''
                        }));
                        this.currentOnlineResults = onlineWorks;
                        this.renderList(onlineWorks, false, true);
                    } else {
                        emptyTip.style.display = 'block';
                        emptyTip.querySelector('div').innerText = json.msg || '未搜索到相关内容';
                    }
                } catch (e) {
                    loading.style.display = 'none';
                    app.interaction.showToast('网络请求失败');
                }
            }
            renderList(works, isMusicMode = false, isOnline = false) {
                const container = document.getElementById('search-result-list');

                // 如果是在资源管理页，可能是另一个容器 ID，这里做兼容
                const targetContainer = container || document.getElementById('rm-works-grid');
                if (!targetContainer) return;

                const html = works.map((w, i) => {
                    let clickAction = '';
                    if (isOnline) clickAction = `app.searchManager.playOnlineWork(${i})`;
                    else if (isMusicMode) clickAction = `app.playFromMyMusic(${i})`;
                    else clickAction = `app.searchManager.playLocalWork(${i})`;
                    return renderUniWorkListItem(w, i, {
                        clickAction,
                        allowLiked: !isOnline,
                        fallbackAuthor: w.author || '未知用户'
                    });
                }).join('');

                targetContainer.innerHTML = html;
            }
            playLocalWork(index) {
                if (this.currentLocalResults && this.currentLocalResults.length > 0) {
                    app.enterContextPlay(this.currentLocalResults, index);
                }
            }
            async playOnlineWork(index) {
                const work = this.currentOnlineResults[index];
                if (!work) return;
                if (work.url && work.url.startsWith('http')) {
                    app.enterContextPlay([work], 0);
                    return;
                }
                app.interaction.showToast('正在解析作品...');
                try {
                    const json = await Api.External.parseVideo(work.share_url || work.cover);
                    if (json.code === 200) {
                        const fullWork = app.customManager.convertDyDataToCreator([json]).works[0];
                        app.enterContextPlay([fullWork], 0);
                    } else { throw new Error(json.msg); }
                } catch (e) { app.interaction.showToast('解析失败: ' + e.message); }
            }
        }


