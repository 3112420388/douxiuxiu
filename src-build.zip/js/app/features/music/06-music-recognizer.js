/* v3 semantic split: class from js/app/03-music-renderer-profile.js | keep script order */
        class MusicRecognizer {
            constructor() {
                this.isListening = false;
                this.mediaStream = null;
                this.mockTimer = null;

                // 模拟识别结果库 (实际开发可对接 ACRCloud 或 Shazam API)
                this.mockDatabase = [
                    { title: "晴天", author: "周杰伦" },
                    { title: "Shape of You", author: "Ed Sheeran" },
                    { title: "起风了", author: "买辣椒也用券" },
                    { title: "Stay", author: "The Kid LAROI / Justin Bieber" },
                    { title: "悬溺", author: "葛东琪" }
                ];
            }

            async toggleListen() {
                if (this.isListening) {
                    this.stopListening();
                } else {
                    await this.startListening();
                }
            }

            async startListening() {
                const btn = document.getElementById('listen-btn');
                const statusText = document.getElementById('listen-btn-text');

                try {
                    // 1. 请求麦克风权限
                    this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });

                    // 2. 更新 UI 状态
                    this.isListening = true;
                    if (btn) btn.classList.add('listening');
                    if (statusText) {
                        statusText.innerText = "识别中...";
                    }

                    // 3. 开始模拟识别 (倒计时 3-5秒)
                    // 在这里如果是真实项目，应该录制 Blob 并上传到后端 API
                    const delay = 3000 + Math.random() * 2000;

                    this.mockTimer = setTimeout(() => {
                        this.analyzeSuccess();
                    }, delay);

                } catch (err) {
                    console.error("Microphone access denied:", err);
                    alert("无法获取麦克风权限，请在浏览器设置中允许后重试。");
                    this.stopListening();
                }
            }

            stopListening() {
                this.isListening = false;

                // 停止音频流
                if (this.mediaStream) {
                    this.mediaStream.getTracks().forEach(track => track.stop());
                    this.mediaStream = null;
                }

                if (this.mockTimer) clearTimeout(this.mockTimer);

                // 恢复 UI
                const btn = document.getElementById('listen-btn');
                const statusText = document.getElementById('listen-btn-text');
                if (btn) {
                    btn.classList.remove('listening');
                    btn.classList.remove('pending');
                }
                if (statusText) statusText.innerText = "听歌识曲";
            }

            // 模拟搜歌 API (实际开发请替换为真实后端接口)
            // 这里为了演示效果，返回网易云音乐的真实试听链接
            async fetchFullSongData(title, author) {
                // 模拟网络请求延迟
                await new Promise(r => setTimeout(r, 800));

                // 演示用的映射表 (歌名 -> 网易云ID)
                // 实际项目中，这里应该是 fetch('https://api.xxx.com/search?q=' + title)
                const demoMap = {
                    "晴天": 186016,
                    "Shape of You": 468176887,
                    "起风了": 1330348068,
                    "Stay": 1859245776,
                    "悬溺": 1397345903
                };

                // 默认 ID (如果没匹配到，就用“晴天”)
                const id = demoMap[title] || 186016;

                return {
                    title: title,
                    author: author,
                    // 网易云直链 (仅供学习演示)
                    url: `https://music.163.com/song/media/outer/url?id=${id}.mp3`,
                    // 模拟一个时长 (实际应从 API 获取)
                    duration: "04:30"
                };
            }

            async analyzeSuccess() {
                this.stopListening();

                // 1. 随机获取一个识别结果 (模拟 ACRCloud/Shazam 的返回)
                const result = this.mockDatabase[Math.floor(Math.random() * this.mockDatabase.length)];

                app.interaction.showToast(`识别到：${result.title}，正在获取资源...`);

                const card = document.getElementById('music-card-anim');
                const statusText = document.getElementById('listen-btn-text');
                const btn = document.getElementById('listen-btn');

                if (btn) btn.classList.add('pending');
                if (statusText) statusText.innerText = "获取中...";
                if (card) card.style.transform = 'scale(0.95)';

                try {
                    // 2. 调用搜歌 API 获取 MP3 链接
                    const songData = await this.fetchFullSongData(result.title, result.author);

                    // 3. 核心：更新全局数据
                    // 找到当前正在播放的作品数据
                    const currentIdx = app.mainSwiper.activeIndex;
                    const workData = app.fullPlaylist[currentIdx];

                    // 覆盖原有的 music_info
                    workData.music_info = {
                        title: songData.title,
                        author: songData.author,
                        url: songData.url
                    };
                    // 如果有 duration 也可以更新
                    if (songData.duration) {
                        workData.duration = songData.duration;
                    }

                    // 4. 刷新音乐页面 UI (让下载按钮和播放器生效)
                    if (app.pageManager) {
                        app.pageManager.refreshMusicInfo(workData);

                        // 自动开始播放新识别的歌曲 (可选体验优化)
                        const audio = document.querySelector('.swiper-slide-active .bgm-audio');
                        if (audio) {
                            audio.src = songData.url;
                            audio.play();
                            app.mediaManager.currentMedia = audio; // 接管播放控制
                            app.mediaManager.updatePlayBtnState(true);
                        }
                    }

                    app.interaction.showToast('资源获取成功，可播放或下载');

                } catch (e) {
                    console.error(e);
                    app.interaction.showToast('搜歌失败，请重试');
                } finally {
                    // 恢复 UI 动画
                    if (card) {
                        card.style.transform = 'scale(1)';
                    }
                    if (btn) btn.classList.remove('pending');
                    if (statusText) statusText.innerText = "听歌识曲";
                }
            }
        }
        function getReleaseTimeText(item) {
            return item.create_time || item.time || '';
        }

        function buildTitleSectionHtml(item, options = {}) {
            let titleText = item.title || '';
            if (titleText === '无标题') titleText = '';
            const timeText = getReleaseTimeText(item);
            const showTime = options.showReleaseTimeTag !== false;
            const timeHtml = (showTime && timeText) ? `<span class="release-time-tag"><i class="fa-regular fa-clock"></i>${timeText}</span>` : '';
            const adButtonHtml = item.is_ad ? `<span class="ad-combined-btn" onclick="window.open('${item.ad_link}', '_blank'); event.stopPropagation();"><span>广告</span><i class="fa-solid fa-arrow-right"></i></span>` : '';
            const safeFullText = titleText.replace(/"/g, '&quot;');
            const enableToggle = options.enableToggle !== false;
            const maxLength = (typeof options.maxLength === 'number' && options.maxLength > 0) ? options.maxLength : 35;

            if (!enableToggle) {
                return `<div class="desc-text-container"><div class="desc-text">${adButtonHtml}${titleText}${timeHtml}</div></div>`;
            }

            if (titleText.length > maxLength) {
                const shortText = titleText.substring(0, maxLength) + '...';
                return `<div class="desc-text-container"><div class="desc-text" data-full-text="${safeFullText}" data-time="${timeText}" onclick="app.interaction.toggleDesc(this, event)">${adButtonHtml}${shortText}${timeHtml}<span class="expand-btn">展开</span></div></div>`;
            }
            return `<div class="desc-text-container"><div class="desc-text">${adButtonHtml}${titleText}${timeHtml}</div></div>`;
        }
        // --- 2. 渲染器 ---
