/* v3 semantic split: class from js/app/03-music-renderer-profile.js | keep script order */
        class Renderer {
            constructor(containerId) {
                this.container = document.getElementById(containerId);
                this.sidebarCollection = 'all';
                this.sidebarCollectionExpanded = false;
                this.sidebarViewMode = 'list';
                this.lastMiniMarkup = '';
                this.lastMiniTitle = '';
                this.lastMiniSize = null;
            }
            formatNumber(num) { num = Number(num) || 0; return num > 10000 ? (num / 10000).toFixed(1) + 'w' : num; }
            createSlideHtml(item, index) {
                const idText = String(item.id || '');
                const isLocal = (idText.includes('local-') || item.is_local);
                const type = item.type || '视频';
                const url = item.url || '';
                let avatarUrl = item.avatar;

                // 如果当前作品对象里没带头像，去全局缓存里找这个作者的头像
                if (!avatarUrl || avatarUrl === 'null' || avatarUrl.includes('${')) {
                    if (window.app && app.dataLoader && app.dataLoader.globalCreators) {
                        const creator = app.dataLoader.globalCreators[item.author];
                        if (creator && creator.info && creator.info.avatar) {
                            avatarUrl = creator.info.avatar;
                        }
                    }
                }

                // 本地资源头像统一为随机头像
                if (isLocal) {
                    avatarUrl = getDiceBearAvatar(item.author || 'Guest');
                }

                // 如果还没找到，或者找到的是无效字符串，最后才用随机头像
                if (!avatarUrl || avatarUrl === 'null' || avatarUrl === '') {
                    avatarUrl = getDiceBearAvatar(item.author);
                }
                const hideLocalTimeTag = !!(isLocal || item.is_local || item.local_type || (item.info && item.info.origin_type === 'local'));
                const titleSectionHtml = buildTitleSectionHtml(item, { showReleaseTimeTag: !hideLocalTimeTag });



                // 媒体容器
                let mediaHtml = '';
                const musicStyleKey = String((typeof CONFIG !== 'undefined' && CONFIG.LOCAL_MUSIC_SLIDE_STYLE) ? CONFIG.LOCAL_MUSIC_SLIDE_STYLE : '1');
                const musicStyleClass = `local-music-style-${musicStyleKey}`;
                if (type === '音乐' || (isLocal && idText.includes('music'))) {
                    const cover = item.cover || getDiceBearAvatar(item.author);
                    mediaHtml = `
            <div class="local-music-container ${musicStyleClass}">
                <div class="music-bg" style="background-image: url('${cover}')"></div>
                <div class="music-bg-overlay"></div>
                <div class="music-disk-wrapper">
                    <div class="music-disk" style="background-image: url('${cover}')"></div>
                    <div class="music-center"></div>
                </div>
                <div class="music-eq" aria-hidden="true">
                    <span></span><span></span><span></span><span></span><span></span>
                </div>

            </div>`;
                } else if (type === '视频') {
                    mediaHtml = `
            <div class="media-container" style="background-color:#000;">
                
                <div class="loader"></div>
                <div class="video-error"><i class="fa-solid fa-circle-exclamation"></i>加载失败</div>
                <video class="video-player lazy-media" 
                    data-src="${url}" 
                    crossorigin="anonymous"
                    poster="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" 
                    playsinline webkit-playsinline 
                    preload="metadata" 
                    style="object-fit: contain;" 
                    onloadeddata="app.captureSlidePoster(this)"
                    onloadedmetadata="app.adjustLayout(this); app.syncVideoSrcWithData(this);"
                    oncanplay="this.classList.add('loaded'); this.parentElement.querySelector('.loader').style.display='none';"
                    onerror="this.parentElement.querySelector('.loader').style.display='none'; this.parentElement.querySelector('.video-error').style.display='block';"
                    onended="app.handleVideoEnded(this)">
                </video>
            </div>`;
                } else {
                    const imagesHtml = (item.images || []).map((img, imgIdx) => {
                        const src = Array.isArray(img) ? img[img.length - 1] : img;
                        const initClass = imgIdx < CONFIG.GALLERY_INIT_LIMIT ? 'init-load' : '';
                        return `<div class="swiper-slide"><div class="media-container" style="background-color:#000;"><img class="lazy-media ${initClass}" data-src="${src}" decoding="async" onload="app.adjustLayout(this)"/></div></div>`;
                    }).join('');
                    mediaHtml = `<div class="swiper gallery-swiper gallery-${index}" style="width:100%;height:100%;"><div class="swiper-wrapper">${imagesHtml}</div></div>`;
                }

                const audioHtml = (item.music_info?.url) ? `<audio class="bgm-audio" preload="none" src="${item.music_info.url}" loop></audio>` : '';
                const isLiked = app.userDataManager ? app.userDataManager.isLiked(item) : false;
                const isFav = app.userDataManager ? app.userDataManager.isFavorite(item) : false;
                const musicTitle = item.music_info ? `${item.music_info.title} - ${item.music_info.author}` : '作品配乐';



                return `
        ${mediaHtml} ${audioHtml}
        <div class="play-overlay"><i class="fa-solid fa-play"></i></div>
        <div class="landscape-toggle-btn" onclick="app.landscapePlayer.toggle()">
            <i class="fa-solid fa-expand"></i>
            <span>全屏</span>
        </div>
            <div class="info-layer">
            <div class="desc-wrapper">${titleSectionHtml}</div>
            <div class="meta-row">
                <div class="author-info" onclick="app.openProfile('${item.author}')">
                    <img src="${avatarUrl}" class="author-avatar-small" onerror="this.src='${getDiceBearAvatar(item.author)}'">
                    <span>${item.author}</span>
                </div>
                <div class="stats-info">
                    <div class="stats-item" onclick="app.interaction.toggleLikeBtn(this)">
                        <i class="fa-solid fa-heart" style="color:${isLiked ? '#ff4d4f' : '#fff'}"></i>
                        <span>${this.formatNumber(item.like)}</span>
                    </div>
                    <div class="stats-item" onclick="app.pageManager.openComments()"><i class="fa-solid fa-comment-dots" style="transform:scaleX(-1);"></i><span>${this.formatNumber(item.comment)}</span></div>
                   <div class="stats-item" onclick="app.favManager.openQuickPanel()">
    <i class="fa-solid fa-star main-fav-icon" style="color:${isFav ? '#face15' : '#fff'}"></i>
</div>
                    <div class="stats-item" onclick="app.pageManager.openDownload(${index})"><i class="fa-solid fa-share"></i></div>
                </div>
                 
            </div>
            
        </div>
         <div class="custom-pagination-container"><div class="swiper-pagination gallery-pagination-${index}"></div></div>
        <div class="bottom-gradient-overlay"></div>
        
        <div class="footer-bar">
            <i class="fas fa-circle-nodes footer-icon" onclick="app.pageManager.openCircleHub()"></i>
            <div class="music-pill" data-index="${index}">
                <div class="progress-fill"></div>
                <div class="music-content">
                    <div class="scroll-wrap"><span>${musicTitle}&nbsp;&nbsp;&nbsp;&nbsp;</span><span>${musicTitle}&nbsp;&nbsp;&nbsp;&nbsp;</span></div>
                </div>
            </div>
            <i class="fa-solid fa-user footer-icon" onclick="app.pageManager.openMyPage()"></i>
        </div>`;
            }

            async renderSidebar(creators) {
                const container = document.getElementById('sidebar-grid-content');
                if (!container) return;

                const allKeys = Object.keys(creators);
                let collectionData = { list: [], assignments: {} };
                if (app.dataSystem && typeof app.dataSystem.getCollectionData === 'function') {
                    collectionData = await app.dataSystem.getCollectionData();
                }
                const assignments = collectionData.assignments || {};
                const list = Array.isArray(collectionData.list) ? collectionData.list : [];

                if (this.sidebarCollection !== 'all' && !list.includes(this.sidebarCollection)) {
                    this.sidebarCollection = 'all';
                }

                const counts = {};
                list.forEach(name => { counts[name] = 0; });
                allKeys.forEach(key => {
                    const group = assignments[key];
                    if (counts[group] !== undefined) counts[group] += 1;
                });

                let keys = allKeys;
                if (this.sidebarCollection !== 'all') {
                    keys = keys.filter(k => assignments[k] === this.sidebarCollection);
                }

                const currentLabel = this.sidebarCollection === 'all' ? '全部资源合集' : this.sidebarCollection;

                const mixKeys = keys.filter((k) => {
                    const c = creators[k];
                    if (!c || !c.info) return true;
                    return !(c.info.origin_type === 'local' && c.info.mix_enabled === false);
                });
                const count = mixKeys.length;
                const isListView = this.sidebarViewMode === 'list';
                const viewToggleLabel = isListView ? '网格' : '列表';
                const viewToggleIcon = isListView ? 'fa-border-all' : 'fa-list';

                const collectionItemsHtml = [
                    `<div class="sidebar-collection-item ${this.sidebarCollection === 'all' ? 'active' : ''}" onclick="app.renderer.setSidebarCollection('all')">
                        <span>全部资源合集</span>
                        <span class="sidebar-collection-count">${allKeys.length}</span>
                    </div>`,
                    ...list.map(name => `
                    <div class="sidebar-collection-item ${this.sidebarCollection === name ? 'active' : ''}" onclick="app.renderer.setSidebarCollection('${name}')">
                        <span>${name}</span>
                        <span class="sidebar-collection-count">${counts[name] || 0}</span>
                    </div>`)
                ].join('');
                let html = `
    <div class="sidebar-ad-wrapper" id="sidebar-ad-container">
        <!-- 轮播图将在此动态加载 -->
    </div>
`;
                // 然后连接原有的内容
                html += `
    <div class="sidebar-collection-drawer">
            
             <div class="mixed-recommend-card" onclick="app.loadRandom()">
            <div class="mr-title">混合推荐</div>
            <div class="mr-subtitle">从 ${count} 个资源中精选作品混合展示</div>
        </div>
            <div class="sidebar-collection-head">
                <div class="sidebar-collection-bar">
                    <div class="sidebar-collection-label">${currentLabel}</div>
                    <div class="sidebar-collection-actions">
                        <button class="sidebar-collection-btn" id="sidebar-collection-toggle" onclick="app.renderer.toggleSidebarCollectionDrawer()">
                            <i class="fa-solid fa-chevron-down"></i>
                        </button>
                    </div>
                </div>
                <button class="sidebar-collection-btn manage" onclick="app.dataSystem.openCollectionManager()">
                    <i class="fa-solid fa-gear"></i>
                </button>
            </div>
            <div class="sidebar-collection-panel" id="sidebar-collection-panel">
                <div class="sidebar-collection-list">
                    ${collectionItemsHtml}
                </div>
            </div>
        </div>
        <div class="sidebar-view-toggle">
            <div class="sidebar-view-label">资源列表</div>
            <div class="sidebar-search">
                <input type="text" id="resource-search" placeholder="搜索资源..." oninput="app.renderer.filterResources(this.value)">
            </div>
            <button class="sidebar-collection-btn" onclick="app.renderer.toggleSidebarViewMode()">
                <i class="fa-solid ${viewToggleIcon}"></i>
            </button>
        </div>
        <div class="${isListView ? 'creator-list' : 'creator-grid'}">
            <!-- 添加资源按钮放在最前面 -->
            <div class="creator-item" data-fixed="true" onclick="app.pageManager.openAddCreator()">
                <div class="c-avatar-box add-creator-btn"><i class="fa-solid fa-plus"></i></div>
                <div class="c-name">添加资源</div>
            </div>`;

                const activeCreator = window.app ? window.app.currentCreatorName : null;
                const localVideoActive = activeCreator === LOCAL_MEDIA_CONFIG.video.name ? 'active' : '';
                const localMusicActive = activeCreator === LOCAL_MEDIA_CONFIG.music.name ? 'active' : '';

                html += `
            <div class="creator-item ${localVideoActive}" data-fixed="true" data-local-type="video"
                onclick="app.openLocalMedia('video')" oncontextmenu="app.resourceManager.openLocal('video', event)">
                <div class="c-avatar-box" style="background: rgba(76, 195, 255, 0.18); border-color: rgba(76, 195, 255, 0.35);">
                    <img src="${getDiceBearAvatar(LOCAL_MEDIA_CONFIG.video.name)}"
                        onerror="this.onerror=null;this.src='${getDiceBearAvatar(LOCAL_MEDIA_CONFIG.video.name)}'">
                </div>
                <div class="c-name">${LOCAL_MEDIA_CONFIG.video.name}</div>
            </div>
            <div class="creator-item ${localMusicActive}" data-fixed="true" data-local-type="music"
                onclick="app.openLocalMedia('music')" oncontextmenu="app.resourceManager.openLocal('music', event)">
                <div class="c-avatar-box" style="background: rgba(255, 122, 216, 0.18); border-color: rgba(255, 122, 216, 0.35);">
                    <img src="${getDiceBearAvatar(LOCAL_MEDIA_CONFIG.music.name)}"
                        onerror="this.onerror=null;this.src='${getDiceBearAvatar(LOCAL_MEDIA_CONFIG.music.name)}'">
                </div>
                <div class="c-name">${LOCAL_MEDIA_CONFIG.music.name}</div>
            </div>`;
                keys.forEach(key => {
                    const c = creators[key];
                    if (c.info && (c.info.name === LOCAL_MEDIA_CONFIG.video.name || c.info.name === LOCAL_MEDIA_CONFIG.music.name)) return;
                    const isCustom = c.isCustom === true;
                    const longPressAttr = isCustom ? `oncontextmenu="app.resourceManager.open('${c.info.name}', event)"` : '';
                    const activeClass = (activeCreator && activeCreator === c.info.name) ? 'active' : '';
                    const customIndicator = isCustom ? `<div class="creator-badge" style="position:absolute;top:0;right:0;width:10px;height:10px;background:#ff4d4f;border-radius:50%;border:1px solid #000;"></div>` : '';
                    let updateBadge = '';
                    if (isCustom && c.info.last_updated && c.info.source_url) {
                        const days = (Date.now() - c.info.last_updated) / (1000 * 60 * 60 * 24);
                        if (days > 3) {
                            updateBadge = `<div class="creator-badge" style="position:absolute;bottom:0;right:0;width:10px;height:10px;background:#faad14;border-radius:50%;border:1px solid #000;" title="数据较旧"></div>`;
                        }
                    }

                    // 优化：为随机视频添加特殊点击处理
                    const isRandomApi = c.info && c.info.origin_type === 'random_api';
                    const onClickHandler = isRandomApi
                        ? `app.loadCreatorWithPreload('${c.info.name}')`
                        : `app.loadCreator('${c.info.name}', 'recommend')`;

                    html += `
<div class="creator-item ${activeClass}" onclick="${onClickHandler}" ${longPressAttr}>
    <div class="c-avatar-box" style="position:relative;">
        <img src="${c.info.avatar}" 
             onerror="this.onerror=null;this.src='data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'%23face15\'><path d=\'M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z\'/></svg>'">
        ${customIndicator}
        ${updateBadge}
        ${isRandomApi ? '<div class="random-api-indicator" style="position:absolute;top:0;left:0;width:8px;height:8px;background:#52c41a;border-radius:50%;border:1px solid #000;"></div>' : ''}
    </div>
    <div class="c-name">${c.info.name}</div>
</div>`;
                });

                html += `
        </div>
        <div style="font-size:12px;color:#666;text-align:center;margin-top:20px;">
            提示：长按资源头像可进入管理
        </div>`;

                container.innerHTML = html;
                this.initSidebarAds();
                this.toggleSidebarCollectionDrawer(this.sidebarCollectionExpanded);
            }

            async setSidebarCollection(value) {
                this.sidebarCollection = value || 'all';
                await this.renderSidebar(app.dataLoader ? app.dataLoader.globalCreators : {});
            }

            toggleSidebarCollectionDrawer(forceState) {
                if (typeof forceState === 'boolean') {
                    this.sidebarCollectionExpanded = forceState;
                } else {
                    this.sidebarCollectionExpanded = !this.sidebarCollectionExpanded;
                }

                const panel = document.getElementById('sidebar-collection-panel');
                const toggleBtn = document.getElementById('sidebar-collection-toggle');
                if (panel) {
                    panel.classList.toggle('expanded', this.sidebarCollectionExpanded);
                }
                if (toggleBtn) {
                    toggleBtn.setAttribute('aria-expanded', this.sidebarCollectionExpanded ? 'true' : 'false');
                    toggleBtn.innerHTML = this.sidebarCollectionExpanded
                        ? '<i class="fa-solid fa-chevron-up"></i>'
                        : '<i class="fa-solid fa-chevron-down"></i>';
                }
            }

            toggleSidebarViewMode() {
                this.sidebarViewMode = this.sidebarViewMode === 'list' ? 'grid' : 'list';
                this.renderSidebar(app.dataLoader ? app.dataLoader.globalCreators : {});
            }

            filterResources(value) {
                const items = document.querySelectorAll('.creator-item');
                const searchTerm = value.toLowerCase();
                items.forEach(item => {
                    if (item.dataset.fixed === 'true') {
                        item.style.display = '';
                        return;
                    }
                    const nameElement = item.querySelector('.c-name');
                    if (!nameElement) return;
                    const name = nameElement.textContent.toLowerCase();
                    if (name === '添加资源' || name.includes(searchTerm)) {
                        item.style.display = '';
                    } else {
                        item.style.display = 'none';
                    }
                });
            }

            renderProfileHeader(name, worksCount, avatar) {
                document.getElementById('profile-name').innerText = name;
                document.getElementById('profile-img').src = avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=Profile';
                document.getElementById('profile-count').innerText = "作品 " + worksCount;
            }

            renderDownloadGrid(assets) {
                const grid = document.getElementById('dl-grid');
                grid.innerHTML = assets.map((a, i) => {
                    let thumbContent = a.type === 'image' ? `<img src="${a.url}">` : (a.cover ? `<img src="${a.cover}"><div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:20px;"><i class="fa-solid fa-play"></i></div>` : `<div class="video-placeholder"></div>`);
                    return `<div class="dl-item selected" onclick="app.interaction.toggleDlItem(this)">${thumbContent}<div class="dl-checkbox" data-index="${i}"></div></div>`
                }).join('');
                app.interaction.updateSelectAllState();
            }

            // 新增：解析 "0 分 31 秒" 格式为秒数
            parseDurationStr(str) {
                if (!str) return 0;
                try {
                    // 提取分钟
                    const minMatch = str.match(/(\d+)\s*分/);
                    const min = minMatch ? parseInt(minMatch[1]) : 0;

                    // 提取秒数
                    const secMatch = str.match(/(\d+)\s*秒/);
                    const sec = secMatch ? parseInt(secMatch[1]) : 0;

                    return min * 60 + sec;
                } catch (e) {
                    return 0;
                }
            }

            renderMusicPage(music) {
                const container = document.getElementById('music-manage-content');
                const safeTitle = (music.title || '原声').replace(/'/g, "\\'");
                const safeAuthor = (music.author || '未知').replace(/'/g, "\\'");
                const url = music.url || '';
                let totalSeconds = 0;
                if (music.duration) {
                    try {
                        const minMatch = music.duration.match(/(\d+)\s*分/);
                        const min = minMatch ? parseInt(minMatch[1]) : 0;
                        const secMatch = music.duration.match(/(\d+)\s*秒/);
                        const sec = secMatch ? parseInt(secMatch[1]) : 0;
                        totalSeconds = min * 60 + sec;
                    } catch (e) { }
                }
                const formattedDuration = window.app.mediaManager.formatTime(totalSeconds);

                const miniMarkup = this.lastMiniMarkup || `
                        <div class="music-mini-placeholder">
                            <i class="fa-solid fa-photo-film"></i>
                            <span>暂无播放画面</span>
                        </div>`;
                const miniTitle = this.lastMiniTitle || '暂无标题';

                container.innerHTML = `
            <div class="music-info-card" id="music-card-anim">
                <div class="music-mini-player" id="music-mini-player">
                    <div class="music-mini-media" id="music-mini-media">
                        ${miniMarkup}
                    </div>
                </div>
                <div class="music-mini-title">
                    <div class="desc-text-container">
                        <div class="desc-text" id="music-mini-title-text" data-full-text="${miniTitle}" onclick="app.interaction.toggleDesc(this, event)">${miniTitle}</div>
                    </div>
                </div>
                <div class="music-meta-title clickable-text" id="music-page-title" onclick="app.interaction.copyText(this)" title="点击复制歌名">${music.title || '原声'}</div>
                <div class="music-meta-author clickable-text" id="music-page-author" onclick="app.interaction.copyText(this)" title="点击复制歌手">${music.author || '未知'}</div>        
            </div>
            <div class="music-player-controls">
                <div class="progress-area"><span class="time-text" id="music-curr-time">00:00</span><input type="range" class="custom-range" id="music-seek-bar" min="0" max="100" value="0" step="0.1"><span class="time-text" id="music-total-time">${formattedDuration}</span></div>
                <div class="control-buttons">
                    <i class="fa-solid fa-backward-step ctrl-btn" data-clickable="true" onclick="app.mainSwiper.slidePrev()"></i>
                    <div class="play-pause-btn ctrl-btn" id="music-toggle-btn" data-clickable="true" onclick="app.mediaManager.toggleCurrent()"><i class="fa-solid fa-pause"></i></div>
                    <i class="fa-solid fa-forward-step ctrl-btn" data-clickable="true" onclick="app.mainSwiper.slideNext()"></i>
                </div>
            </div>
            <div class="to-hillmusic-control-box"><div class="to-hillmusic" onclick="window.open('https://music.hillmis.cn', '_blank')"><span>点击前往Hillmusic，一个小而美<br>免费听、免费下无损歌曲的网页应用</span></div></div>
           <div class="music-actions-grid">           
                <div class="gradient-btn btn-pink" id="btn-music-fav"><div class="btn-icon"><i class="fa-solid fa-heart"></i></div><div class="btn-text">收藏音乐</div></div>        
                <div class="gradient-btn btn-teal" id="btn-music-download" onclick="app.downloadMusic('${url}', '${safeTitle}', '${safeAuthor}')"><div class="btn-icon"><i class="fa-solid fa-cloud-arrow-down"></i></div><div class="btn-text">下载音频</div></div>
                 <div class="gradient-btn btn-indigo" id="btn-music-copy-link"><div class="btn-icon"><i class="fa-solid fa-link"></i></div><div class="btn-text">复制音乐链接</div></div>   
            </div>`;

                const seekBar = document.getElementById('music-seek-bar');
                if (seekBar) {
                    const newSeekBar = seekBar.cloneNode(true);
                    seekBar.parentNode.replaceChild(newSeekBar, seekBar);
                    newSeekBar.addEventListener('input', (e) => {
                        window.app.mediaManager.isSeeking = true;
                        const pct = e.target.value / 100;
                        const media = window.app.mediaManager.currentMedia;
                        if (media && media.duration) document.getElementById('music-curr-time').innerText = window.app.mediaManager.formatTime(pct * media.duration);
                    });
                    newSeekBar.addEventListener('change', (e) => {
                        window.app.mediaManager.seek(e.target.value / 100);
                        setTimeout(() => { window.app.mediaManager.isSeeking = false; }, 200);
                    });
                }

                if (this.lastMiniSize) {
                    const miniPlayer = document.getElementById('music-mini-player');
                    if (miniPlayer) {
                        miniPlayer.style.width = `${this.lastMiniSize.width}px`;
                        miniPlayer.style.height = `${this.lastMiniSize.height}px`;
                    }
                }

                if (window.app && window.app.pageManager) {
                    const activeData = (window.app.fullPlaylist && window.app.mainSwiper)
                        ? window.app.fullPlaylist[window.app.mainSwiper.activeIndex]
                        : null;
                    window.app.pageManager.updateMusicMiniPlayer(activeData || {});
                }
            }
            async initSidebarAds() {
                const container = document.getElementById('sidebar-ad-container');
                if (!container) return;

                try {
                    // 修改点：使用 App 实例的镜像获取方法
                    const ads = await app.fetchFromMirrors('ad.json');

                    const slidesHtml = ads.map(ad => `
            <div class="swiper-slide sidebar-ad-slide" onclick="window.open('${ad.link}', '_blank')">
                <img src="${ad.url}" alt="${ad.alt}" loading="lazy">
            </div>
        `).join('');

                    container.innerHTML = `
            <div class="swiper sidebar-ad-swiper">
                <div class="swiper-wrapper">${slidesHtml}</div>
            </div>
        `;

                    new Swiper('.sidebar-ad-swiper', {
                        loop: true,
                        autoplay: { delay: 3000, disableOnInteraction: false },
                        observer: true, observeParents: true
                    });
                } catch (e) {
                    console.warn('加载侧边栏广告失败 (所有镜像已尝试):', e);
                    container.style.display = 'none';
                }
            }
        }

        // --- 3. 资源主页懒加载控制器 (支持筛选版) ---
