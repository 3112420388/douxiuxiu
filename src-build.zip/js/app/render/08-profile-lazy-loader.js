/* v3 semantic split: class from js/app/03-music-renderer-profile.js | keep script order */
        class ProfileLazyLoader {
            constructor() {
                this.originalWorks = []; // 存储所有原始数据
                this.displayWorks = [];  // 存储当前筛选后的数据
                this.renderedCount = 0;

                this.container = document.getElementById('works-content-area');
                this.scrollContainer = document.getElementById('works-scroll-container');
                this.loadingIndicator = document.getElementById('profile-loading-indicator');

                this.isLoading = false;
                this.viewMode = 'grid'; // grid or list
                this.currentFilter = 'all'; // all, video, image
                this.searchTerm = '';
                this.searchInput = null;

                this.scrollContainer.addEventListener('scroll', () => {
                    if (this.scrollContainer.scrollTop + this.scrollContainer.clientHeight >= this.scrollContainer.scrollHeight - 100) {
                        this.loadMore();
                    }
                });
            }

            // 重置数据 (入口)
            reset(works) {
                this.originalWorks = works; // 保存原始副本
                this.searchTerm = '';

                // 重置筛选 UI 为“全部”
                this.resetFilterUI();

                // 应用筛选 (默认 all) 并渲染
                this.applyFilter('all', null, true); // true 表示内部调用，不需更新UI（因为上面已经重置了）
            }

            scrollToTop() {
                this.scrollContainer.scrollTo({ top: 0, behavior: 'smooth' });
            }

            // 切换视图模式 (网格/列表)
            changeView(mode) {
                this.viewMode = mode;
                document.getElementById('view-icon-grid').classList.toggle('active', mode === 'grid');
                document.getElementById('view-icon-list').classList.toggle('active', mode === 'list');

                // 重新渲染当前筛选后的数据
                this.renderedCount = 0;
                this.container.innerHTML = '';
                this.container.className = mode === 'grid' ? 'works-grid' : 'works-list';
                this.loadMore();
            }

            // --- 新增：应用筛选 ---
            applyFilter(type, btnElement, isInternal = false) {
                this.currentFilter = type;

                // 1. 更新 UI 高亮
                if (btnElement) {
                    const group = btnElement.parentElement;
                    group.querySelectorAll('.filter-tag').forEach(el => el.classList.remove('active'));
                    btnElement.classList.add('active');
                }

                // 2. 过滤数据
                let filteredWorks = [];
                if (type === 'all') {
                    filteredWorks = [...this.originalWorks];
                } else if (type === 'video') {
                    filteredWorks = this.originalWorks.filter(w => w.type === '视频');
                } else if (type === 'image') {
                    filteredWorks = this.originalWorks.filter(w => this.isImageWork(w));
                }

                if (this.searchTerm) {
                    const term = this.searchTerm;
                    filteredWorks = filteredWorks.filter((w) => {
                        const title = (w.title || w.desc || '').toLowerCase();
                        const author = (w.author || '').toLowerCase();
                        const musicTitle = (w.music_info?.title || '').toLowerCase();
                        const musicAuthor = (w.music_info?.author || '').toLowerCase();
                        return title.includes(term) || author.includes(term) || musicTitle.includes(term) || musicAuthor.includes(term);
                    });
                }

                this.displayWorks = filteredWorks;

                // 3. 重置渲染状态
                this.renderedCount = 0;
                this.container.innerHTML = '';
                if (this.viewMode === 'grid') {
                    this.container.className = 'works-grid';
                } else {
                    this.container.className = 'works-list';
                }

                // 4. 显示空状态提示 (如果筛选后无数据)
                // 注意：loadMore 会处理数据加载，我们只需要处理 0 条的情况
                if (this.displayWorks.length === 0) {
                    this.container.innerHTML = '<div style="text-align:center; padding:50px; color:#666;">暂无相关内容</div>';
                    this.loadingIndicator.style.display = 'none';
                } else {
                    this.loadMore();
                }

                // 滚动回顶部
                if (!isInternal) this.scrollContainer.scrollTop = 0;
            }

            // 辅助：重置筛选 UI
            resetFilterUI() {
                const filters = document.querySelectorAll('.filter-group .filter-tag');
                filters.forEach(el => el.classList.remove('active'));
                if (filters.length > 0) filters[0].classList.add('active'); // 选中“全部”
            }

            isImageWork(work) {
                if (!work) return false;
                const type = (work.type || '').trim();
                if (type === '图集' || type === '图片' || type === '图文') return true;
                if (Array.isArray(work.images) && work.images.length > 0) return true;
                return false;
            }

            normalizeSearchTerm(term) {
                return (term || '').trim().toLowerCase();
            }

            setSearchTerm(term) {
                this.searchTerm = this.normalizeSearchTerm(term);
                this.applyFilter(this.currentFilter, null, true);
                this.scrollContainer.scrollTop = 0;
                if (this.searchTerm) {
                    app.interaction.showToast(`搜索到 ${this.displayWorks.length} 个结果`);
                } else {
                    app.interaction.showToast('已清空搜索');
                }
            }

            promptSearch() {
                const input = prompt('搜索作品标题/文案/音乐', this.searchTerm || '');
                if (input === null) return;
                this.setSearchTerm(input);
            }

            _isSameWork(a, b) {
                if (!a || !b) return false;
                if (a.id && b.id && String(a.id) === String(b.id)) return true;
                if (a.url && b.url && a.url === b.url) return true;
                if (a.title && b.title && a.author && b.author && a.title === b.title && a.author === b.author) return true;
                return false;
            }

            locateCurrentPlayingWork() {
                const current = app.fullPlaylist && app.mainSwiper ? app.fullPlaylist[app.mainSwiper.activeIndex] : null;
                if (!current) {
                    app.interaction.showToast('未找到正在播放的作品');
                    return;
                }

                const matchIndex = this.originalWorks.findIndex(w => this._isSameWork(w, current));
                if (matchIndex === -1) {
                    app.interaction.showToast('当前播放作品不在该主页');
                    return;
                }

                let displayIndex = this.displayWorks.findIndex(w => this._isSameWork(w, current));
                if (displayIndex === -1) {
                    if (this.searchTerm) {
                        this.searchTerm = '';
                    }
                    if (this.currentFilter !== 'all') {
                        const allBtn = document.querySelector('.filter-group .filter-tag');
                        this.applyFilter('all', allBtn, true);
                    } else {
                        this.applyFilter('all', null, true);
                    }
                    displayIndex = this.displayWorks.findIndex(w => this._isSameWork(w, current));
                }
                if (displayIndex === -1) {
                    app.interaction.showToast('无法定位当前作品');
                    return;
                }

                const ensureRendered = (index, tries = 0) => {
                    if (index < this.renderedCount) {
                        const item = this.container.children[index];
                        if (item) {
                            const prev = this.container.querySelector('.profile-locate-highlight');
                            if (prev) prev.classList.remove('profile-locate-highlight');
                            item.scrollIntoView({ behavior: 'smooth', block: 'center' });
                            item.classList.add('profile-locate-highlight');
                        }
                        return;
                    }
                    if (tries > 40) {
                        app.interaction.showToast('定位失败，请稍后重试');
                        return;
                    }
                    this.loadMore();
                    setTimeout(() => ensureRendered(index, tries + 1), 80);
                };

                ensureRendered(displayIndex);
            }

            // 加载更多 (核心渲染逻辑)
            loadMore() {
                // 注意：这里判断的是 displayWorks 的长度
                if (this.isLoading || this.renderedCount >= this.displayWorks.length) return;

                this.isLoading = true;
                this.loadingIndicator.style.display = 'block';

                setTimeout(() => {
                    const start = this.renderedCount;
                    const end = Math.min(start + CONFIG.PROFILE_BATCH, this.displayWorks.length);
                    const batch = this.displayWorks.slice(start, end);

                    let html = '';
                    if (this.viewMode === 'grid') {
                        html = batch.map((w, i) => {
                            const listIndex = start + i;
                            return renderWorkGridItem(w, listIndex, {
                                clickAction: `app.profileLoader.playFromFilteredProfile(${listIndex})`,
                                typeFallback: '视频',
                                showTopBadge: true
                            });
                        }).join('');
                    } else {
                        html = batch.map((w, i) => {
                            const listIndex = start + i;
                            return renderUniWorkListItem(w, listIndex, {
                                clickAction: `app.profileLoader.playFromFilteredProfile(${listIndex})`,
                                fallbackAuthor: w.author || 'Guest',
                                timeClass: 'list-time-tag',
                                timeIconStyle: 'font-size:10px;',
                                showTopBadge: true
                            });
                        }).join('');
                    }

                    this.container.insertAdjacentHTML('beforeend', html);
                    this.renderedCount = end;
                    this.isLoading = false;
                    this.loadingIndicator.style.display = 'none';

                    // 如果内容没填满屏幕，继续加载
                    if (this.scrollContainer.scrollHeight <= this.scrollContainer.clientHeight + 50 && this.renderedCount < this.displayWorks.length) {
                        this.loadMore();
                    }
                }, 50);
            }

            // --- 新增：点击播放 (使用当前筛选后的列表) ---
            playFromFilteredProfile(index) {
                // 将当前筛选后的列表作为播放上下文传入
                app.enterContextPlay([...this.displayWorks], index);
            }
        }
        // --- 4. 数据加载 (修改版) ---
