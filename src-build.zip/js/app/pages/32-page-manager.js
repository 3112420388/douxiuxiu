/* v3 semantic split: class from js/app/08-settings-search-circle-page.js | keep script order */
        class PageManager {
            constructor() {
                // 1. 绑定全局遮罩点击事件
                this.mask = document.getElementById('global-mask');
                if (this.mask) {
                    // 点击遮罩等同于按下返回键
                    this.mask.onclick = () => history.back();
                }



                // 3. 初始化音乐页面的滑动手势（暂时关闭）
                //this.initMusicPageSwipe();

                // 4. 初始化 History API
                // 替换当前状态为 home，确保有“根”状态，防止直接退出
                try {
                    window.history.replaceState({ page: 'home' }, null, '');
                } catch (e) {
                    console.warn('History API restricted (Sandboxed?)');
                }

                // 5. 核心：监听系统返回事件 (浏览器后退/安卓物理返回)
                window.addEventListener('popstate', (e) => {
                    this.handleSystemBack(e);
                });

                this.bindPageClickGuard();
            }
            bindPageClickGuard() {
                const guardClick = (e) => {
                    if (!window.app) return;
                    const suppressMs = app.clickSuppressMs || 0;
                    const lastOpenAt = app.lastOpenAt || 0;
                    if (suppressMs > 0 && Date.now() - lastOpenAt < suppressMs) {
                        if (e.cancelable) e.preventDefault();
                        e.stopPropagation();
                    }
                };

                document.querySelectorAll('.page-layer, .comment-layer, .modal-sheet').forEach((layer) => {
                    layer.addEventListener('click', guardClick, true);
                });
            }
            refreshMyPageListIfActive(targetTab) {
                const myPage = document.getElementById('my-page');
                if (myPage && myPage.classList.contains('active')) {
                    const activeBtn = myPage.querySelector('.view-switch .view-btn.active');
                    if (activeBtn) {
                        const btnText = activeBtn.innerText.trim();
                        let currentTabKey = '';
                        if (btnText === '喜欢') currentTabKey = 'likes';
                        else if (btnText === '收藏') currentTabKey = 'favorites';
                        else if (btnText === '音乐') currentTabKey = 'music';

                        if (currentTabKey === targetTab) {
                            // 重新加载列表
                            this.switchMyTab(targetTab, activeBtn);
                        }
                    }
                }
            }

            openDownloadCenter() {

                // 1. 检查并打开“我的页面” (作为底层)
                const myPage = document.getElementById('my-page');
                if (!myPage.classList.contains('active')) {
                    this.pushState('my-page'); // 写入浏览器历史
                    myPage.classList.add('active');
                    // 顺便刷新一下我的页面数据，防止退回去时是空的
                    this.updateMyStats();
                    // 初始化我的页面 Tab
                    const myTabBtn = myPage.querySelector('.view-btn');
                    if (myTabBtn) this.switchMyTab('likes', myTabBtn);
                }

                // 2. 检查并打开“设置页面” (作为中间层)
                const settingsPage = document.getElementById('settings-page');
                if (!settingsPage.classList.contains('active')) {
                    this.pushState('settings'); // 写入浏览器历史
                    settingsPage.classList.add('active');
                    // 刷新设置状态
                    if (app.settingsManager) app.settingsManager.reflectToUI();
                }

                // 3. 最后打开“下载中心” (作为顶层)
                this.pushState('download-center'); // 写入浏览器历史
                const dlPage = document.getElementById('download-center-page');

                // 【关键】强制设置更高的 z-index，确保盖住设置页
                // 假设设置页 z-index 默认为 100-120 左右，这里设为 150 足够安全
                dlPage.style.zIndex = '150';
                dlPage.classList.add('active');

                // 4. 初始化下载页面的 Tab
                const firstTabBtn = dlPage.querySelector('.view-btn');
                if (firstTabBtn && app.downloadMgr) {
                    app.downloadMgr.switchTab('active', firstTabBtn);
                }
            }
            // === 新增：全屏切换功能 ===
            toggleLayerFullscreen(elementId, btn) {
                const el = document.getElementById(elementId);
                const icon = btn.querySelector('i');

                if (!el) return;

                // 切换类名
                el.classList.toggle('layer-fullscreen');
                const isFull = el.classList.contains('layer-fullscreen');

                // 切换图标
                if (isFull) {
                    icon.className = 'fa-solid fa-down-left-and-up-right-to-center'; // 收缩图标
                } else {
                    icon.className = 'fa-solid fa-up-right-and-down-left-from-center'; // 扩展图标
                }
            }
            /**
             * 辅助方法：向浏览器历史栈添加一条记录
             * 当打开新页面/弹窗时调用
             */
            pushState(id) {
                if (window.app && window.app.feedMode === 'recommend' && typeof window.app.pauseAllRecommendSingleVideos === 'function') {
                    window.app.pauseAllRecommendSingleVideos();
                }
                if (window.app && typeof app.safeOpenPage === 'function') {
                    app.safeOpenPage();
                }
                try {
                    window.history.pushState({ id: id }, null, '');
                } catch (e) { /* ignore */ }
            }

            /**
             * 核心逻辑：处理系统返回
             * 注意：此处只操作 DOM (remove active)，绝对不要调用 history.back()
             * 否则会造成死循环：popstate -> handle -> back -> popstate ...
             */
            handleSystemBack(e) {
                const tryClose = (selector) => {
                    const el = document.querySelector(selector);
                    if (el && el.classList.contains('active')) {
                        el.classList.remove('active');
                        setTimeout(() => {
                            el.classList.remove('layer-fullscreen');
                            const btnIcon = el.querySelector('.expand-toggle-btn i');
                            if (btnIcon) btnIcon.className = 'fa-solid fa-up-right-and-down-left-from-center';
                        }, 300);
                        return true;
                    }
                    return false;
                };

                if (tryClose('#work-settings-sheet')) {
                    const mask = document.getElementById('global-mask');
                    if (mask) mask.classList.remove('active');
                    return;
                }

                if (tryClose('#text-display-page')) return;
                if (tryClose('#download-sheet')) return;
                if (tryClose('#comment-layer')) return;
                if (tryClose('#fav-select-sheet')) return;
                if (tryClose('#fav-quick-panel')) {
                    const mask = document.getElementById('global-mask');
                    if (mask) mask.classList.remove('active');
                    return;
                }
                if (tryClose('#task-sheet')) return;

                const musicPage = document.getElementById('music-manage-page');
                if (musicPage && musicPage.classList.contains('active')) {
                    musicPage.classList.remove('active');

                    // 恢复视频模式
                    if (window.app.mediaManager) {
                        window.app.mediaManager.switchToVideoMode();
                        window.app.mediaManager.syncActiveProgressNow();
                    }

                    if (window.app.isMusicMode) {
                        window.app.isMusicMode = false;
                        history.back();
                    }
                    return;
                }

                const sidebar = document.getElementById('sidebar-page');
                if (sidebar && sidebar.classList.contains('active')) {
                    sidebar.classList.remove('active');
                    const mask = document.getElementById('global-mask');
                    if (mask) mask.classList.remove('active');
                    return;
                }

                const activePages = Array.from(document.querySelectorAll('.page-layer.active'));
                if (activePages.length > 0) {
                    const topPage = activePages[activePages.length - 1];
                    topPage.classList.remove('active');
                    return;
                }

                if (window.app.isContextMode) {
                    const prevPageId = window.app.returnPageId;
                    window.app.restoreHomeFeed(!prevPageId);
                    if (prevPageId) {
                        const prevPage = document.getElementById(prevPageId);
                        if (prevPage) {
                            prevPage.classList.add('active');
                            if (prevPageId === 'search-page' && window.app.searchManager) {
                                const input = document.getElementById('global-search-input');
                                if (input && input.value.trim()) {
                                    document.getElementById('search-result-view').style.display = 'flex';
                                    document.getElementById('search-default-view').style.display = 'none';
                                }
                            }
                        }
                    }
                    window.app.returnPageId = null;
                    return;
                }
            }
            // ================= Open 方法 (打开时 pushState) =================

            openMusicManage() {

                this.pushState('music');
                const currentIdx = app.mainSwiper.activeIndex;
                const data = app.fullPlaylist[currentIdx];
                const music = data.music_info || {};
                // 如果没有音乐信息，显示提示并尝试打开（显示为空状态）
                if (!music.url && !music.title) {
                    app.interaction.showToast('该作品暂无有效音乐信息');
                    // 可选择 return 不打开页面，或者继续打开显示空状态
                    // 这里选择继续打开，但在页面里按钮会失效
                }
                // 打开页面时，强制切换到“音乐模式” (视频静音，音频播放)
                if (app.mediaManager) {
                    app.mediaManager.switchToMusicMode();
                }
                // 1. 渲染基础结构
                // 这步生成 HTML，但里面的时间可能默认为 00:00
                app.renderer.renderMusicPage(music);
                if (app.mediaManager) app.mediaManager.refreshMusicPageRefs(true);

                // 2. 激活页面
                document.getElementById('music-manage-page').classList.add('active');

                // 3. 立即加载静态信息 (核心步骤)
                // 调用 refreshMusicInfo 从 data 中解析 JSON 预设时长 (如 "0分30秒")
                // 这能保证即使视频还没缓冲完，总时长也不显示 00:00
                this.refreshMusicInfo(data);
                if (app.mediaManager) {
                    app.mediaManager.refreshMusicPageRefs(true);
                    const media = app.mediaManager.currentMedia;
                    if (media && media.readyState >= 1 && media.duration) {
                        const pct = (media.currentTime / media.duration) * 100;
                        if (app.mediaManager._syncMusicPageUI) {
                            app.mediaManager._syncMusicPageUI(media.currentTime, pct);
                        }
                    }
                }

                // 4. 立即同步动态信息 (覆盖上一步的重置)
                // 如果当前已经在播放中，我们要立刻显示当前进度，而不是 0
                if (app.mediaManager && app.mediaManager.currentMedia) {
                    const media = app.mediaManager.currentMedia;

                    // 4.1 同步播放/暂停按钮
                    const isPlaying = !media.paused;
                    app.mediaManager.updatePlayBtnState(isPlaying);

                    // 4.2 同步进度条和时间
                    // 只有当媒体已加载元数据(readyState >= 1)时才读取，否则保持 JSON 预设
                    if (media.readyState >= 1) {
                        const curr = media.currentTime;
                        const dur = media.duration || 1; // 防止除以0
                        const pct = (curr / dur) * 100;

                        const musicSeekBar = document.getElementById('music-seek-bar');
                        const musicCurrTime = document.getElementById('music-curr-time');
                        const musicTotalTime = document.getElementById('music-total-time');

                        // 立即更新 DOM，消除延迟感
                        if (musicSeekBar) musicSeekBar.value = pct;
                        if (musicCurrTime) musicCurrTime.innerText = app.mediaManager.formatTime(curr);

                        // 如果获取到了真实的媒体文件时长，用它覆盖 JSON 里的预设文本
                        if (media.duration && !isNaN(media.duration) && musicTotalTime) {
                            musicTotalTime.innerText = app.mediaManager.formatTime(media.duration);
                        }
                    }
                }
                // [新增] 如果没有 URL，禁用下载和收藏按钮
                if (!music.url) {
                    const btnDl = document.getElementById('btn-music-download');
                    const btnFav = document.getElementById('btn-music-fav');
                    const btnCopy = document.getElementById('btn-music-copy-link');

                    if (btnDl) { btnDl.style.opacity = '0.5'; btnDl.onclick = () => app.interaction.showToast('无法下载：无音频源'); }
                    if (btnFav) { btnFav.style.opacity = '0.5'; btnFav.onclick = () => app.interaction.showToast('无法收藏：无音频源'); }
                    if (btnCopy) { btnCopy.style.opacity = '0.5'; btnCopy.onclick = () => app.interaction.showToast('无法复制：无音频源'); }
                }

            }
            openLogViewer() {
                this.pushState('log-viewer');
                document.getElementById('log-viewer-page').classList.add('active');
                // 打开时自动渲染
                if (app.logger) app.logger.renderLogs();
            }
            openSidebar() {
                this.pushState('sidebar');
                document.getElementById('sidebar-page').classList.add('active');
                if (this.mask) this.mask.classList.add('active');
            }

            openSidebarSafe() {
                if (window.app) {
                    const now = Date.now();
                    if (app.isSwiping || (now - (app.lastSwipeTime || 0) < 200)) return;
                }
                this.openSidebar();
            }

            openProfile() {
                this.pushState('profile');
                document.getElementById('profile-page').classList.add('active');
            }

            openAddCreator() {
                const targetCollection = (app.renderer && app.renderer.sidebarCollection && app.renderer.sidebarCollection !== 'all')
                    ? app.renderer.sidebarCollection
                    : '';
                app.pendingAddCollection = targetCollection;
                this.pushState('add-creator');
                document.getElementById('add-creator-page').classList.add('active');
            }

            openComments() {
                this.pushState('comments');
                const currentIdx = app.mainSwiper.activeIndex;
                const data = app.fullPlaylist[currentIdx];
                if (data) {
                    const descEl = document.getElementById('comment-desc');
                    const tagEl = document.getElementById('comment-tags');
                    if (descEl) descEl.innerText = data.title || '无描述';
                    if (tagEl) tagEl.innerText = data.type === '视频' ? '#视频 #分享' : '#图集 #美图';
                }
                document.getElementById('comment-layer').classList.add('active');

            }

            openDownload(idx) {
                this.pushState('download');
                // prepareDownload 内部负责渲染 DOM 并添加 .active
                if (app.prepareDownload) app.prepareDownload(idx);
            }

            openPage(title) {
                this.pushState('common');
                const titleEl = document.getElementById('common-page-title');
                if (titleEl) titleEl.textContent = title;
                document.getElementById('common-page').classList.add('active');
            }
            openSearch() {
                if (window.app && typeof app.safeOpenPage === 'function') {
                    app.safeOpenPage();
                }
                if (app.searchManager) {
                    app.searchManager.clearLocalScope();
                    app.searchManager.open();
                } else {
                    console.error("SearchManager not initialized");
                }
            }
            openSettings() {
                this.pushState('settings');
                // 同步设置数据到 UI
                if (app.settingsManager) app.settingsManager.reflectToUI();
                document.getElementById('settings-page').classList.add('active');
            }
            openApiSettings() {
                this.pushState('api-settings');
                if (app.settingsManager) app.settingsManager.reflectToUI();
                document.getElementById('api-settings-page').classList.add('active');
            }
            openApiCustom() {
                this.pushState('api-custom');
                document.getElementById('api-custom-page').classList.add('active');
            }
            // 在 PageManager 类中添加或替换
            openMyPage() {
                this.pushState('my-page');
                this.updateMyStats();

                // 【修复】精确选择 #my-page 下的第一个 view-btn，防止选中 Profile 页面的按钮
                const firstTabBtn = document.querySelector('#my-page .view-btn');
                this.switchMyTab('likes', firstTabBtn);

                document.getElementById('my-page').classList.add('active');
            }

            updateMyStats() {
                const ud = app.userDataManager;
                document.getElementById('stat-likes').innerText = ud.likes.length;
                // 收藏数改为统计所有文件夹内的总数
                document.getElementById('stat-favorites').innerText = ud.getTotalFavCount();
                document.getElementById('stat-music').innerText = ud.music.length;
            }
            // 核心修改：切换 Tab 逻辑 (修复版)
            async switchMyTab(tab, btn) {
                try {
                    // 1. 【UI 优先】立即更新按钮选中状态，让用户感觉到点击已生效
                    document.querySelectorAll('#my-page .view-btn').forEach(b => b.classList.remove('active'));
                    if (btn) btn.classList.add('active');

                    // 2. 获取容器
                    const containerLikes = document.getElementById('my-likes-grid');
                    const containerFavorites = document.getElementById('my-favorites-grid');
                    const containerMusic = document.getElementById('my-music-list');
                    const containerDl = document.getElementById('my-download-list');
                    const emptyTip = document.getElementById('my-empty-tip');

                    // 3. 先隐藏所有容器，并显示简单的加载状态（可选，防止闪烁）
                    if (containerLikes) containerLikes.style.display = 'none';
                    if (containerFavorites) containerFavorites.style.display = 'none';
                    if (containerMusic) containerMusic.style.display = 'none';
                    if (containerDl) containerDl.style.display = 'none';
                    if (emptyTip) emptyTip.style.display = 'none';

                    // 4. 【核心优化】使用 setTimeout 将繁重的渲染任务推迟到 UI 绘制之后
                    // 这允许浏览器先绘制 Tab 的切换动画，解决“点击无反应”的问题
                    await new Promise(resolve => setTimeout(resolve, 10));

                    const ud = app.userDataManager;
                    let isEmpty = false;

                    // --- 逻辑分支 (渲染逻辑) ---

                    if (tab === 'likes') {
                        // 喜欢列表
                        if (!ud.likes || ud.likes.length === 0) {
                            isEmpty = true;
                        } else {
                            if (containerLikes) {
                                containerLikes.style.display = 'grid';
                                // 使用 Fragment 或 innerHTML 渲染
                                this.renderWorksGrid(ud.likes, 'my-likes-grid', 'playFromMyLikes');
                            }
                        }
                    }
                    else if (tab === 'favorites') {
                        // 收藏夹列表
                        let folders = ud.favData;
                        if (!folders || !Array.isArray(folders)) folders = [];

                        if (containerFavorites) {
                            containerFavorites.style.display = 'block';

                            // 渲染“新建”按钮
                            const addBtnHtml = `
                                <div class="fav-folder-item" onclick="app.favManager.openCreateModal()" style="border-bottom: 10px solid rgba(255,255,255,0.02);">
                                    <div class="fav-icon-box" style="background: rgba(255,255,255,0.1); color: #fff;">
                                        <i class="fa-solid fa-plus"></i>
                                    </div>
                                    <div class="fav-info">
                                        <div class="fav-title">新建收藏夹</div>
                                    </div>
                                </div>`;

                            // 优化：避免在 map 中做过于复杂的 try-catch，提升性能
                            const folderListHtml = folders.map(f => {
                                if (!f) return '';
                                const folderName = f.name || '未命名文件夹';
                                const items = Array.isArray(f.items) ? f.items : [];
                                const count = items.length;

                                // 获取封面
                                let coverHtml = '<i class="fa-regular fa-folder-open"></i>';
                                if (count > 0 && items[0]) {
                                    const imgUrl = getWorkCover(items[0], items[0].author || 'Guest');
                                    if (imgUrl) coverHtml = `<img src="${escapeAttr(imgUrl)}" style="width:100%;height:100%;object-fit:cover;">`;
                                }

                                return `
                                    <div class="fav-folder-item" onclick="app.favManager.openFolderDetail('${f.id}')">
                                        <div class="fav-icon-box">${coverHtml}</div>
                                        <div class="fav-info">
                                            <div class="fav-title">${folderName}</div>
                                            <div class="fav-count">${count} 个作品</div>
                                        </div>
                                        <div style="color:#666;"><i class="fa-solid fa-angle-right"></i></div>
                                    </div>`;
                            }).join('');

                            containerFavorites.innerHTML = addBtnHtml + folderListHtml;
                        }
                        isEmpty = false; // 即使没有收藏夹，也会显示新建按钮，所以永远不为空
                    }
                    else if (tab === 'music') {
                        // 音乐列表
                        if (!ud.music || ud.music.length === 0) {
                            isEmpty = true;
                            if (containerMusic) containerMusic.innerHTML = '';
                        } else {
                            if (containerMusic) {
                                containerMusic.style.display = 'block';
                                this.renderMyMusic(ud.music);
                            }
                        }
                    }
                    else if (tab === 'downloads') {
                        // 下载列表
                        if (!ud.downloads || ud.downloads.length === 0) {
                            isEmpty = true;
                        } else {
                            if (containerDl) {
                                containerDl.style.display = 'block';
                                this.renderMyDownloads(ud.downloads);
                            }
                        }
                    }

                    // 5. 显示空状态提示
                    if (isEmpty && emptyTip) emptyTip.style.display = 'block';

                } catch (e) {
                    console.error("切换Tab出错:", e);
                    if (window.app && app.interaction) app.interaction.showToast("列表加载出错");
                }
            }

            // 优化版的网格渲染 (分批次，防止页面假死)
            async renderWorksGrid(list, containerId, clickFnName) {
                const container = document.getElementById(containerId);
                container.innerHTML = '';

                const BATCH_SIZE = 50;
                let index = 0;

                const renderBatch = () => {
                    const batch = list.slice(index, index + BATCH_SIZE);
                    if (batch.length === 0) return;

                    const html = batch.map((w, i) => {
                        const globalIndex = index + i;
                        return renderWorkGridItem(w, globalIndex, {
                            clickAction: `app.${clickFnName}(${globalIndex})`,
                            typeFallback: '视频'
                        });
                    }).join('');

                    container.insertAdjacentHTML('beforeend', html);
                    index += BATCH_SIZE;
                    if (index < list.length) requestAnimationFrame(renderBatch);
                };

                renderBatch();
            }



            // 2. 渲染“我的音乐”列表 (增加空状态处理)
            renderMyMusic(list) {
                const container = document.getElementById('my-music-list');
                if (!container) return;

                // 1. 基础判空
                if (!list || !Array.isArray(list) || list.length === 0) {
                    container.innerHTML = '';
                    return;
                }

                // 2. 渲染列表（增加容错判断）
                const html = list.map((m, i) => {
                    // 【核心修复】如果数据项为空，直接跳过，防止报错
                    if (!m) return '';

                    // 安全获取字段，防止 undefined 报错
                    const safeTitle = m.title || '未知标题';
                    const safeAuthor = m.author || '未知作者';

                    // 判断是否有来源视频
                    const canJump = !!(m.source_work && m.source_work.title);
                    const subText = canJump ? `来源: ${m.source_work.title}` : safeAuthor;

                    return `
        <div class="my-list-item" onclick="app.playFromMyMusic(${i})">
            <div class="music-item-icon">
                <i class="fa-solid fa-music"></i>
            </div>
            <div class="item-info">
                <div class="item-title">${safeTitle}</div>
                <div class="item-sub">${safeAuthor}</div>
            </div>
            <!-- 删除按钮 -->
            <div class="item-action-btn" onclick="app.deleteMyMusic(event, ${i})">
                <i class="fa-solid fa-trash"></i>
            </div>
        </div>`;
                }).join('');

                container.innerHTML = html;
            }

            renderMyDownloads(list) {
                const html = list.map((d) => renderDownloadHistoryItem(d, {
                    actionIcon: 'fa-folder-open',
                    actionClick: "alert('文件已下载到本地，请在手机/电脑的文件管理器中查看')"
                })).join('');
                document.getElementById('my-download-list').innerHTML = html;
            }

            openTextPage(type, isHighPriority = false) {
                this.pushState('text-page');

                const titleEl = document.getElementById('text-page-title');
                const bodyEl = document.getElementById('text-page-body');
                const page = document.getElementById('text-display-page');

                let title = '';
                let content = '';

                // 使用 helper 获取内容，保持代码整洁
                if (type === 'privacy') {
                    title = '隐私政策';
                    content = this._getTextContent('privacy');
                } else if (type === 'terms') {
                    title = '免责声明';
                    content = this._getTextContent('terms');
                } else if (type === 'about') {
                    title = '软件介绍';
                    content = this._getTextContent('about');
                }

                if (titleEl) titleEl.innerText = title;
                if (bodyEl) bodyEl.innerHTML = content;

                // 处理层级 (协议弹窗需要更高层级)
                if (isHighPriority) {
                    page.classList.add('z-top');
                } else {
                    page.classList.remove('z-top');
                }

                page.classList.add('active');
            }

            // ================= Close 方法 (触发 history.back) =================

            /**
             * 关闭当前页面的通用方法
             * 点击页面左上角“返回”箭头时调用此方法
             */
            closePage(id) {
                // 不直接操作 DOM，而是让浏览器回退，触发 popstate，进而调用 handleSystemBack
                history.back();
            }

            closeComments() {
                history.back();
            }

            /**
             * 特殊方法：重置所有状态
             * 用于：点击侧边栏加载新资源时，或者需要强行清场时
             */
            closeAll() {
                // 如果侧边栏是打开的，退一步（通常此时是由侧边栏触发的加载）
                const sidebar = document.getElementById('sidebar-page');
                if (sidebar && sidebar.classList.contains('active')) {
                    history.back();
                } else {
                    // 兜底逻辑：如果历史记录混乱，强行清理 UI
                    // 这里不调用 history.back() 防止不可控的跳转
                    document.querySelectorAll('.page-layer.active').forEach(e => e.classList.remove('active'));

                    const list = ['download-sheet', 'comment-layer', 'global-mask', 'task-sheet'];
                    list.forEach(id => {
                        const el = document.getElementById(id);
                        if (el) el.classList.remove('active');
                    });
                }
            }
            backToHome() {
                // 1. 强制关闭所有页面层 (包括侧边栏、添加页、设置页等)
                document.querySelectorAll('.page-layer').forEach(el => {
                    el.classList.remove('active');
                });

                // 2. 强制关闭所有遮罩
                document.querySelectorAll('.overlay-mask').forEach(el => {
                    el.classList.remove('active');
                });

                // 3. 关闭底部 Sheet 和 评论区 (如果有打开)
                const sheet = document.getElementById('download-sheet');
                if (sheet) sheet.classList.remove('active');

                const commentLayer = document.getElementById('comment-layer');
                if (commentLayer) commentLayer.classList.remove('active');

                // 4. 为了保持浏览器历史记录的一致性（可选优化）
                // 尝试回退2次（假设路径是：主页->侧边栏->添加页）
                // 如果担心多退，可以注释掉下面这行，只做视觉关闭即可
                history.go(-2);
            }
            // ================= 辅助逻辑 =================

            // 获取长文本内容
            _getTextContent(type) {
                // --- 1. 免责声明与数据来源 ---
                if (type === 'terms') {
                    return `
                    <h3>免责声明</h3>
                    <p>更新日期：2025年12月1日</p>          
                    <h4>1. 数据来源说明</h4>
                    <p>本应用（抖咻咻）是一款基于 Web 技术的第三方客户端。应用内展示的所有视频、图片、音乐及文本内容，其数据来源方式如下：</p>
                    <ul>
                        <li><strong>用户主动输入：</strong>通过用户粘贴的公开分享链接（如抖音/TikTok分享链接）。</li>
                        <li><strong>第三方接口解析：</strong>本应用调用公开合法的第三方解析接口，将分享链接转换为可播放的媒体地址。</li>
                        <li><strong>非官方关联：</strong>本应用与抖音（Douyin）、TikTok 或字节跳动公司无任何官方关联。</li>
                    </ul>

                    <h4>2. 数据使用方式</h4>
                    <p>本应用仅作为内容的<strong>浏览器/播放器</strong>，不进行任何形式的数据爬取、破解或非法存储。所有媒体资源均存储于原平台的 CDN 服务器，本应用仅做链接引用。</p>

                    <h4>3. 责任声明</h4>
                    <p>用户在使用本应用时，应遵守相关法律法规。对于用户使用本应用下载、分享的内容所产生的任何版权纠纷或法律后果，本应用开发者不承担任何责任。若您是内容版权方且认为本应用侵犯了您的权益，请联系开发者，我们将立即停止相关链接的解析服务。</p>
                    
                    <p><strong>本应用仅供技术学习与交流使用，禁止用于任何商业用途。</strong></p>
                    `;
                }

                // --- 2. 隐私权限说明 ---
                if (type === 'privacy') {
                    return `
                    <h3>隐私权限说明</h3>
                    <p>为了向您提供完整的功能体验，我们需要申请以下权限。我们遵循“最小必要、就地处理、可随时清理”的原则。</p>

                    <h4>1. 存储权限 (Storage)</h4>
                    <p><strong>用途：</strong>保存您的个性化设置（如自动连播、静音）、历史记录（下载记录、收藏列表）、本地扫描结果以及自定义添加的资源数据。</p>
                    <p><strong>方式：</strong>使用浏览器本地存储 (LocalStorage/IndexedDB)，数据仅保存在您的设备上，不会上传至任何服务器。</p>

                    <h4>2. 本地媒体扫描</h4>
                    <p><strong>用途：</strong>扫描您选择的文件夹，筛选出视频/音乐资源并生成本地播放列表。</p>
                    <p><strong>方式：</strong>仅读取文件路径、文件名、文件大小等基础信息，不读取或上传文件内容。您可在“设置”中指定扫描目录与最小大小阈值。</p>

                    <h4>3. 麦克风权限 (Microphone)</h4>
                    <p><strong>用途：</strong>仅用于“听歌识曲”功能。</p>
                    <p><strong>方式：</strong>当您点击封面上的麦克风图标时申请。音频数据仅在本地或发送至识别接口进行特征比对，识别完成后立即丢弃，不会录音保存。</p>

                    <h4>4. 网络权限 (Network)</h4>
                    <p><strong>用途：</strong>加载视频、图片资源，检查应用更新，以及请求解析接口。</p>
                    <p><strong>方式：</strong>标准的 HTTP/HTTPS 请求。</p>

                    <h4>5. 设备信息 (Device Info)</h4>
                    <p><strong>用途：</strong>适配屏幕布局（响应式设计），判断是否为移动设备以优化触摸体验。</p>
                    <p><strong>方式：</strong>读取 UserAgent 和 Screen Resolution，不收集IMEI等敏感识别码。</p>

                    <h4>6. 数据保留与清理</h4>
                    <p>您可以在“存储管理”中清除缓存、重置本地数据或关闭本地混合播放。清理后不会保留任何历史记录与本地扫描结果。</p>
                    `;
                }

                // --- 3. 软件介绍 (美化版) ---
                if (type === 'about') {
                    return `
                    <div class="about-page-wrapper">
                        <!-- 头部 Logo -->
                        <div class="about-header-section">
                            <div class="about-logo-box">
                                <i class="fa fa-circle-nodes"></i>
                            </div>
                            <div class="about-app-name">抖咻咻</div>
                        </div>

                         <div class="z-desc">Developed by Hillmis</div>
                         <div class="z-desc" style="margin-top:6px;">一站式短视频/图集/音乐浏览器，支持本地扫描、收藏管理与多视图体验。</div>
    

                        <!-- 功能亮点 (对称网格) -->
                        <div class="about-section-header">功能亮点</div>
                        <div class="feature-grid-box">
                            <div class="feature-card-item">
                                <div class="f-icon blue"><i class="fa-solid fa-mobile-screen"></i></div>
                                <div class="f-title">沉浸体验</div>
                                <div class="f-desc">全屏滑动 纯净浏览</div>
                            </div>
                            <div class="feature-card-item">
                                <div class="f-icon purple"><i class="fa-solid fa-users-viewfinder"></i></div>
                                <div class="f-title">资源订阅</div>
                                <div class="f-desc">一键导入 实时更新</div>
                            </div>
                            <div class="feature-card-item">
                                <div class="f-icon orange"><i class="fa-solid fa-music"></i></div>
                                <div class="f-title">听歌识曲</div>
                                <div class="f-desc">快速识别 收藏下载</div>
                            </div>
                            <div class="feature-card-item">
                                <div class="f-icon green"><i class="fa-solid fa-chart-pie"></i></div>
                                <div class="f-title">数据分析</div>
                                <div class="f-desc">色调提取 尺寸检测</div>
                            </div>
                            <div class="feature-card-item">
                                <div class="f-icon teal"><i class="fa-solid fa-folder-open"></i></div>
                                <div class="f-title">本地资源</div>
                                <div class="f-desc">本地扫描 离线播放</div>
                            </div>
                            <div class="feature-card-item">
                                <div class="f-icon pink"><i class="fa-solid fa-layer-group"></i></div>
                                <div class="f-title">多视图模式</div>
                                <div class="f-desc">单列/双列/推荐</div>
                            </div>
                        </div>

                        <!-- 致谢列表 -->
                        <div class="about-section-header">致谢 & 依赖</div>
                        <div class="credits-card-box">
                            <div class="credits-item"><span>核心框架：</span><span>HTML5 + Vanilla JS</span></div>
                            <div class="credits-item"><span>滑动组件：</span><span>Swiper.js v11</span></div>
                            <div class="credits-item"><span>第三方库：</span><span>Fas + Jszip + Filesave</span></div>
                            <div class="credits-item"><span>解析支持：</span><span>北城</span></div>
                            <div class="credits-item"><span>设计灵感：</span><span>Douyin + Tuxiuxiu</span></div>
                            <div class="credits-item"><span>开发工具：</span><span>Vscode + Gemini3.0+WebIDE</span></div>           
                        </div>
                        <div class="about-section-header">一言</div>
                        <div class="credits-card-box">  
                            <div class="credits-item"><span>“天若有情天亦老，人间正道是沧桑”</span></div>
                        </div>
                    </div>
                    `;
                }
                return '';
            }

            refreshMusicInfo(data) {
                if (!document.getElementById('music-manage-page').classList.contains('active')) return;
                const music = data.music_info || {};
                const safeTitle = music.title || '原声';
                const safeAuthor = music.author || '未知';
                const safeUrl = music.url || '';
                const titleEl = document.getElementById('music-page-title');
                const authorEl = document.getElementById('music-page-author');
                if (titleEl) titleEl.innerText = safeTitle;
                if (authorEl) authorEl.innerText = safeAuthor;

                const btnDownload = document.getElementById('btn-music-download');
                const btnFav = document.getElementById('btn-music-fav');
                const btnCopyLink = document.getElementById('btn-music-copy-link');

                if (btnDownload) { btnDownload.onclick = () => window.app.downloadMusic(safeUrl, safeTitle, safeAuthor); }
                if (btnFav) {
                    const icon = btnFav.querySelector('i');
                    const text = btnFav.querySelector('.btn-text');
                    const updateBtnStyle = (isSaved) => {
                        if (isSaved) {
                            icon.className = 'fa-solid fa-check';
                            text.innerText = '已收藏';
                            btnFav.style.background = 'rgba(255,255,255,0.2)';
                            btnFav.style.border = '1px solid rgba(255,255,255,0.3)';
                        } else {
                            icon.className = 'fa-solid fa-heart';
                            text.innerText = '收藏音乐';
                            btnFav.style.background = ''; // 恢复 CSS 定义的渐变色
                            btnFav.style.border = '';
                        }
                    };

                    // 初始化状态
                    const isInitSaved = window.app.userDataManager.isMusicSaved(music);
                    updateBtnStyle(isInitSaved);

                    btnFav.onclick = null;
                    btnFav.onclick = async () => { // 加上 async
                        if (!safeUrl) { window.app.interaction.showToast('无效音频，无法收藏'); return; }

                        // 执行切换
                        const newState = await window.app.userDataManager.toggleMusic(music, data);

                        // 立即更新样式
                        updateBtnStyle(newState);

                        window.app.interaction.showToast(newState ? '已添加到我的音乐' : '已取消收藏');

                        // 刷新我的页面状态
                        window.app.pageManager.updateMyStats();
                        const musicListEl = document.getElementById('my-music-list');
                        if (musicListEl) window.app.pageManager.renderMyMusic(window.app.userDataManager.music);
                    };
                }

                if (btnCopyLink) {
                    btnCopyLink.onclick = () => {
                        if (!safeUrl) { window.app.interaction.showToast('暂无音乐链接'); return; }
                        navigator.clipboard.writeText(safeUrl).then(() => { window.app.interaction.showToast('音乐链接已复制'); }).catch(() => { window.app.interaction.showToast('复制失败，请长按文本复制'); });
                    };
                }

                this.updateMusicMiniPlayer(data);

                const currTimeEl = document.getElementById('music-curr-time');
                const totalTimeEl = document.getElementById('music-total-time');
                const seekBar = document.getElementById('music-seek-bar');
                const media = window.app.mediaManager ? window.app.mediaManager.currentMedia : null;
                if (media && media.readyState >= 1 && media.duration && media.duration !== Infinity) {
                    const pct = (media.currentTime / media.duration) * 100;
                    if (currTimeEl) currTimeEl.innerText = window.app.mediaManager.formatTime(media.currentTime);
                    if (seekBar) seekBar.value = pct;
                } else {
                    if (currTimeEl) currTimeEl.innerText = "00:00";
                    if (seekBar) seekBar.value = 0;
                }
                if (totalTimeEl) {
                    let durationStr = "00:00";
                    let realDuration = 0;
                    if (window.app.mediaManager && window.app.mediaManager.currentMedia) {
                        const media = window.app.mediaManager.currentMedia;
                        if (media.readyState >= 1 && media.duration && media.duration !== Infinity) realDuration = media.duration;
                    }
                    if (realDuration > 0) durationStr = window.app.mediaManager.formatTime(realDuration);
                    else if (data.duration) {
                        if (window.app.renderer && window.app.renderer.parseDurationStr) {
                            const secs = window.app.renderer.parseDurationStr(data.duration);
                            durationStr = window.app.mediaManager.formatTime(secs);
                        } else { durationStr = data.duration; }
                    }
                    totalTimeEl.innerText = durationStr;
                }
                const toggleBtn = document.getElementById('music-toggle-btn');
                if (toggleBtn) {
                    const isPlaying = media ? !media.paused : true;
                    toggleBtn.innerHTML = isPlaying
                        ? '<i class="fa-solid fa-pause"></i>'
                        : '<i class="fa-solid fa-play" style="padding-left:4px;"></i>';
                }
                const card = document.getElementById('music-card-anim');
                if (card) {
                    card.classList.remove('pulse-music');
                    const shouldAnimate = !(media && media.currentTime > 0.1);
                    if (shouldAnimate) {
                        card.style.transition = 'transform 0.2s';
                        card.style.transform = 'scale(0.9)';
                        setTimeout(() => { card.style.transform = 'scale(1)'; }, 200);
                    } else {
                        card.style.transition = 'none';
                        card.style.transform = 'scale(1)';
                    }
                }
            }

            updateMusicMiniPlayer(data, options = {}) {
                const mediaBox = document.getElementById('music-mini-media');
                const titleEl = document.getElementById('music-mini-title-text');
                const miniPlayer = document.getElementById('music-mini-player');
                const shouldUpdateDom = !!mediaBox;
                const preferDom = options.preferDom !== false;
                const activeSlide = preferDom ? document.querySelector('.swiper-slide-active') : null;
                const isVideo = data && data.type === '视频';
                const hasImages = data && data.images && data.images.length > 0;
                const idText = data ? String(data.id || '') : '';
                const isLocal = data && (data.is_local || idText.includes('local-') || (data.info && data.info.origin_type === 'local'));
                const isMusic = data && (data.type === '音乐' || data.type === 'music' || (data.music_info && !isVideo && !hasImages));
                let titleText = '暂无标题';
                let html = '';
                const setMiniSize = (ratioW, ratioH) => {
                    if (!ratioW || !ratioH) return;
                    const maxWidth = Math.min(320, window.innerWidth * 0.9);
                    const maxHeight = Math.min(320, window.innerHeight * 0.45);
                    let width = maxWidth;
                    let height = width * (ratioH / ratioW);
                    if (height > maxHeight) {
                        height = maxHeight;
                        width = height * (ratioW / ratioH);
                    }
                    const nextSize = { width: Math.round(width), height: Math.round(height) };
                    if (miniPlayer) {
                        miniPlayer.style.width = `${nextSize.width}px`;
                        miniPlayer.style.height = `${nextSize.height}px`;
                    }
                    this.lastMiniSize = nextSize;
                };

                const captureVideoPoster = (videoEl) => {
                    if (!videoEl || videoEl.readyState < 2) return '';
                    try {
                        const w = videoEl.videoWidth;
                        const h = videoEl.videoHeight;
                        if (!w || !h) return '';
                        const canvas = document.createElement('canvas');
                        canvas.width = w;
                        canvas.height = h;
                        const ctx = canvas.getContext('2d');
                        ctx.drawImage(videoEl, 0, 0, w, h);
                        return canvas.toDataURL('image/jpeg', 0.7);
                    } catch (e) {
                        return '';
                    }
                };

                const extractBgUrl = (el) => {
                    if (!el) return '';
                    const bg = el.style.backgroundImage || window.getComputedStyle(el).backgroundImage || '';
                    const match = /url\(["']?(.*?)["']?\)/.exec(bg);
                    return match ? match[1] : '';
                };

                if (isMusic && isLocal) {
                    const filmSvg = "data:image/svg+xml;utf8," +
                        "<svg xmlns='http://www.w3.org/2000/svg' width='520' height='360' viewBox='0 0 520 360'>" +
                        "<defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>" +
                        "<stop offset='0' stop-color='%23111111'/><stop offset='1' stop-color='%23272727'/>" +
                        "</linearGradient></defs>" +
                        "<rect width='520' height='360' rx='26' fill='url(%23g)'/>" +
                        "<rect x='30' y='40' width='460' height='280' rx='18' fill='%230b0b0d' stroke='%232b2b2b' stroke-width='4'/>" +
                        "<rect x='70' y='80' width='380' height='200' rx='12' fill='%2318181c'/>" +
                        "<g fill='%233a3a3a'>" +
                        "<rect x='40' y='70' width='20' height='36' rx='6'/><rect x='40' y='125' width='20' height='36' rx='6'/>" +
                        "<rect x='40' y='180' width='20' height='36' rx='6'/><rect x='40' y='235' width='20' height='36' rx='6'/>" +
                        "<rect x='460' y='70' width='20' height='36' rx='6'/><rect x='460' y='125' width='20' height='36' rx='6'/>" +
                        "<rect x='460' y='180' width='20' height='36' rx='6'/><rect x='460' y='235' width='20' height='36' rx='6'/>" +
                        "</g>" +
                        "<circle cx='260' cy='180' r='58' fill='%23222222' stroke='%233a3a3a' stroke-width='6'/>" +
                        "<circle cx='260' cy='180' r='18' fill='%233a3a3a'/>" +
                        "</svg>";
                    setMiniSize(4, 3);
                    html = `<img src="${filmSvg}" alt="胶片占位图" loading="eager" decoding="async">`;
                } else if (isVideo) {
                    let videoSrc = data.url || '';
                    let poster = data.cover || '';
                    let ratioW = data.width || 9;
                    let ratioH = data.height || 16;
                    if (activeSlide) {
                        const videoEl = activeSlide.querySelector('video');
                        if (videoEl) {
                            videoSrc = videoEl.currentSrc || videoEl.src || videoSrc;
                            const snapshot = captureVideoPoster(videoEl);
                            poster = snapshot || videoEl.getAttribute('poster') || poster;
                            if (videoEl.videoWidth && videoEl.videoHeight) {
                                ratioW = videoEl.videoWidth;
                                ratioH = videoEl.videoHeight;
                            }
                        }
                    }
                    setMiniSize(ratioW, ratioH);
                    if (videoSrc) {
                        const posterAttr = poster ? ` poster="${poster}"` : '';
                        html = `<video class="music-mini-video" data-mini-sync="true" src="${videoSrc}"${posterAttr} muted autoplay playsinline preload="metadata"></video>`;
                    } else if (poster) {
                        html = `<img src="${poster}" alt="当前播放封面" loading="eager" decoding="async">`;
                    }
                } else if (hasImages) {
                    let imgSrc = '';
                    let ratioW = data.width || 4;
                    let ratioH = data.height || 3;
                    if (activeSlide) {
                        const gallerySwiper = activeSlide.querySelector('.gallery-swiper');
                        if (gallerySwiper && gallerySwiper.swiper) {
                            const active = gallerySwiper.swiper.slides[gallerySwiper.swiper.activeIndex];
                            const imgEl = active ? active.querySelector('img') : null;
                            if (imgEl) {
                                imgSrc = imgEl.currentSrc || imgEl.src || imgEl.getAttribute('data-src') || '';
                                if (imgEl.naturalWidth && imgEl.naturalHeight) {
                                    ratioW = imgEl.naturalWidth;
                                    ratioH = imgEl.naturalHeight;
                                }
                            }
                        }
                    }
                    if (!imgSrc) {
                        const first = data.images[0];
                        imgSrc = Array.isArray(first) ? first[0] : first;
                    }
                    setMiniSize(ratioW, ratioH);
                    if (imgSrc) {
                        html = `<img src="${imgSrc}" alt="当前播放图集" loading="eager" decoding="async">`;
                    }
                }

                if (!html) {
                    if (miniPlayer) {
                        miniPlayer.style.width = '260px';
                        miniPlayer.style.height = '195px';
                        this.lastMiniSize = { width: 260, height: 195 };
                    }
                    html = `<div class="music-mini-placeholder"><i class="fa-solid fa-photo-film"></i><span>暂无播放画面</span></div>`;
                }

                if (shouldUpdateDom) {
                    mediaBox.innerHTML = html;
                    if (app.mediaManager) app.mediaManager.refreshMusicPageRefs(true);
                }
                this.lastMiniMarkup = html;
                if (data) {
                    titleText = data.title || data.desc || '暂无标题';
                }
                if (titleEl && shouldUpdateDom) {
                    titleEl.dataset.fullText = titleText;
                    titleEl.innerText = titleText;
                }
                this.lastMiniTitle = titleText;
                if (window.app && app.renderer) {
                    app.renderer.lastMiniMarkup = html;
                    app.renderer.lastMiniTitle = titleText;
                    app.renderer.lastMiniSize = this.lastMiniSize;
                }
            }


            // 初始化音乐页面滑动手势（上下切换歌曲）
            initMusicPageSwipe() {
                const page = document.getElementById('music-manage-page');
                if (!page) return;

                let startY = 0;
                let startX = 0;

                page.addEventListener('touchstart', (e) => {
                    startY = e.touches[0].clientY;
                    startX = e.touches[0].clientX;
                }, { passive: true });

                page.addEventListener('touchend', (e) => {
                    // 防止误触：如果点击的是进度条或按钮，不触发滑动
                    if (e.target.closest('.custom-range, .ctrl-btn, .gradient-btn')) return;

                    const endY = e.changedTouches[0].clientY;
                    const endX = e.changedTouches[0].clientX;
                    const diffY = startY - endY;
                    const diffX = Math.abs(startX - endX);

                    // 垂直滑动距离 > 50 且 大于水平滑动距离
                    if (Math.abs(diffY) > 50 && Math.abs(diffY) > diffX) {
                        if (diffY > 0) {
                            // 上滑 -> 下一个
                            app.mainSwiper.slideNext();
                        } else {
                            // 下滑 -> 上一个
                            app.mainSwiper.slidePrev();
                        }
                    }
                });
            }

            // 渲染“我的”页面 Mock 数据
            renderMyWorksMock() {
                const container = document.getElementById('my-works-grid');
                if (!container || container.children.length > 0) return; // 避免重复渲染

                let html = '';
                for (let i = 0; i < 12; i++) {
                    const isVideo = i % 2 === 0;
                    const likeCount = Math.floor(Math.random() * 5000) + 100;
                    // 使用占位图
                    const cover = `getDiceBearAvatar('Work ${i + 1}')`;

                    html += `
            <div class="work-item" onclick="alert('这是预览，实际可跳转播放')">
                <div class="work-type-badge">${isVideo ? '视频' : '图集'}</div>
                <img src="${cover}" loading="lazy">
                <div style="position:absolute; bottom:5px; left:5px; font-size:12px; font-weight:bold;">
                    <i class="fa-regular fa-heart"></i> ${likeCount}
                </div>
            </div>`;
                }
                container.innerHTML = html;
            }

            // --- 【新增】打开圈子主页的方法 ---
            openCircleHub() {
                // 1. 写入历史记录，支持返回键关闭
                this.pushState('circle-hub');

                // 2. 获取圈子页面 DOM
                const page = document.getElementById('circle-page');
                if (page) {
                    page.classList.add('active');

                    // 3. 确保数据初始化 (如果还没加载过)
                    // 这里调用 CircleManager 的 init 方法加载 Hero 区域和帖子
                    if (app.circleManager) {
                        // 仅当页面为空或需要刷新时初始化，避免重复刷新
                        const container = document.getElementById('circle-feed-container');
                        if (!container || container.children.length === 0) {
                            app.circleManager.init();
                        }
                    }
                }
            }

        }
