/* v3 semantic split: class from js/app/08-settings-search-circle-page.js | keep script order */
        class LinkParser {
            static parse(content) {
                const urlRegex = /(https?:\/\/[^\s]+)/g;
                return content.replace(urlRegex, (url) => {
                    // 如果是图片或视频直链，不处理，交由媒体渲染处理
                    if (url.match(/\.(jpeg|jpg|gif|png|mp4|webm)$/i)) return url;

                    return this.createCardHtml(url);
                });
            }

            static createCardHtml(url) {
                let icon = 'fa-link';
                let sourceClass = '';
                let sourceName = '外部链接';

                if (url.includes('pan.quark.cn')) { icon = 'fa-cloud'; sourceName = '夸克网盘'; sourceClass = 'source-quark'; }
                else if (url.includes('baidu.com')) { icon = 'fa-paw'; sourceName = '百度网盘'; sourceClass = 'source-baidu'; }
                else if (url.includes('lanzou')) { icon = 'fa-cloud-arrow-up'; sourceName = '蓝奏云'; sourceClass = 'source-lanzou'; }
                else if (url.includes('douyin.com')) { icon = 'fa-video'; sourceName = '抖音'; sourceClass = 'source-douyin'; }
                else if (url.includes('y.qq.com')) { icon = 'fa-music'; sourceName = 'QQ音乐'; sourceClass = 'source-quark'; } // 借用绿色

                // 检测是否为本站分享链接
                if (url.includes('hillmis.cn') || url.includes('?share_type=')) {
                    sourceName = '抖咻咻认证';
                    sourceClass = 'source-douyin';
                    icon = 'fa-circle-check';
                }

                return `<div class="link-card-wrapper" onclick="window.open('${url}', '_blank')">
            <div class="link-card-icon ${sourceClass}"><i class="fa-solid ${icon}"></i></div>
            <div class="link-card-info">
                <div class="link-card-title">${url}</div>
                <div class="link-card-source">${sourceName}</div>
            </div>
            <i class="fa-solid fa-angle-right" style="color:#666"></i>
        </div>`;
            }
        }
        /* --- 修复版 CircleManager (完整逻辑 + Api模块对接) --- */
