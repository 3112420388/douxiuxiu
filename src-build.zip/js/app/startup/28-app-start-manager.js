/* v3 semantic split: class from js/app/08-settings-search-circle-page.js | keep script order */
        class AppStartManager {
            constructor() {
                this.splash = document.getElementById('splash-screen');
                this.privacyModal = document.getElementById('startup-privacy-modal');
                this.privacyMask = document.getElementById('startup-privacy-mask');
                this.hasAgreed = localStorage.getItem('douxiuxiu_agreed_privacy') === 'true';
                this.hasStarted = false;
                this.hasEntered = false;
                this.hasForcedEntry = false;
                this.startTimer = null;
                this.resourceGuarded = false;
                this.resourceErrorHandler = this.handleResourceLoadError.bind(this);
                this.registerResourceGuard();
            }

            // 启动入口
            start() {
                if (this.hasStarted) return;
                this.hasStarted = true;
                this.registerResourceGuard();

                // 1. 显示开屏，模拟加载资源
                // 实际上 app.init() 已经在后台运行请求了
                this.startTimer = setTimeout(() => {
                    if (this.hasAgreed) {
                        this.enterApp();
                    } else {
                        this.showPrivacyModal();
                    }
                }, 2000); // 强制显示 2秒 开屏，提升品牌感
            }

            showPrivacyModal() {
                this.privacyModal.classList.add('active');
                this.privacyMask.classList.add('active');
            }

            agreeAndEnter() {
                localStorage.setItem('douxiuxiu_agreed_privacy', 'true');
                this.privacyModal.classList.remove('active');
                this.privacyMask.classList.remove('active');
                this.enterApp();
            }

            enterApp() {
                if (this.hasEntered) return;
                this.hasEntered = true;
                this.clearStartTimer();

                // 隐藏开屏
                this.splash.classList.add('fade-out');

                // 500ms 动画结束后移除 DOM (可选)
                setTimeout(() => {
                    this.splash.style.display = 'none';
                }, 500);
            }

            registerResourceGuard() {
                if (this.resourceGuarded) return;
                window.addEventListener('error', this.resourceErrorHandler, true);
                this.resourceGuarded = true;
            }

            handleResourceLoadError(event) {
                const target = event?.target || event?.srcElement;
                if (!target || !target.tagName) return;
                const tag = target.tagName.toUpperCase();
                const criticalTags = ['SCRIPT', 'LINK', 'IMG', 'VIDEO', 'AUDIO', 'SOURCE', 'STYLE', 'IFRAME'];
                if (!criticalTags.includes(tag)) return;
                const url = target.src || target.href;
                if (!url) return;

                if (target.dataset && target.dataset.dxxErrorHandled === '1') return;
                if (target.dataset) target.dataset.dxxErrorHandled = '1';

                this.forceEnterApp(`资源加载失败 (${tag})`);
            }

            forceEnterApp(message) {
                if (this.hasForcedEntry || this.hasEntered) return;
                this.hasForcedEntry = true;
                this.clearStartTimer();
                this.notifyResourceFailure(message);

                if (this.hasAgreed) {
                    this.enterApp();
                } else {
                    this.showPrivacyModal();
                }
            }

            notifyResourceFailure(message) {
                if (window.app && window.app.interaction) {
                    window.app.interaction.showToast('部分资源加载失败，已尝试进入', 3500);
                } else {
                    console.warn('资源加载失败，已尝试进入：', message);
                }
            }

            clearStartTimer() {
                if (this.startTimer) {
                    clearTimeout(this.startTimer);
                    this.startTimer = null;
                }
            }
        }
        const GLOBAL_START_MANAGER = new AppStartManager();
        GLOBAL_START_MANAGER.start();
