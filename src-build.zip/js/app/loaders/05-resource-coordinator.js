/* v3 semantic split: class from js/app/02-smart-loaders.js | keep script order */
        class ResourceCoordinator {
            constructor() {
                this.imgLoader = new SmartImageLoader();
                this.videoLoader = new SmartVideoLoader();
            }

            /**
             * 处理滑动资源加载
             * @param {Object} swiper Swiper实例
             * @param {Boolean} isFastScroll 是否为快速滑动模式
             */
            handleSlideChange(swiper, isFastScroll) {
                const activeIndex = swiper.activeIndex;
                const slides = swiper.slides;
                const total = slides.length;

                const currentSlide = slides[activeIndex];

                // 1. 标记当前 Slide 已处理 (用于 touchEnd 补救)
                // 快速滑动时这里只加载封面，不应标记 processed，否则 touchEnd/停顿补救不会再激活视频，
                // 会造成主页面一直显示 loading，而横屏页可以播放的错觉。
                if (isFastScroll) {
                    currentSlide.classList.remove('processed');
                    currentSlide.dataset.lightProcessed = 'true';
                } else {
                    currentSlide.classList.add('processed');
                    delete currentSlide.dataset.lightProcessed;
                }

                // 2. 视觉优化：给容器添加 loaded 类，触发 CSS 渐入动画
                const container = currentSlide.querySelector('.media-container');
                if (container) {
                    // 强制重绘以触发动画
                    requestAnimationFrame(() => container.classList.add('loaded'));
                }

                // 3. 进入 slide 时异步检测视频尺寸，决定是否显示全屏按钮
                if (window.app && typeof app.detectLandscapeBtnForSlide === 'function') {
                    app.detectLandscapeBtnForSlide(currentSlide);
                }

                if (isFastScroll) {
                    // === 快速滑动模式 ===
                    // 策略：只加载当前页的封面图，不加载视频流，不预加载下一页
                    // 这样可以极大减少网络阻塞和卡顿
                    this.processSlide(currentSlide, 'poster-only');

                    // 快速清理远离的资源
                    this.cleanup(slides, activeIndex, 2);
                } else {
                    // === 正常浏览模式 ===

                    // A. 当前页：完全激活 (加载视频、原图)
                    this.processSlide(currentSlide, 'active');

                    // B. 下一页：预加载 (延迟执行，优先保证当前页带宽)
                    if (activeIndex + 1 < total) {
                        // 使用 setTimeout 将预加载任务放入宏任务队列，让当前视频先开始缓冲
                        setTimeout(() => {
                            this.processSlide(slides[activeIndex + 1], 'preload');
                        }, 500);
                    }

                    // C. 清理更远的资源
                    this.cleanup(slides, activeIndex, CONFIG.UNLOAD_DISTANCE || 3);
                }
            }

            processSlide(slide, state) {
                const video = slide.querySelector('video');
                const gallerySwiper = slide.querySelector('.gallery-swiper');
                const audio = slide.querySelector('audio.bgm-audio');
                const poster = slide.querySelector('.lazy-media'); // 封面图

                if (state === 'poster-only') {
                    // 只加载封面，不加载视频实体
                    if (poster && poster.tagName === 'IMG' && !poster.classList.contains('video-player')) {
                        this.imgLoader.loadImage(poster, 'high');
                    }
                    if (video) {
                        // 确保视频不加载
                        video.removeAttribute('src');
                        video.load();
                    }
                }
                else if (state === 'active') {
                    // 激活：加载视频并播放
                    if (video) this.videoLoader.activate(video);

                    this.imgLoader.activateSlide(slide);

                    // 图集加载
                    if (gallerySwiper && gallerySwiper.swiper) {
                        this.imgLoader.loadGalleryBatch(gallerySwiper.swiper, true); // 强制加载当前图集
                    }
                }
                else if (state === 'preload') {
                    // 预加载：仅缓冲 Metadata 或首帧
                    if (video) this.videoLoader.preload(video);
                    this.imgLoader.preloadSlide(slide);
                    if (audio) audio.preload = "auto";
                }
            }

            cleanup(slides, activeIndex, distance) {
                for (let i = 0; i < slides.length; i++) {
                    if (Math.abs(i - activeIndex) > distance) {
                        const slide = slides[i];
                        const video = slide.querySelector('video');

                        // 移除视觉类，以便下次滑回来时重新触发渐入
                        const container = slide.querySelector('.media-container');
                        if (container) container.classList.remove('loaded');
                        slide.classList.remove('processed');

                        if (video) this.videoLoader.unload(video);
                        this.imgLoader.unload(slide);
                    }
                }
            }

            onGallerySlideChange(gallerySwiper) {
                // 图集内部滑动逻辑保持不变
                const currentIndex = gallerySwiper.realIndex;
                if (currentIndex >= 2) {
                    this.imgLoader.loadGalleryBatch(gallerySwiper, true);
                } else if (currentIndex >= 1) {
                    this.imgLoader.loadGalleryBatch(gallerySwiper, false);
                }
            }
        }
        // --- 1.4 听歌识曲控制器 ---
