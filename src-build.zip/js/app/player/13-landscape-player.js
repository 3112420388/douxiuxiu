/* v3 semantic split: class from js/app/04-data-media-landscape.js | keep script order */
class LandscapePlayer {
    constructor() {
        this.root = null;
        this.playerWrapper = null;
        this.video = null;
        this.image = null;
        this.uiLayer = null;
        this.sidePanel = null;
        this.sideTitle = null;
        this.sideBody = null;
        this.sideFooter = null;
        this.sourceVideo = null;
        this.landscapeBgmAudio = null;
        this.activePanel = null;
        this.chatHost = null;
        this.chatPlaceholder = null;
        this.chatOriginalParent = null;
        this.chatOriginalNext = null;
        this.musicContentHost = null;
        this.musicContentOriginalParent = null;
        this.musicContentOriginalNext = null;

        this.isActive = false;
        this.isSeeking = false;
        this.uiTimer = null;
        this.loopTimer = null;
        this.toastTimer = null;
        this.galleryTimer = null;
        this.galleryImages = [];
        this.galleryIndex = 0;
        this.isGallery = false;
        this.galleryPaused = false;
        this.galleryProgress = null;
        this.galleryStepStartedAt = 0;
        this.galleryStepDuration = 0;
        this.lastLandscapeMiniSync = 0;

        this.brightness = 1.0;
        this.currentData = null; // 当前播放的数据对象

        this._onResize = this._onResize.bind(this);
    }

    // ================== 1. 初始化与样式构建 ==================

    init() {
        if (this.root) return;

        this._injectStyles();

        this.root = document.createElement('div');
        this.root.className = 'lp-root';

        this.playerWrapper = document.createElement('div');
        this.playerWrapper.className = 'lp-player-wrapper';

        this.video = document.createElement('video');
        this.video.className = 'lp-video';
        this.video.setAttribute('playsinline', 'true');
        this.video.setAttribute('webkit-playsinline', 'true');
        this.video.setAttribute('poster', 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');

        this.video.addEventListener('ended', () => this.onVideoEnded());
        this.video.addEventListener('waiting', () => this.showLoading(true));
        this.video.addEventListener('playing', () => this.showLoading(false));
        this.video.addEventListener('timeupdate', () => this._syncTimeUI());

        this.image = document.createElement('img');
        this.image.className = 'lp-gallery-image';
        this.image.alt = '';
        // 点击视频区域显示/隐藏UI (保持不变)
        // 注意：_bindGestures 里的 touchend 已经处理了点击，这里其实可以移除，但为了双重保险保留也无妨，只要stopPropagation即可

        this.brightnessMask = document.createElement('div');
        this.brightnessMask.className = 'lp-brightness-mask';

        this.uiLayer = document.createElement('div');
        this.uiLayer.className = 'lp-ui-layer';

        const header = document.createElement('div');
        header.className = 'lp-header';

        const backBtn = document.createElement('div');
        backBtn.className = 'lp-btn-icon';
        backBtn.innerHTML = '<i class="fa-solid fa-chevron-left"></i>';
        backBtn.onclick = (e) => { e.stopPropagation(); this.exit(); };

        // --- 核心修改：标题容器结构 ---
        const metaContainer = document.createElement('div');
        metaContainer.className = 'lp-meta-container';
        metaContainer.innerHTML = `
            <div class="lp-title-box" onclick="app.landscapePlayer.toggleTitle(event)">
                <span id="lp-title" class="lp-title-text"></span>
            </div>
            <div class="lp-author-row">
                <img id="lp-avatar" src="">
                <div id="lp-author" class="lp-name"></div>
            </div>
        `;

        const settingBtn = document.createElement('div');
        settingBtn.className = 'lp-btn-icon lp-settings-toggle';
        settingBtn.innerHTML = '<i class="fa-solid fa-gear"></i>';
        settingBtn.onclick = (e) => { e.stopPropagation(); this.openPanel('settings'); };

        header.append(backBtn, metaContainer, settingBtn);

        // --- B. 右侧互动栏 ---
        const rightSidebar = document.createElement('div');
        rightSidebar.className = 'lp-right-sidebar';
        rightSidebar.innerHTML = `
            <div class="lp-sidebar-item" id="lp-btn-like">
                <i class="fa-solid fa-heart" id="lp-like-icon"></i>
                <span id="lp-like-count">0</span>
            </div>
            <div class="lp-sidebar-item" id="lp-btn-chat">
                <i class="fa-solid fa-comment-dots"></i>
                <span id="lp-comment-count">0</span>
            </div>
            <div class="lp-sidebar-item" id="lp-btn-share">
                <i class="fa-solid fa-share"></i>
                <span>分享</span>
            </div>
            <div class="lp-sidebar-item" id="lp-btn-music">
                <i class="fa-solid fa-music"></i>
                <span>音乐</span>
            </div>
        `;
        rightSidebar.querySelector('#lp-btn-like').onclick = (e) => {
            e.stopPropagation();
            this.toggleLike();
        };
        rightSidebar.querySelector('#lp-btn-chat').onclick = (e) => {
            e.stopPropagation();
            this.openPanel('chat');
        };
        rightSidebar.querySelector('#lp-btn-share').onclick = (e) => {
            e.stopPropagation();
            this.openPanel('share');
        };
        rightSidebar.querySelector('#lp-btn-music').onclick = (e) => {
            e.stopPropagation();
            this.openPanel('music');
        };

        // --- C. 中间控制区 ---
        this.centerControls = document.createElement('div');
        this.centerControls.className = 'lp-center-controls';

        const prevBtn = document.createElement('div');
        prevBtn.className = 'lp-ctrl-btn side';
        prevBtn.innerHTML = '<i class="fa-solid fa-backward-step"></i>';
        prevBtn.onclick = (e) => { e.stopPropagation(); this.switchVideo('prev'); };

        this.playPauseBtnBig = document.createElement('div');
        this.playPauseBtnBig.className = 'lp-ctrl-btn main';
        this.playPauseBtnBig.innerHTML = '<i class="fa-solid fa-play"></i>';
        this.playPauseBtnBig.onclick = (e) => { e.stopPropagation(); this.togglePlay(); };

        const nextBtn = document.createElement('div');
        nextBtn.className = 'lp-ctrl-btn side';
        nextBtn.innerHTML = '<i class="fa-solid fa-forward-step"></i>';
        nextBtn.onclick = (e) => { e.stopPropagation(); this.switchVideo('next'); };

        this.centerControls.append(prevBtn, this.playPauseBtnBig, nextBtn);

        // --- D. 底部进度栏 ---
        const footer = document.createElement('div');
        footer.className = 'lp-footer';

        this.timeCurrent = document.createElement('span');
        this.timeCurrent.innerText = "00:00";
        this.timeCurrent.className = 'lp-time';

        this.progressBar = document.createElement('input');
        this.progressBar.type = 'range';
        this.progressBar.className = 'lp-progress';
        this.progressBar.min = 0; this.progressBar.max = 100; this.progressBar.step = 0.1;

        this.progressBar.oninput = (e) => {
            this.isSeeking = true;
            this.showUI();
            const pct = e.target.value / 100;
            this.progressBar.style.setProperty('--lp-progress-pct', `${e.target.value}%`);
            if (this.isGallery) {
                const idx = Math.round(pct * Math.max(0, this.galleryImages.length - 1));
                this.galleryIndex = idx;
                this._renderGalleryImage();
                return;
            }
            if (this.video.duration) {
                this.timeCurrent.innerText = app.mediaManager.formatTime(pct * this.video.duration);
            }
        };
        this.progressBar.onchange = (e) => {
            if (this.isGallery) {
                this._syncSourceGallery();
                this.isSeeking = false;
                this._markGalleryInteraction();
                return;
            }
            if (this.video.duration) {
                this.video.currentTime = (e.target.value / 100) * this.video.duration;
            }
            this.isSeeking = false;
            this.resetHideTimer();
        };

        this.timeTotal = document.createElement('span');
        this.timeTotal.innerText = "00:00";
        this.timeTotal.className = 'lp-time';

        this.galleryProgress = document.createElement('div');
        this.galleryProgress.className = 'lp-gallery-progress';
        this.galleryProgress.style.display = 'none';

        footer.append(this.timeCurrent, this.progressBar, this.galleryProgress, this.timeTotal);

        // --- E. 辅助组件 ---
        this.toast = document.createElement('div');
        this.toast.className = 'lp-toast';

        this.settingsPanel = document.createElement('div');
        this.settingsPanel.className = 'lp-settings-panel';
        this._buildSettingsContent();

        this.sidePanel = document.createElement('aside');
        this.sidePanel.className = 'lp-side-panel';
        this.sidePanel.innerHTML = `
            <div class="lp-panel-header">
                <div class="lp-panel-title">面板</div>
                <div class="lp-panel-close" data-clickable><i class="fa-solid fa-xmark"></i></div>
            </div>
            <div class="lp-panel-body"></div>
            <div class="lp-panel-footer" style="display:none;"></div>
        `;
        this.sideTitle = this.sidePanel.querySelector('.lp-panel-title');
        this.sideBody = this.sidePanel.querySelector('.lp-panel-body');
        this.sideFooter = this.sidePanel.querySelector('.lp-panel-footer');
        this.sidePanel.querySelector('.lp-panel-close').onclick = (e) => {
            e.stopPropagation();
            this.closePanel();
        };

        this.loadingEl = document.createElement('div');
        this.loadingEl.className = 'lp-loading';
        this.loadingEl.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

        this.uiLayer.append(header, rightSidebar, this.centerControls, footer);
        this.playerWrapper.append(this.video, this.image, this.brightnessMask, this.uiLayer, this.toast, this.loadingEl);
        this.root.append(this.playerWrapper, this.sidePanel);
        document.body.appendChild(this.root);

        this._bindGestures();
    }
    _injectStyles() {
        if (document.getElementById('lp-styles')) return;
        const style = document.createElement('style');
        style.id = 'lp-styles';
        style.innerHTML = `
        /* 1. 根容器改为 Flex 布局 */
        .lp-root {
            position: fixed; top: 0; left: 0;
            background-color: #000; z-index: 99999; display: none;
            overflow: hidden; transform-origin: center center;
            /* 关键：使用 Flex 布局管理左右分栏 */
            flex-direction: row; 
        }

        /* 2. 播放器包裹层 (左侧区域) */
        .lp-player-wrapper {
            position: relative;
            flex: 1 1 auto; /* 默认占满剩余空间 */
            min-width: 0;
            height: 100%;
            overflow: hidden;
            transition: width 0.32s cubic-bezier(0.2, 0.8, 0.2, 1), flex-basis 0.32s cubic-bezier(0.2, 0.8, 0.2, 1);
            background: #000;
        }

        /* 视频和UI层现在相对于 player-wrapper 定位 */
        .lp-video,
        .lp-gallery-image { width: 100%; height: 100%; object-fit: contain; display: block; background: #000; }
        .lp-gallery-image { display: none; user-select: none; -webkit-user-drag: none; }
        .lp-brightness-mask {
            position: absolute; inset: 0; background: #000; opacity: 0; pointer-events: none; z-index: 8;
        }
        .lp-ui-layer {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            display: flex; flex-direction: column; justify-content: space-between;
            background: linear-gradient(to bottom, rgba(0,0,0,0.6) 0%, transparent 15%, transparent 85%, rgba(0,0,0,0.8) 100%);
            transition: opacity 0.3s; z-index: 10; pointer-events: none;
        }
        /* 恢复UI内部点击 */
        .lp-ui-layer > * { pointer-events: auto; }

        /* 3. 右侧侧边栏 (评论/分享) */
        .lp-side-panel {
            width: 0;
            height: 100%;
            background: #111;
            border-left: 1px solid rgba(255,255,255,0.1);
            overflow: hidden;
            transform: translateX(100%);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.32s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.2s ease, visibility 0.2s ease;
            display: flex; flex-direction: column;
            flex: 0 0 0;
            box-shadow: -18px 0 40px rgba(0,0,0,0.35);
        }

        /* 激活状态：侧边栏展开 */
        .lp-root.split-mode .lp-side-panel {
            width: clamp(260px, 25vw, 360px);
            flex-basis: clamp(260px, 25vw, 360px);
            transform: translateX(0);
            opacity: 1;
            visibility: visible;
        }
        
        /* 移动端适配：如果是竖屏手机旋转过来的，宽度占比稍微大一点 */
        @media (max-height: 500px) {
            .lp-root.split-mode .lp-side-panel {
                width: 25vw;
                flex-basis: 25vw;
            }
        }

        /* --- 侧边栏内部样式 --- */
        .lp-panel-header {
            height: 54px; display: flex; align-items: center; justify-content: space-between;
            padding: 0 16px; border-bottom: 1px solid rgba(255,255,255,0.08); color: #fff; font-size: 15px; font-weight: bold;
            flex: 0 0 54px;
        }
        .lp-panel-close { cursor: pointer; padding: 10px; color: #ccc; }
        .lp-panel-body { flex: 1; min-height: 0; overflow: hidden; display: flex; flex-direction: column; }
        .lp-panel-scroll { flex: 1; min-height: 0; overflow-y: auto; padding: 14px; }
        
        /* 评论输入框区域 */
        .lp-panel-footer {
            padding: 10px; border-top: 1px solid rgba(255,255,255,0.1); background: rgba(0,0,0,0.3);
            display: flex; gap: 10px;
        }
        .lp-input {
            flex: 1; background: rgba(255,255,255,0.1); border: none; border-radius: 18px;
            height: 36px; padding: 0 15px; color: #fff; font-size: 13px; outline: none;
        }
        
        /* 评论列表项 */
        .lp-comment-item { display: flex; gap: 10px; margin-bottom: 15px; }
        .lp-comment-avatar { width: 32px; height: 32px; border-radius: 50%; background: #333; flex-shrink: 0; }
        .lp-comment-info { flex: 1; font-size: 13px; }
        .lp-comment-user { color: #888; font-size: 12px; margin-bottom: 2px; }
        .lp-comment-text { color: #ddd; line-height: 1.4; }

        /* 分享网格 */
        .lp-share-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; }
        .lp-share-item { display: flex; flex-direction: column; align-items: center; gap: 8px; cursor: pointer; color: #ccc; font-size: 12px; }
        .lp-share-icon { 
            width: 48px; height: 48px; border-radius: 12px; background: rgba(255,255,255,0.1); 
            display: flex; align-items: center; justify-content: center; font-size: 24px; color: #fff;
            transition: background 0.2s;
        }
        .lp-share-item:active .lp-share-icon { background: rgba(255,255,255,0.2); }
        .lp-download-actions { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; padding: 10px; border-top: 1px solid rgba(255,255,255,0.08); }
        .lp-action-btn {
            height: 34px; min-width: 0; border-radius: 8px; display: flex; align-items: center; justify-content: center; gap: 6px;
            background: rgba(255,255,255,0.1); color: #fff; font-size: 12px; cursor: pointer; user-select: none;
            white-space: nowrap; overflow: hidden;
        }
        .lp-action-btn i { font-size: 13px; flex: 0 0 auto; }
        .lp-action-btn span { min-width: 0; overflow: hidden; text-overflow: ellipsis; }
        .lp-action-btn.primary { background: #5cc9ff; color: #051018; font-weight: 700; }
        .lp-action-btn:active { transform: scale(0.98); }
        .lp-panel-body .chat-container { height: 100%; flex: 1; min-height: 0; background: transparent !important; }
        .lp-panel-body .chat-list { padding: 12px !important; }
        .lp-panel-body .comment-input-bar {
            flex-shrink: 0; padding: 8px; display: grid !important;
            grid-template-columns: 28px 28px minmax(0, 1fr) 48px; gap: 6px; align-items: center;
            width: 100%; box-sizing: border-box;
        }
        .lp-panel-body .chat-tool-btn {
            width: 28px; height: 32px; display: flex; align-items: center; justify-content: center;
            margin: 0 !important; flex: 0 0 auto; font-size: 16px;
        }
        .lp-panel-body .c-input {
            width: 100% !important; min-width: 0; height: 34px; box-sizing: border-box;
            padding: 0 10px; font-size: 12px;
        }
        .lp-panel-body .c-btn {
            width: 48px; min-width: 48px; height: 34px; padding: 0; font-size: 12px;
            display: flex; align-items: center; justify-content: center; flex: 0 0 auto;
        }
        .lp-panel-body .dl-grid-container { flex: 1; min-height: 0; overflow-y: auto; padding: 12px; }
        .lp-panel-body .dl-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }
        .lp-panel-body .dl-item { aspect-ratio: 1 / 1.25; border-radius: 8px; overflow: hidden; }
        .lp-panel-body .lp-settings-panel {
            position: static; width: 100%; height: auto; transform: none !important; background: transparent;
            backdrop-filter: none; padding: 16px; z-index: auto; overflow-y: auto; flex: 1;
        }
            
            /* 头部样式 */
            .lp-header {
                display: flex; align-items: flex-start; padding: 20px 30px; gap: 15px; color: #fff;
                height: 80px; box-sizing: border-box; flex-shrink: 0; pointer-events: none;
            }
            .lp-btn-icon {
                font-size: 18px; cursor: pointer; width: 36px; height: 36px;
                display: flex; align-items: center; justify-content: center;
                background: rgba(255,255,255,0.15); border-radius: 50%;
                backdrop-filter: blur(5px); pointer-events: auto; flex-shrink: 0;
            }
            
            /* 标题容器 */
            .lp-meta-container {
                flex: 1; display: flex; flex-direction: column; justify-content: center;
                margin-top: 5px; overflow: visible; pointer-events: auto; min-width: 0; position: relative;
            }
            .lp-title-box {
                position: relative; width: 100%; transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            }
            .lp-title-text {
                font-size: 15px; font-weight: bold;
                white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
                text-shadow: 0 1px 3px rgba(0,0,0,0.8); line-height: 1.4; color: #fff;
            }
            .lp-expand-btn {
                display: inline-block; font-size: 12px; color: rgba(255,255,255,0.7); 
                margin-left: 8px; cursor: pointer; background: rgba(255,255,255,0.1); 
                padding: 1px 6px; border-radius: 4px; vertical-align: middle;
            }
        
        /* === 核心修改：展开后的样式 === */
        .lp-title-box.expanded {
            /* 使用 fixed 脱离顶部 header 文档流，相对于 lp-root 定位 */
            position: fixed; 
            top: 60px; 
            left: 20px; 
            /* 宽度：预留右侧按钮空间 (右侧栏约占 80px) */
            width: calc(100% - 100px); 
            max-width: 650px; /* 大屏限制最大宽 */
            
            /* 高度核心限制：屏幕高度 - 顶部间距 - 底部进度条区域(约90px) */
            max-height: calc(100% - 110px);
            background: rgba(15,15,15,0.5);
            backdrop-filter: blur(20px); 
            -webkit-backdrop-filter: blur(20px);
            
            padding: 16px 20px; 
            border-radius: 16px; 
            z-index: 999; /* 确保在最上层 */
            
            box-shadow: 0 10px 40px rgba(0,0,0,0.8); 
            border: 1px solid rgba(255,255,255,0.1);
            
            display: flex;
            flex-direction: column;
            
            /* 动画优化 */
            will-change: transform, opacity;
            transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        .lp-title-text {
            font-size: 15px; font-weight: bold;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
            text-shadow: 0 1px 3px rgba(0,0,0,0.8); line-height: 1.4; color: #fff;
        }

     .lp-title-box.expanded .lp-title-text {
    white-space: normal !important;
    overflow: auto !important;
    max-height: calc(100vh - 150px);
    padding-right: 10px;
    line-height: 1.6;
}

        .lp-title-box.expanded::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 20px;
            background: linear-gradient(to top, rgba(15,15,15,0.9), transparent);
            border-radius: 0 0 16px 16px;
            pointer-events: none;
        }
            .lp-author-row {
                display: flex; align-items: center; gap: 8px; width: 100%; overflow: hidden;
            }
            #lp-avatar {
                width: 24px; height: 24px; border-radius: 50%; border: 1px solid rgba(255,255,255,0.6); object-fit: cover; flex-shrink: 0;
            }
            .lp-name {
                font-size: 12px; color: #ddd; font-weight: 500; text-shadow: 0 1px 2px rgba(0,0,0,0.8);
                white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
            }

            /* 右侧边栏 */
            .lp-right-sidebar {
                position: absolute; right: 25px; top: 50%; transform: translateY(-50%);
                display: flex; flex-direction: column; gap: 25px; align-items: center; pointer-events: auto;
                transition: right 0.32s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.2s ease;
            }
            .lp-root.split-mode .lp-right-sidebar {
                opacity: 0;
                pointer-events: none;
                transform: translateY(-50%) translateX(12px);
            }
            .lp-root.split-mode .lp-settings-toggle {
                opacity: 0;
                pointer-events: none;
            }
            .lp-sidebar-item {
                display: flex; flex-direction: column; align-items: center; gap: 4px; cursor: pointer;
            }
            .lp-sidebar-item:active { transform: scale(0.9); }
            .lp-sidebar-item i {
                font-size: 20px; color: #fff; text-shadow: 0 2px 5px rgba(0,0,0,0.5); transition: color 0.2s;
            }
            .lp-sidebar-item span {
                font-size: 11px; color: #fff; text-shadow: 0 1px 2px rgba(0,0,0,0.5); font-weight: 500;
            }

            /* 中间控制 */
            .lp-center-controls {
                position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
                display: flex; align-items: center; gap: 50px; pointer-events: auto;
            }
            .lp-ctrl-btn {
                display: flex; align-items: center; justify-content: center; cursor: pointer; color: #fff;
                opacity: 0.9; transition: transform 0.1s; filter: drop-shadow(0 2px 5px rgba(0,0,0,0.5));
            }
            .lp-ctrl-btn:active { transform: scale(0.9); }
            .lp-ctrl-btn.side { font-size: 32px; opacity: 0.8; }
            
            /* === 核心修改：去除中间按钮背景 === */
            .lp-ctrl-btn.main { 
                font-size: 70px; /* 稍微放大 */
                width: 80px; height: 80px; 
                background: transparent; /* 透明 */
                border-radius: 50%; 
            }
            
            /* 底部 */
            .lp-footer {
                display: flex; align-items: center; padding: 12px 22px 22px 22px; gap: 8px; color: #fff; flex-shrink: 0; pointer-events: auto;
                background: linear-gradient(to top, rgba(0,0,0,0.45), transparent);
            }
            .lp-time { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 11px; opacity: 0.95; min-width: 38px; text-align: center; text-shadow: 0 1px 3px rgba(0,0,0,0.7); }
            .lp-progress {
                --lp-progress-pct: 0%;
                flex: 1; height: 12px; appearance: none; -webkit-appearance: none;
                background: transparent; outline: none; cursor: pointer; border-radius: 999px;
            }
            .lp-progress::-webkit-slider-runnable-track {
                height: 4px; border-radius: 999px;
                background: linear-gradient(90deg, rgba(255,255,255,0.85) 0%, rgba(255,255,255,0.85) var(--lp-progress-pct), rgba(255,255,255,0.35) var(--lp-progress-pct), rgba(255,255,255,0.35) 100%);
                box-shadow: inset 0 0 0 1px rgba(255,255,255,0.12);
            }
            .lp-progress::-webkit-slider-thumb {
                -webkit-appearance: none; width: 0; height: 0; margin-top: 0; border: none; background: transparent; box-shadow: none;
            }
            .lp-progress::-webkit-slider-thumb:active { transform: none; }
            .lp-progress::-moz-range-track { height: 4px; border-radius: 999px; background: rgba(255,255,255,0.35); }
            .lp-progress::-moz-range-progress { height: 4px; border-radius: 999px; background: rgba(255,255,255,0.85); }
            .lp-progress::-moz-range-thumb { width: 0; height: 0; border: none; background: transparent; box-shadow: none; }
            .lp-gallery-progress {
                flex: 1; height: 10px; display: flex; align-items: center; gap: 4px; min-width: 0;
            }
            .lp-gallery-segment {
                flex: 1; height: 4px; border-radius: 999px; overflow: hidden;
                background: rgba(255,255,255,0.28); cursor: pointer; min-width: 8px;
                box-shadow: inset 0 0 0 1px rgba(255,255,255,0.08);
            }
            .lp-gallery-segment-fill {
                display: block; width: 0%; height: 100%; border-radius: inherit;
                background: rgba(255,255,255,0.92); transition: width 0.18s ease;
            }
            .lp-gallery-segment.done .lp-gallery-segment-fill { width: 100%; }
            .lp-gallery-segment.active .lp-gallery-segment-fill { width: var(--lp-gallery-active-pct, 0%); }
            .lp-music-panel { padding: 18px; color: #fff; display: flex; flex-direction: column; gap: 16px; }
            .lp-music-cover {
                width: 150px; height: 150px; border-radius: 12px; overflow: hidden; align-self: center;
                background: rgba(255,255,255,0.08); display: flex; align-items: center; justify-content: center;
                font-size: 46px; color: rgba(255,255,255,0.55);
            }
            .lp-music-cover img { width: 100%; height: 100%; object-fit: cover; display: block; }
            .lp-music-meta { text-align: center; min-width: 0; }
            .lp-music-title { font-size: 18px; font-weight: 700; line-height: 1.35; overflow-wrap: anywhere; }
            .lp-music-author { margin-top: 5px; font-size: 13px; color: rgba(255,255,255,0.62); overflow-wrap: anywhere; }
            .lp-music-progress { display: flex; align-items: center; gap: 8px; font-size: 11px; color: rgba(255,255,255,0.72); }
            .lp-music-track { flex: 1; height: 4px; border-radius: 999px; overflow: hidden; background: rgba(255,255,255,0.22); }
            .lp-music-track span { display: block; width: 0%; height: 100%; background: #fff; border-radius: inherit; }
            .lp-music-actions { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
            .lp-music-btn {
                border: 0; border-radius: 8px; background: rgba(255,255,255,0.12); color: #fff;
                padding: 10px 8px; display: flex; flex-direction: column; align-items: center; gap: 6px;
                font-size: 12px; cursor: pointer;
            }
            .lp-music-empty { color: rgba(255,255,255,0.55); text-align: center; font-size: 13px; }
            .lp-mounted-music-content {
                width: 100%; height: 100%; min-height: 0; padding: 16px;
                box-sizing: border-box; color: #fff; background: transparent;
            }
            .lp-mounted-music-content .music-mini-player { max-width: 100%; }
            .lp-mounted-music-content .music-actions-grid { margin-top: 0; }
            /* 辅助层 */
            .lp-toast {
                position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
                background: rgba(0,0,0,0.7); padding: 12px 20px; border-radius: 8px;
                display: flex; flex-direction: row; gap: 10px; align-items: center; color: #fff;
                pointer-events: none; opacity: 0; transition: opacity 0.2s; z-index: 30;
                backdrop-filter: blur(5px);
            }
            .lp-settings-panel {
                position: absolute; top: 0; right: 0; width: 280px; height: 100%;
                background: rgba(0,0,0,0.85); backdrop-filter: blur(10px);
                transform: translateX(100%); transition: transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1);
                display: flex; flex-direction: column; padding: 30px; box-sizing: border-box; z-index: 40; pointer-events: auto;
            }
            .lp-loading {
                position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
                pointer-events: none; display: none; z-index: 5; font-size: 40px; color: rgba(255,255,255,0.8);
            }
        `;
        document.head.appendChild(style);
    }
    _buildSettingsContent() {
        const createGroup = (title, items, action) => {
            const group = document.createElement('div');
            group.style.marginBottom = '25px';
            const label = document.createElement('div');
            label.innerText = title;
            label.style.cssText = "color: #888; font-size: 12px; margin-bottom: 10px;";
            const row = document.createElement('div');
            row.style.cssText = "display: flex; flex-wrap: wrap; gap: 10px;";
            items.forEach(item => {
                const btn = document.createElement('div');
                btn.innerText = item.text;
                btn.dataset.val = item.val;
                btn.style.cssText = "padding: 6px 14px; border-radius: 20px; font-size: 13px; color: #fff; background: rgba(255,255,255,0.15); cursor: pointer; transition: all 0.2s;";
                btn.onclick = (e) => {
                    e.stopPropagation();
                    Array.from(row.children).forEach(b => {
                        b.style.color = '#fff'; b.classList.remove('active');
                    });
                    btn.style.background = '#5cc9ff'; btn.style.color = '#000'; btn.classList.add('active');
                    action(item.val);
                };
                row.appendChild(btn);
            });
            group.append(label, row);
            return group;
        };
        this.settingsPanel.appendChild(createGroup('播放速度', [
            { text: '0.75x', val: 0.75 }, { text: '1.0x', val: 1.0 }, { text: '1.25x', val: 1.25 }, { text: '1.5x', val: 1.5 }, { text: '2.0x', val: 2.0 }
        ], (v) => this.setSpeed(v)));
        this.settingsPanel.appendChild(createGroup('画面尺寸', [
            { text: '适应', val: 'contain' }, { text: '铺满', val: 'cover' }, { text: '拉伸', val: 'fill' }
        ], (v) => this.setFit(v)));
    }

    openPanel(type) {
        this.init();
        if (this.activePanel === type && this.root.classList.contains('split-mode')) {
            this.closePanel();
            return;
        }

        this._restoreChatHost();
        this._restoreMusicManageContent();
        this.sideBody.replaceChildren();
        this.sideFooter.replaceChildren();
        this.sideFooter.style.display = 'none';
        this.sideFooter.className = 'lp-panel-footer';

        this.activePanel = type;
        this.root.classList.add('split-mode');
        this.showUI();
        if (this.uiTimer) clearTimeout(this.uiTimer);

        if (type === 'chat') {
            this.sideTitle.innerText = '聊天室';
            this._mountChatPanel();
        } else if (type === 'share') {
            this.sideTitle.innerText = '分享/下载';
            this._renderSharePanel();
        } else if (type === 'music') {
            this.sideTitle.innerText = '音乐';
            this._mountMusicManagePanel();
        } else {
            this.sideTitle.innerText = '播放设置';
            this.sideBody.appendChild(this.settingsPanel);
            this._updateSettingsUI();
        }
    }

    closePanel() {
        if (!this.root) return;
        this._restoreChatHost();
        this._restoreMusicManageContent();
        this.root.classList.remove('split-mode');
        this.activePanel = null;
        this.sideBody.replaceChildren();
        this.sideFooter.replaceChildren();
        this.sideFooter.style.display = 'none';
        this.sideFooter.className = 'lp-panel-footer';
        this.resetHideTimer();
    }

    _mountChatPanel() {
        const chat = document.querySelector('#comment-layer .chat-container');
        if (!chat) {
            this.sideBody.innerHTML = '<div class="lp-panel-scroll" style="color:#aaa;">聊天室暂不可用</div>';
            return;
        }
        this.chatHost = chat;
        this.chatOriginalParent = chat.parentNode;
        this.chatOriginalNext = chat.nextSibling;
        this.chatPlaceholder = document.createComment('landscape-chat-placeholder');
        this.chatOriginalParent.insertBefore(this.chatPlaceholder, chat);
        document.getElementById('comment-layer')?.classList.remove('active');
        this.sideBody.appendChild(chat);
        if (app.chat) app.chat.checkLogin();
        setTimeout(() => {
            const list = document.getElementById('chat-list');
            if (list) list.scrollTop = list.scrollHeight;
        }, 50);
    }

    _restoreChatHost() {
        if (!this.chatHost || !this.chatOriginalParent) return;
        if (this.chatOriginalNext && this.chatOriginalNext.parentNode === this.chatOriginalParent) {
            this.chatOriginalParent.insertBefore(this.chatHost, this.chatOriginalNext);
        } else if (this.chatPlaceholder && this.chatPlaceholder.parentNode === this.chatOriginalParent) {
            this.chatOriginalParent.insertBefore(this.chatHost, this.chatPlaceholder);
        } else {
            this.chatOriginalParent.appendChild(this.chatHost);
        }
        if (this.chatPlaceholder && this.chatPlaceholder.parentNode) {
            this.chatPlaceholder.parentNode.removeChild(this.chatPlaceholder);
        }
        this.chatHost = null;
        this.chatPlaceholder = null;
        this.chatOriginalParent = null;
        this.chatOriginalNext = null;
    }

    _mountMusicManagePanel() {
        const content = document.getElementById('music-manage-content');
        if (!content || !app.renderer || !app.pageManager) {
            this._renderMusicPanel();
            return;
        }

        const data = this.currentData || (app.fullPlaylist && app.fullPlaylist[app.mainSwiper?.activeIndex]) || {};
        const music = data.music_info || {};
        if (!music.url && !music.title && app.interaction) {
            app.interaction.showToast('\u8be5\u4f5c\u54c1\u6682\u65e0\u6709\u6548\u97f3\u4e50\u4fe1\u606f');
        }

        this._setLandscapeAudioMode('music');
        const musicPage = document.getElementById('music-manage-page');
        const wasMusicPageActive = !!(musicPage && musicPage.classList.contains('active'));
        if (musicPage) musicPage.classList.add('active');
        app.renderer.renderMusicPage(music);
        app.pageManager.refreshMusicInfo(data);

        if (!this.musicContentHost) {
            this.musicContentHost = content;
            this.musicContentOriginalParent = content.parentNode;
            this.musicContentOriginalNext = content.nextSibling;
        }

        if (musicPage && !wasMusicPageActive) musicPage.classList.remove('active');
        content.classList.add('lp-mounted-music-content');
        this.sideBody.appendChild(content);

        if (app.mediaManager) {
            app.mediaManager.refreshMusicPageRefs(true);
            const media = app.mediaManager.currentMedia;
            if (media && media.duration && app.mediaManager._syncMusicPageUI) {
                app.mediaManager._syncMusicPageUI(media.currentTime || 0, ((media.currentTime || 0) / media.duration) * 100);
            }
            this._syncLandscapeMiniPreview(true);
        }
    }

    _restoreMusicManageContent() {
        if (!this.musicContentHost || !this.musicContentOriginalParent) return;
        this.musicContentHost.classList.remove('lp-mounted-music-content');
        if (this.musicContentOriginalNext && this.musicContentOriginalNext.parentNode === this.musicContentOriginalParent) {
            this.musicContentOriginalParent.insertBefore(this.musicContentHost, this.musicContentOriginalNext);
        } else {
            this.musicContentOriginalParent.appendChild(this.musicContentHost);
        }
        this.musicContentHost = null;
        this.musicContentOriginalParent = null;
        this.musicContentOriginalNext = null;
        this._setLandscapeAudioMode('default');
        if (app.mediaManager) app.mediaManager.refreshMusicPageRefs(true);
    }

    _getActiveSlideAudio() {
        const slide = app.mainSwiper?.slides?.[app.mainSwiper.activeIndex] || null;
        const audio = slide ? slide.querySelector('.bgm-audio') : null;
        return { slide, audio };
    }

    _syncAudioToLandscapeVideo(audio) {
        if (!audio || this.isGallery || !this.video) return;
        const videoTime = this.video.currentTime || 0;
        if (Math.abs((audio.currentTime || 0) - videoTime) > 0.35) {
            try { audio.currentTime = videoTime; } catch (e) { /* ignore */ }
        }
    }

    _syncLandscapeVideoToAudio(audio) {
        if (!audio || this.isGallery || !this.video) return;
        const audioTime = audio.currentTime || 0;
        if (Math.abs((this.video.currentTime || 0) - audioTime) > 0.25) {
            try { this.video.currentTime = audioTime; } catch (e) { /* ignore */ }
        }
    }

    _setLandscapeAudioMode(mode = 'default') {
        const { audio } = this._getActiveSlideAudio();
        this.landscapeBgmAudio = audio || null;

        if (!audio) {
            if (!this.isGallery && this.video) this.video.muted = false;
            if (app.mediaManager && !this.isGallery && this.video) {
                app.mediaManager.currentMedia = this.video;
                app.mediaManager.updatePlayBtnState(!this.video.paused);
            }
            return;
        }

        if (this.isGallery) {
            audio.muted = false;
            audio.play().catch(e => console.log('Landscape gallery music play failed', e));
            if (app.mediaManager) {
                app.mediaManager.currentMedia = audio;
                app.mediaManager.updatePlayBtnState(true);
                app.mediaManager.refreshMusicPageRefs(true);
            }
            return;
        }

        this._syncAudioToLandscapeVideo(audio);

        if (mode === 'music') {
            this.video.muted = true;
            if (this.video.paused) this.video.play().catch(e => console.log('Landscape video play failed', e));
            audio.muted = false;
            audio.play().catch(e => console.log('Landscape music play failed', e));
            if (app.mediaManager) {
                app.mediaManager.currentMedia = audio;
                app.mediaManager.updatePlayBtnState(true);
                app.mediaManager.refreshMusicPageRefs(true);
            }
            return;
        }

        if (!audio.paused && Math.abs((this.video.currentTime || 0) - (audio.currentTime || 0)) > 0.35) {
            try { this.video.currentTime = audio.currentTime || this.video.currentTime; } catch (e) { /* ignore */ }
        }
        audio.muted = true;
        audio.play().catch(e => console.log('Landscape muted music play failed', e));
        this.video.muted = false;
        if (app.mediaManager) {
            app.mediaManager.currentMedia = this.video;
            app.mediaManager.updatePlayBtnState(!this.video.paused);
            app.mediaManager.refreshMusicPageRefs(true);
        }
    }

    _syncLandscapeMusicPage() {
        if (!this.isActive || this.activePanel !== 'music' || !app.mediaManager) return;
        const { audio } = this._getActiveSlideAudio();
        const media = audio || app.mediaManager.currentMedia || this.video;
        if (!media) return;

        if (!this.isGallery && audio) {
            this._syncLandscapeVideoToAudio(audio);
        }

        const duration = media.duration || 0;
        const currentTime = media.currentTime || 0;
        const pct = duration ? Math.max(0, Math.min(100, (currentTime / duration) * 100)) : 0;
        app.mediaManager.refreshMusicPageRefs();
        if (app.mediaManager._syncMusicPageUI) {
            app.mediaManager._syncMusicPageUI(currentTime, pct);
        }
        this._syncLandscapeMiniPreview();
    }

    _syncLandscapeMiniPreview(force = false) {
        if (this.activePanel !== 'music') return;
        const mediaBox = document.getElementById('music-mini-media');
        if (!mediaBox) return;

        const now = performance.now();
        if (!force && now - this.lastLandscapeMiniSync < 180) return;
        this.lastLandscapeMiniSync = now;

        if (this.isGallery) {
            const src = this.galleryImages[this.galleryIndex] || '';
            if (!src) return;
            let img = mediaBox.querySelector('img');
            if (!img || mediaBox.querySelector('video')) {
                mediaBox.innerHTML = '<img alt="" loading="eager" decoding="async">';
                img = mediaBox.querySelector('img');
            }
            if (img && img.getAttribute('src') !== src) img.src = src;
            return;
        }

        if (!this.video) return;
        let miniVideo = mediaBox.querySelector('video[data-mini-sync="true"]');
        if (!miniVideo) {
            mediaBox.innerHTML = '<video class="music-mini-video" data-mini-sync="true" muted autoplay playsinline preload="metadata"></video>';
            miniVideo = mediaBox.querySelector('video[data-mini-sync="true"]');
            if (app.mediaManager) app.mediaManager.refreshMusicPageRefs(true);
        }

        const src = this.video.currentSrc || this.video.src || '';
        if (src && miniVideo.src !== src) miniVideo.src = src;
        const targetTime = this.landscapeBgmAudio ? (this.landscapeBgmAudio.currentTime || 0) : (this.video.currentTime || 0);
        if (Math.abs((miniVideo.currentTime || 0) - targetTime) > 0.25) {
            try { miniVideo.currentTime = Math.min(targetTime, miniVideo.duration || targetTime); } catch (e) { /* ignore */ }
        }
        miniVideo.playbackRate = this.video.playbackRate || 1;
        if (this.video.paused) {
            if (!miniVideo.paused) miniVideo.pause();
        } else if (miniVideo.paused) {
            const p = miniVideo.play();
            if (p) p.catch(() => { });
        }
    }

    _renderSharePanel() {
        const data = this.currentData || (app.fullPlaylist && app.fullPlaylist[app.mainSwiper?.activeIndex]);
        const assets = app.downloadMgr ? app.downloadMgr.prepareAssets(data) : [];
        const scroll = document.createElement('div');
        scroll.className = 'dl-grid-container';
        const grid = document.createElement('div');
        grid.className = 'dl-grid';
        grid.innerHTML = assets.map((asset, index) => {
            const url = asset.url || '';
            const thumb = asset.type === 'image'
                ? `<img src="${url}">`
                : `<div class="video-placeholder"></div><div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:20px;"><i class="fa-solid fa-play"></i></div>`;
            return `<div class="dl-item selected lp-dl-item" data-index="${index}" data-clickable>${thumb}<div class="dl-checkbox active-all" data-index="${index}"></div></div>`;
        }).join('') || '<div style="color:#888; padding:16px;">未找到可下载资源</div>';
        scroll.appendChild(grid);
        this.sideBody.appendChild(scroll);

        grid.querySelectorAll('.lp-dl-item').forEach((item) => {
            item.onclick = (e) => {
                e.stopPropagation();
                item.classList.toggle('selected');
            };
        });

        this.sideFooter.className = 'lp-download-actions';
        this.sideFooter.style.display = 'grid';
        this.sideFooter.innerHTML = `
            <div class="lp-action-btn primary" id="lp-download-direct" data-clickable><i class="fa-solid fa-download"></i><span>直接下载</span></div>
            <div class="lp-action-btn" id="lp-download-zip" data-clickable><i class="fa-solid fa-file-zipper"></i><span>资源打包</span></div>
            <div class="lp-action-btn" id="lp-copy-links" data-clickable><i class="fa-solid fa-link"></i><span>复制链接</span></div>
            <div class="lp-action-btn" id="lp-share-work" data-clickable><i class="fa-solid fa-share-nodes"></i><span>分享作品</span></div>
        `;
        this.sideFooter.querySelector('#lp-download-direct').onclick = (e) => {
            e.stopPropagation();
            const selected = this._getSelectedAssetIndexes();
            if (!selected.length) return this._showToast('fa-circle-exclamation', '请先选择资源');
            app.downloadMgr.downloadDirect(selected);
        };
        this.sideFooter.querySelector('#lp-download-zip').onclick = (e) => {
            e.stopPropagation();
            const selected = this._getSelectedAssetIndexes();
            if (!selected.length) return this._showToast('fa-circle-exclamation', '请先选择资源');
            app.downloadMgr.downloadZip(selected);
        };
        this.sideFooter.querySelector('#lp-copy-links').onclick = (e) => {
            e.stopPropagation();
            const selected = this._getSelectedAssetIndexes();
            if (!selected.length) return this._showToast('fa-circle-exclamation', '请先选择资源');
            const text = app.downloadMgr.getLinks(selected);
            navigator.clipboard?.writeText(text).then(() => this._showToast('fa-link', '链接已复制')).catch(() => {
                app.interaction.copyText({ innerText: text });
            });
        };
        this.sideFooter.querySelector('#lp-share-work').onclick = (e) => {
            e.stopPropagation();
            if (app.menuManager) app.menuManager.shareCurrentWork();
        };
    }

    _escapeHtml(text) {
        return String(text || '').replace(/[&<>"']/g, (ch) => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[ch]));
    }

    _renderMusicPanel() {
        const data = this.currentData || (app.fullPlaylist && app.fullPlaylist[app.mainSwiper?.activeIndex]) || {};
        const music = data.music_info || {};
        const title = this._escapeHtml(music.title || data.music_title || '原声');
        const author = this._escapeHtml(music.author || data.music_author || '未知');
        const cover = this._escapeHtml(music.cover || data.music_cover || data.cover || data.images?.[0] || '');
        const hasMusic = !!(music.url || music.title || music.author);

        this.sideBody.innerHTML = `
            <div class="lp-music-panel">
                <div class="lp-music-cover">${cover ? `<img src="${cover}" alt="">` : '<i class="fa-solid fa-music"></i>'}</div>
                <div class="lp-music-meta">
                    <div class="lp-music-title">${title}</div>
                    <div class="lp-music-author">${author}</div>
                </div>
                <div class="lp-music-progress">
                    <span class="lp-music-current">00:00</span>
                    <div class="lp-music-track"><span></span></div>
                    <span class="lp-music-total">00:00</span>
                </div>
                <div class="lp-music-actions">
                    <button class="lp-music-btn" data-action="toggle" data-clickable><i class="fa-solid fa-pause"></i><span>播放</span></button>
                    <button class="lp-music-btn" data-action="fav" data-clickable><i class="fa-solid fa-heart"></i><span>收藏</span></button>
                    <button class="lp-music-btn" data-action="copy" data-clickable><i class="fa-solid fa-link"></i><span>链接</span></button>
                </div>
                ${hasMusic ? '' : '<div class="lp-music-empty">该作品暂无有效音乐信息</div>'}
            </div>
        `;

        this.sideBody.querySelector('[data-action="toggle"]')?.addEventListener('click', (e) => {
            e.stopPropagation();
            if (app.mediaManager) app.mediaManager.toggleCurrent();
            this._syncMusicPanel();
        });
        this.sideBody.querySelector('[data-action="fav"]')?.addEventListener('click', async (e) => {
            e.stopPropagation();
            if (!app.userDataManager || !hasMusic) return;
            const liked = await app.userDataManager.toggleMusic(music, data);
            this._showToast('fa-music', liked ? '已收藏音乐' : '已取消收藏');
        });
        this.sideBody.querySelector('[data-action="copy"]')?.addEventListener('click', (e) => {
            e.stopPropagation();
            const url = music.url || music.play_url || music.playUrl || '';
            if (!url) return this._showToast('fa-circle-exclamation', '暂无音乐链接');
            navigator.clipboard?.writeText(url).then(() => this._showToast('fa-link', '链接已复制')).catch(() => {
                app.interaction?.copyText?.({ innerText: url });
            });
        });

        this._syncMusicPanel();
    }

    _syncMusicPanel() {
        if (this.activePanel !== 'music' || !this.sideBody) return;
        const media = app.mediaManager?.currentMedia;
        const fill = this.sideBody.querySelector('.lp-music-track span');
        const curr = this.sideBody.querySelector('.lp-music-current');
        const total = this.sideBody.querySelector('.lp-music-total');
        const toggleIcon = this.sideBody.querySelector('[data-action="toggle"] i');
        if (!media) return;
        const duration = media.duration || 0;
        const pct = duration ? Math.max(0, Math.min(100, (media.currentTime / duration) * 100)) : 0;
        if (fill) fill.style.width = `${pct}%`;
        if (curr) curr.innerText = app.mediaManager.formatTime(media.currentTime || 0);
        if (total) total.innerText = duration ? app.mediaManager.formatTime(duration) : '00:00';
        if (toggleIcon) toggleIcon.className = media.paused ? 'fa-solid fa-play' : 'fa-solid fa-pause';
    }

    _getSelectedAssetIndexes() {
        return Array.from(this.sideBody.querySelectorAll('.lp-dl-item.selected'))
            .map((item) => Number(item.dataset.index))
            .filter((n) => Number.isInteger(n) && n >= 0);
    }

    // ================== 2. 核心控制 ==================
    enter(sourceVideo, data) {
        if (!sourceVideo && !this._hasGalleryImages(data)) return;
        this.init();

        this.sourceVideo = sourceVideo;
        this.currentData = data;
        this.isActive = true;
        this.isGallery = this._hasGalleryImages(data);
        this.galleryPaused = false;
        this._clearGalleryTimer();

        // 1. 同步媒体状态
        if (this.isGallery) {
            this.video.pause();
            this.video.style.display = 'none';
            this.image.style.display = 'block';
            this.galleryImages = (data.images || []).map((img) => this._getImageUrl(img)).filter(Boolean);
            this.galleryIndex = this._getSourceGalleryIndex() || 0;
            if (this.galleryProgress) this.galleryProgress.innerHTML = '';
            this._renderGalleryImage();
        } else {
            const currentSrc = sourceVideo.currentSrc || sourceVideo.src;
            if (this.video.src !== currentSrc) this.video.src = currentSrc;
            this.video.currentTime = sourceVideo.currentTime;
            this.video.volume = sourceVideo.volume;
            this.video.muted = false;
            this.video.playbackRate = sourceVideo.playbackRate;
            this.video.style.display = 'block';
            this.image.style.display = 'none';
            this.galleryImages = [];
            this.galleryIndex = 0;
            if (this.galleryProgress) {
                this.galleryProgress.style.display = 'none';
                this.galleryProgress.innerHTML = '';
            }
            this.progressBar.style.display = '';
        }

        // 2. 填充标题 (带展开逻辑)
        const titleBox = this.root.querySelector('.lp-title-box');
        const titleText = this.root.querySelector('#lp-title');

        // 重置样式
        titleBox.classList.remove('expanded');

        const fullTitle = data.title || '无标题';

        // 判断长度 (超过 25 字显示展开按钮)
        if (fullTitle.length > 25) {
            // 记录完整和简略标题
            titleBox.dataset.fullTitle = fullTitle;
            titleBox.dataset.shortTitle = fullTitle.substring(0, 25) + '...';
            // 初始显示简略版
            titleText.innerHTML = `${titleBox.dataset.shortTitle} <span class="lp-expand-btn">展开</span>`;
        } else {
            titleText.innerHTML = fullTitle;
            delete titleBox.dataset.fullTitle;
        }

        // 3. 填充作者信息
        document.getElementById('lp-author').innerText = data.author || '未知';

        // --- 核心修复：头像获取逻辑 ---
        let avatar = data.avatar;
        // 尝试从全局创作者数据中查找头像
        if (!avatar && window.app && app.dataLoader && app.dataLoader.globalCreators) {
            const creator = app.dataLoader.globalCreators[data.author];
            if (creator && creator.info) avatar = creator.info.avatar;
        }
        // 兜底：随机生成
        if (!avatar && window.getDiceBearAvatar) avatar = window.getDiceBearAvatar(data.author);

        const avatarEl = document.getElementById('lp-avatar');
        avatarEl.src = avatar || '';
        avatarEl.style.display = 'block';

        // 4. 刷新状态
        this._updateLikeUI();
        document.getElementById('lp-comment-count').innerText = app.renderer.formatNumber(data.comment);
        if (this.activePanel === 'share') {
            this.activePanel = null;
            this.openPanel('share');
        } else if (this.activePanel === 'music') {
            this._restoreMusicManageContent();
            this.sideBody.replaceChildren();
            this._mountMusicManagePanel();
        }

        // 5. 开始播放
        if (this.sourceVideo) this.sourceVideo.pause();
        this.root.style.display = 'flex';

        if (this.isGallery) {
            this._updatePlayBtnUI(true);
            this._setLandscapeAudioMode(this.activePanel === 'music' ? 'music' : 'default');
            this._scheduleGalleryAuto();
        } else {
            const p = this.video.play();
            if (p) {
                p.then(() => {
                    this._setLandscapeAudioMode(this.activePanel === 'music' ? 'music' : 'default');
                    this._updatePlayBtnUI(true);
                }).catch(e => {
                    this._setLandscapeAudioMode(this.activePanel === 'music' ? 'music' : 'default');
                    console.warn("LP Autoplay blocked", e);
                });
            } else {
                this._setLandscapeAudioMode(this.activePanel === 'music' ? 'music' : 'default');
            }
        }

        this._enterFullscreen();
        this.showUI();
        this._updateSettingsUI();
        this._startLoop();
    }

    exit() {
        if (!this.isActive) return;

        // 退出前同步进度回竖屏播放器
        if (this.isGallery) {
            this._syncSourceGallery();
        }
        if (this.sourceVideo) {
            this.sourceVideo.currentTime = this.video.currentTime;
            if (this.landscapeBgmAudio) {
                try { this.landscapeBgmAudio.currentTime = this.video.currentTime || this.landscapeBgmAudio.currentTime; } catch (e) { /* ignore */ }
                this.landscapeBgmAudio.muted = true;
            }
            this.sourceVideo.muted = app.mediaManager ? (app.mediaManager.isGlobalMuted || app.mediaManager._isMutedByLayer()) : false;
            if (!this.video.paused) {
                this.sourceVideo.play();
                if (app.mediaManager) {
                    app.mediaManager.currentMedia = this.sourceVideo;
                    app.mediaManager.updatePlayBtnState(true);
                }
            } else {
                if (app.mediaManager) app.mediaManager.updatePlayBtnState(false);
            }
        }

        this.isActive = false;
        this.closePanel();
        this._clearGalleryTimer();
        this.video.pause();
        this._exitFullscreen();
        this.root.style.display = 'none';
        this.root.style.transform = 'none';
        this.root.style.width = '100%';
        this.root.style.height = '100%';
        if (this.loopTimer) cancelAnimationFrame(this.loopTimer);
    }

    // ================== 3. 交互逻辑 (点赞/播放/切歌) ==================

    _hasGalleryImages(data) {
        return !!(data && Array.isArray(data.images) && data.images.length > 0);
    }

    _getImageUrl(img) {
        if (!img) return '';
        if (Array.isArray(img)) return img[0] || '';
        if (typeof img === 'object') return img.url || img.src || img.cover || '';
        return String(img);
    }

    _getSourceGalleryIndex() {
        try {
            const slide = app.mainSwiper?.slides?.[app.mainSwiper.activeIndex];
            const gallery = slide?.querySelector('.gallery-swiper')?.swiper;
            return gallery ? Math.max(0, gallery.realIndex || 0) : 0;
        } catch (e) {
            return 0;
        }
    }

    _renderGalleryImage() {
        if (!this.isGallery || !this.galleryImages.length) return;
        this.galleryIndex = Math.max(0, Math.min(this.galleryImages.length - 1, this.galleryIndex));
        this.image.src = this.galleryImages[this.galleryIndex];
        this.timeCurrent.innerText = `${this.galleryIndex + 1}/${this.galleryImages.length}`;
        this.timeTotal.innerText = '图集';
        const pct = this.galleryImages.length <= 1 ? 100 : (this.galleryIndex / (this.galleryImages.length - 1)) * 100;
        this.progressBar.value = pct;
        this.progressBar.style.setProperty('--lp-progress-pct', `${pct}%`);
        this._renderGalleryProgress();
        this._syncLandscapeMiniPreview(true);
    }

    _renderGalleryProgress() {
        if (!this.galleryProgress) return;
        if (!this.isGallery || !this.galleryImages.length) {
            this.galleryProgress.style.display = 'none';
            this.progressBar.style.display = '';
            return;
        }
        this.progressBar.style.display = 'none';
        this.galleryProgress.style.display = 'flex';
        if (this.galleryProgress.children.length !== this.galleryImages.length) {
            this.galleryProgress.innerHTML = this.galleryImages.map((_, index) => (
                `<div class="lp-gallery-segment" data-index="${index}" data-clickable><span class="lp-gallery-segment-fill"></span></div>`
            )).join('');
            this.galleryProgress.querySelectorAll('.lp-gallery-segment').forEach((seg) => {
                seg.onclick = (e) => {
                    e.stopPropagation();
                    const index = Number(seg.dataset.index);
                    if (!Number.isInteger(index)) return;
                    this.galleryIndex = Math.max(0, Math.min(this.galleryImages.length - 1, index));
                    this._renderGalleryImage();
                    this._syncSourceGallery();
                    this._markGalleryInteraction();
                };
            });
        }
        Array.from(this.galleryProgress.children).forEach((seg, index) => {
            seg.classList.toggle('done', index < this.galleryIndex);
            seg.classList.toggle('active', index === this.galleryIndex);
        });
    }

    switchGalleryImage(direction, manual = false) {
        if (!this.isGallery || !this.galleryImages.length) return;
        const delta = direction === 'next' ? 1 : -1;
        const nextIndex = this.galleryIndex + delta;
        if (nextIndex < 0) {
            this.galleryIndex = this.galleryImages.length - 1;
            this._renderGalleryImage();
            this._syncSourceGallery();
            this._scheduleGalleryAuto(manual ? 3000 : undefined);
            return;
        }
        if (nextIndex >= this.galleryImages.length) {
            this.galleryIndex = 0;
            this._renderGalleryImage();
            this._syncSourceGallery();
            this._scheduleGalleryAuto(manual ? 3000 : undefined);
            return;
        }
        this.galleryIndex = nextIndex;
        this._renderGalleryImage();
        this._syncSourceGallery();
        this._scheduleGalleryAuto(manual ? 3000 : undefined);
    }

    _syncSourceGallery() {
        try {
            const slide = app.mainSwiper?.slides?.[app.mainSwiper.activeIndex];
            const gallery = slide?.querySelector('.gallery-swiper')?.swiper;
            if (!gallery) return;
            if (gallery.params?.loop && gallery.slideToLoop) gallery.slideToLoop(this.galleryIndex, 0);
            else gallery.slideTo(this.galleryIndex, 0);
        } catch (e) {
            // ignore gallery sync failures
        }
    }

    _markGalleryInteraction() {
        if (!this.isGallery) return;
        this._clearGalleryTimer();
        this._scheduleGalleryAuto(3000);
    }

    _scheduleGalleryAuto(delayOverride) {
        this._clearGalleryTimer();
        if (!this.isActive || !this.isGallery || this.galleryPaused || !this.galleryImages.length) return;
        const isLast = this.galleryIndex >= this.galleryImages.length - 1;
        if (!isLast && Number(CONFIG.GALLERY_AUTOPLAY_DELAY) <= 0) return;
        const delay = isLast
            ? this._getGalleryMusicWait(typeof delayOverride === 'number' ? delayOverride : 3000)
            : (typeof delayOverride === 'number' ? delayOverride : Math.max(1200, Number(CONFIG.GALLERY_AUTOPLAY_DELAY) || 2500));
        this.galleryStepStartedAt = performance.now();
        this.galleryStepDuration = delay;
        this._updateGalleryProgressFill();
        this.galleryTimer = setTimeout(() => {
            if (!this.isActive || !this.isGallery || this.galleryPaused) return;
            if (this.galleryIndex >= this.galleryImages.length - 1) {
                this.switchVideo('next');
            } else {
                this.switchGalleryImage('next', false);
            }
        }, delay);
    }

    _getGalleryMusicWait(baseDelayMs = 3000) {
        const slide = app.mainSwiper?.slides?.[app.mainSwiper.activeIndex];
        const audio = slide ? slide.querySelector('.bgm-audio') : null;
        if (!audio || audio.paused) return baseDelayMs;
        const duration = audio.duration;
        if (!isFinite(duration) || isNaN(duration) || duration <= 0) return baseDelayMs;
        const remainingMs = Math.max(0, (duration - audio.currentTime) * 1000);
        return Math.max(baseDelayMs, remainingMs);
    }

    _clearGalleryTimer() {
        if (this.galleryTimer) {
            clearTimeout(this.galleryTimer);
            this.galleryTimer = null;
        }
        this.galleryStepStartedAt = 0;
        this.galleryStepDuration = 0;
        this._updateGalleryProgressFill();
    }

    _updateGalleryProgressFill() {
        if (!this.galleryProgress || !this.isGallery) return;
        let pct = 0;
        if (this.galleryStepStartedAt && this.galleryStepDuration > 0 && !this.galleryPaused) {
            pct = Math.max(0, Math.min(100, ((performance.now() - this.galleryStepStartedAt) / this.galleryStepDuration) * 100));
        }
        this.galleryProgress.style.setProperty('--lp-gallery-active-pct', `${pct}%`);
    }

    // 核心：横屏内部点赞
    async toggleLike() {
        if (!this.currentData) return;

        // 1. 调用全局点赞逻辑 (异步获取最新状态)
        const isLiked = await app.userDataManager.toggleLike(this.currentData);

        // 2. 更新数据模型
        if (isLiked) {
            this.currentData.like = (parseInt(this.currentData.like) || 0) + 1;
            this._showToast('fa-heart', '已喜欢', '#ff4d4f'); // 红色心提示
        } else {
            this.currentData.like = Math.max(0, (parseInt(this.currentData.like) || 0) - 1);
            this._showToast('fa-heart-crack', '取消喜欢');
        }

        // 3. 刷新横屏 UI
        this._updateLikeUI();

        // 4. 同步刷新竖屏页面 (找到当前 slide 刷新 DOM)
        // 这一步是为了退出横屏时，竖屏界面的状态也是对的
        if (app.mainSwiper) {
            const slide = app.mainSwiper.slides[app.mainSwiper.activeIndex];
            if (slide) {
                const heartBtn = slide.querySelector('.stats-item .fa-heart');
                const countText = slide.querySelector('.stats-item span');
                if (heartBtn) {
                    heartBtn.style.color = isLiked ? '#ff4d4f' : '#fff';
                }
                if (countText) countText.innerText = app.renderer.formatNumber(this.currentData.like);
            }
        }

        // 5. 刷新“我的”页面列表 (如果激活)
        app.pageManager.refreshMyPageListIfActive('likes');
    }

    _updateLikeUI() {
        if (!this.currentData) return;
        const isLiked = app.userDataManager.isLiked(this.currentData);
        const icon = document.getElementById('lp-like-icon');
        const count = document.getElementById('lp-like-count');

        if (icon) {
            icon.style.color = isLiked ? '#ff4d4f' : '#fff';
        }
        if (count) {
            count.innerText = app.renderer.formatNumber(this.currentData.like);
        }
    }

    togglePlay() {
        if (this.isGallery) {
            this.galleryPaused = !this.galleryPaused;
            if (this.galleryPaused) this._clearGalleryTimer();
            else this._scheduleGalleryAuto();
            this._updatePlayBtnUI(!this.galleryPaused);
            return;
        }
        if (this.video.paused) {
            this.video.play();
            if (this.landscapeBgmAudio) {
                this.landscapeBgmAudio.play().catch(e => console.log('Landscape music resume failed', e));
            }
            this._updatePlayBtnUI(true);
        } else {
            this.video.pause();
            if (this.landscapeBgmAudio) this.landscapeBgmAudio.pause();
            this._updatePlayBtnUI(false);
        }
    }

    _updatePlayBtnUI(isPlaying) {
        const centerIcon = this.playPauseBtnBig.querySelector('i');
        if (isPlaying) {
            centerIcon.className = 'fa-solid fa-pause';
            this.resetHideTimer(); // 播放时如果没有交互会自动隐藏
        } else {
            centerIcon.className = 'fa-solid fa-play';
            this.showUI(); // 暂停时保持 UI 显示
        }
    }

    // 自动连播/循环
    onVideoEnded() {
        if (this.isGallery) return;
        if (CONFIG.AUTO_NEXT_VIDEO) {
            this.switchVideo('next');
        } else {
            // 循环播放
            this.video.currentTime = 0;
            this.video.play();
            if (this.landscapeBgmAudio) {
                try { this.landscapeBgmAudio.currentTime = 0; } catch (e) { /* ignore */ }
                this.landscapeBgmAudio.play().catch(err => console.log('Landscape music loop failed', err));
            }
            this._updatePlayBtnUI(true); // 确保UI是播放状态
        }
    }

    switchVideo(direction) {
        if (!app.mainSwiper) return;
        const currentIndex = app.mainSwiper.activeIndex;
        let targetIndex = direction === 'next' ? currentIndex + 1 : currentIndex - 1;

        if (targetIndex < 0) return this._showToast('fa-circle-exclamation', '已经是第一个了');
        if (targetIndex >= app.mainSwiper.slides.length) {
            app.appendNextBatch();
            setTimeout(() => {
                if (targetIndex < app.mainSwiper.slides.length) this._doSwitch(targetIndex);
                else this._showToast('fa-circle-exclamation', '没有更多视频了');
            }, 200);
            return;
        }
        this._doSwitch(targetIndex);
    }

    _doSwitch(index) {
        this.showLoading(true);
        this.video.pause();
        this._clearGalleryTimer();

        // 标记正在切换，防止触发主页的播放逻辑
        app.landscapePlayer.isSwitching = true;
        app.mainSwiper.slideTo(index, 0);

        const newSlide = app.mainSwiper.slides[index];
        const newData = app.fullPlaylist[index];
        const newSourceVideo = newSlide ? newSlide.querySelector('video') : null;

        // 确保新视频有 src
        if (newSourceVideo && !newSourceVideo.src && newSourceVideo.dataset.src) {
            newSourceVideo.src = newSourceVideo.dataset.src;
        }

        setTimeout(() => {
            if (!newData || (newData.type !== '视频' && !this._hasGalleryImages(newData))) {
                this._showToast('fa-image', '当前作品不支持横屏');
                this.exit();
            } else {
                this.enter(newSourceVideo, newData);
                // 自动播放
                // this._showToast('fa-play', '已切换');
            }
            this.showLoading(false);
            app.landscapePlayer.isSwitching = false;
        }, 300);
    }

    _syncTimeUI() {
        if (!this.isActive || this.isSeeking) return;
        if (this.isGallery) {
            this._renderGalleryImage();
            return;
        }
        if (this.landscapeBgmAudio && !this.landscapeBgmAudio.muted) {
            this._syncLandscapeVideoToAudio(this.landscapeBgmAudio);
        }
        if (this.video.duration) {
            const cur = this.video.currentTime;
            const dur = this.video.duration;
            const pct = (cur / dur) * 100;
            this.progressBar.value = pct;
            this.progressBar.style.setProperty('--lp-progress-pct', `${pct}%`);
            this.timeCurrent.innerText = app.mediaManager.formatTime(cur);
            this.timeTotal.innerText = app.mediaManager.formatTime(dur);
        }
    }
    // 替换 LandscapePlayer 中的 toggleTitle 方法为下面这段
    toggleTitle(e) {
        if (e) e.stopPropagation();

        // 如果选中了文本（复制操作），不触发收起/展开
        const selection = window.getSelection();
        if (selection && selection.toString().length > 0) return;

        const titleBox = this.root.querySelector('.lp-title-box');
        const titleText = this.root.querySelector('#lp-title');

        if (!titleBox || !titleBox.dataset.fullTitle) return;

        const isExpanded = titleBox.classList.contains('expanded');

        if (isExpanded) {
            // === 收起 ===
            titleBox.classList.remove('expanded');

            // 恢复简略文本
            titleText.innerHTML = `${titleBox.dataset.shortTitle} <span class="lp-expand-btn">展开</span>`;

            // 恢复自动隐藏UI计时器
            this.resetHideTimer();

            // 清理事件监听（防止内存泄漏 / 保证手势恢复）
            titleText.ontouchstart = null;
            titleText.ontouchmove = null;
            titleText.onpointerdown = null;
            titleText.onpointermove = null;

            // 恢复样式（防万一）
            titleText.style.overflowY = '';
            titleText.style.whiteSpace = '';
            titleText.scrollTop = 0;

        } else {
            // === 展开 ===
            titleBox.classList.add('expanded');

            // 显示全文
            titleText.innerHTML = `${titleBox.dataset.fullTitle} <span class="lp-expand-btn">收起</span>`;

            // 展开时不自动隐藏UI
            if (this.uiTimer) clearTimeout(this.uiTimer);

            // 阻止事件向上冒泡，隔离播放器的全局手势（不 preventDefault）
            const stopProp = (evt) => evt.stopPropagation();

            // 绑定到实际可滚动的文本节点（#lp-title），不要只绑定到 titleBox
            titleText.ontouchstart = stopProp;
            titleText.ontouchmove = stopProp;
            titleText.onpointerdown = stopProp;
            titleText.onpointermove = stopProp;

            // 让内部可以原生滚动（必要的内联样式，辅以 CSS）
            titleText.style.overflowY = 'auto';
            titleText.style.whiteSpace = 'normal';
            // iOS 惯性滚动
            titleText.style.WebkitOverflowScrolling = 'touch';
        }
    }


    // ================== 4. 设置与辅助 ==================

    setSpeed(rate) {
        this.video.playbackRate = rate;
        this._showToast('fa-gauge-high', `倍速: ${rate}x`);
        setTimeout(() => this.toggleSettings(), 300);
    }
    setFit(mode) {
        this.video.style.objectFit = mode;
        this.image.style.objectFit = mode;
        this._showToast('fa-expand', `模式: ${mode === 'contain' ? '适应' : (mode === 'cover' ? '铺满' : '拉伸')}`);
        setTimeout(() => this.toggleSettings(), 300);
    }
    toggleSettings() {
        if (this.activePanel === 'settings') this.closePanel();
        else this.openPanel('settings');
    }
    _updateSettingsUI() {
        const rate = this.video.playbackRate;
        const fit = (this.isGallery ? this.image.style.objectFit : this.video.style.objectFit) || 'contain';
        this.settingsPanel.querySelectorAll('[data-val]').forEach(btn => {
            const val = btn.dataset.val;
            let match = false;
            if (!isNaN(parseFloat(val))) match = Math.abs(parseFloat(val) - rate) < 0.01;
            else match = val === fit;

            btn.style.background = match ? '#5cc9ff' : 'rgba(255,255,255,0.15)';
            btn.style.color = match ? '#000' : '#fff';
        });
    }
    showLoading(show) { this.loadingEl.style.display = show ? 'block' : 'none'; }

    // 使用内部 Toast 确保方向正确 (旋转后 HTML 元素也会旋转)
    _showToast(icon, text, color = '#fff') {
        this.toast.innerHTML = `<i class="fa-solid ${icon}" style="font-size:20px; color:${color}"></i><span style="font-size:14px;font-weight:bold">${text}</span>`;
        this.toast.style.opacity = '1';
        setTimeout(() => { this.toast.style.opacity = '0'; }, 2000);
    }

    // ================== 5. 全屏与布局 ==================

    _enterFullscreen() {
        const el = this.root;
        this.css(el, { position: 'fixed', zIndex: '99999', backgroundColor: '#000', top: '0', left: '0' });
        this._updateLayout();
        window.addEventListener('resize', this._onResize);
        setTimeout(() => this._updateLayout(), 300);
        window.webapp?.设置全屏模式?.(true);
    }
    _exitFullscreen() {
        if (document.exitFullscreen) document.exitFullscreen().catch(() => { });
        window.removeEventListener('resize', this._onResize);
        this.css(this.root, { width: '100%', height: '100%', top: '0', left: '0', transform: 'none', zIndex: '', position: '', backgroundColor: '' });
        window.webapp?.设置全屏模式?.(false);

    }
    _onResize() { if (this.isActive) this._updateLayout(); }
    _updateLayout() {
        const w = window.innerWidth; const h = window.innerHeight;
        if (w < h) {
            this.css(this.root, { width: h + 'px', height: w + 'px', top: '50%', left: '50%', transform: 'translate(-50%, -50%) rotate(90deg)', position: 'fixed', zIndex: '99999' });
        } else {
            this.css(this.root, { width: '100%', height: '100%', top: '0', left: '0', transform: 'none', position: 'fixed', zIndex: '99999' });
        }
    }

    // ================== 6. 手势与 UI 显隐 ==================

    showUI() {
        this.uiLayer.style.opacity = '1';
        if (this.uiTimer) clearTimeout(this.uiTimer);
    }
    resetHideTimer() {
        if (this.uiTimer) clearTimeout(this.uiTimer);

        // 检查标题是否展开
        const titleBox = this.root.querySelector('.lp-title-box');
        const isTitleExpanded = titleBox && titleBox.classList.contains('expanded');
        const mediaPaused = this.isGallery ? this.galleryPaused : this.video.paused;

        // 条件：侧栏打开 OR 视频暂停 OR 拖动进度条 OR 标题展开 -> 不隐藏
        if (this.activePanel || mediaPaused || this.isSeeking || isTitleExpanded) return;

        this.uiTimer = setTimeout(() => { this.uiLayer.style.opacity = '0'; }, 3000);
    }
    toggleUI() {
        if (this.uiLayer.style.opacity === '1') {
            this.uiLayer.style.opacity = '0';
            this.closePanel();
        } else {
            this.showUI();
            this.resetHideTimer();
        }
    }

    _bindGestures() {
        let startX, startY, initTime, initVol, initBright;
        let isDragging = false;
        let dragType = null;
        this.originalRate = 1.0;

        // 1. 触摸开始
        this.root.addEventListener('touchstart', (e) => {
            // === ★★★ 核心修复：如果是触摸在展开的标题框上，直接退出 ★★★ ===
            // 这样就不会触发长按倍速，也不会记录 startX，完全把控制权交给浏览器原生滚动
            if (e.target.closest('.lp-title-box.expanded')) {
                e.stopPropagation(); // 阻止冒泡，防止触发底层的点击隐藏UI逻辑
                return;
            }

            if (e.target.closest('.lp-side-panel') || e.target.closest('input') || e.target.closest('[onclick]') || e.target.closest('[data-clickable]')) return;
            if (e.target !== this.root && e.target !== this.uiLayer && e.target !== this.centerControls) return;

            const touch = e.touches[0];
            startX = touch.clientX; startY = touch.clientY;
            initTime = this.isGallery ? this.galleryIndex : this.video.currentTime;
            initVol = this.video.volume;
            initBright = this.brightness;
            isDragging = false; dragType = null;
            this.originalRate = this.video.playbackRate;
            if (this.isGallery) this._clearGalleryTimer();
        }, { passive: false });

        // 2. 触摸移动
        this.root.addEventListener('touchmove', (e) => {
            if (startX === undefined || startY === undefined) return;
            const touch = e.touches[0];
            const deltaX = touch.clientX - startX;
            const deltaY = touch.clientY - startY;

            const isRotated = this.root.style.transform.includes('rotate(90deg)');
            const visualX = isRotated ? deltaY : deltaX;
            const visualY = isRotated ? -deltaX : deltaY;
            const visualStartX = isRotated ? startY : startX;
            const visualWidth = isRotated ? window.innerHeight : window.innerWidth;
            const visualHeight = isRotated ? window.innerWidth : window.innerHeight;
            const absX = Math.abs(visualX);
            const absY = Math.abs(visualY);

            if (!dragType) {
                if (absX < 18 && absY < 18) return;
                if (absX > absY * 1.25) {
                    dragType = 'seek';
                    this.isSeeking = true;
                } else if (absY > absX * 1.25) {
                    dragType = visualStartX > visualWidth / 2 ? 'volume' : 'brightness';
                } else {
                    return;
                }
            }

            if (dragType) {
                isDragging = true;
                e.preventDefault();
                this.showUI();

                if (dragType === 'seek') {
                    if (this.isGallery) {
                        const step = Math.round(visualX / Math.max(36, visualWidth / Math.max(3, this.galleryImages.length)));
                        let nextIndex = Math.max(0, Math.min(this.galleryImages.length - 1, initTime + step));
                        if (initTime >= this.galleryImages.length - 1 && step > 0) {
                            nextIndex = 0;
                        } else if (initTime <= 0 && step < 0) {
                            nextIndex = this.galleryImages.length - 1;
                        }
                        if (nextIndex !== this.galleryIndex) {
                            this.galleryIndex = nextIndex;
                            this._renderGalleryImage();
                            this._syncSourceGallery();
                        }
                        this._showToast('fa-images', `${this.galleryIndex + 1}/${this.galleryImages.length}`);
                    } else if (this.video.duration) {
                        const target = Math.max(0, Math.min(this.video.duration, initTime + (visualX / visualWidth) * 90));
                        this.video.currentTime = target;
                        this._syncTimeUI();
                        this._showToast(visualX > 0 ? 'fa-forward' : 'fa-backward', app.mediaManager.formatTime(target));
                    }
                } else {
                    const change = -visualY / (visualHeight * 0.75);
                    if (dragType === 'volume') {
                        let v = Math.max(0, Math.min(1, initVol + change));
                        this.video.volume = v;
                        this.video.muted = v === 0;
                        this._showToast(v === 0 ? 'fa-volume-off' : 'fa-volume-high', `音量 ${Math.round(v * 100)}%`);
                    } else {
                        let b = Math.max(0, Math.min(1, initBright + change));
                        this.brightness = b;
                        this.brightnessMask.style.opacity = (1 - b) * 0.8;
                        this._showToast('fa-sun', `亮度 ${Math.round(b * 100)}%`);
                    }
                }
            }
        }, { passive: false });

        // 3. 触摸结束 (保持不变)
        this.root.addEventListener('touchend', (e) => {
            if (!isDragging) {
                const isControl = e.target.closest('.lp-btn-icon, .lp-ctrl-btn, .lp-sidebar-item, .lp-follow-btn, input, .lp-title-box, [data-clickable]');
                const isPanel = this.sidePanel && this.sidePanel.contains(e.target);

                if (!isControl && !isPanel) {
                    if (this.activePanel) {
                        this.closePanel();
                    } else {
                        this.toggleUI();
                    }
                }
            }

            if (dragType === 'seek') this.isSeeking = false;
            if (this.isGallery) this._markGalleryInteraction();
            isDragging = false;
            dragType = null;
            startX = undefined;
            startY = undefined;
            this.toast.style.opacity = '0';
        });
    }

    // 显示提示
    _showToast(icon, text, color = '#fff') {
        if (this.toastTimer) clearTimeout(this.toastTimer);
        this.toast.innerHTML = `<i class="fa-solid ${icon}" style="font-size:20px; color:${color}"></i><span style="font-size:14px;font-weight:bold;z-index:99999">${text}</span>`;
        this.toast.style.opacity = '1';
        this.toastTimer = setTimeout(() => {
            this.toast.style.opacity = '0';
            this.toastTimer = null;
        }, 900);
    }
    _startLoop() {
        const loop = () => {
            if (!this.isActive) return;
            this._syncMusicPanel();
            if (this.isGallery) this._updateGalleryProgressFill();
            this._syncLandscapeMusicPage();
            this.loopTimer = requestAnimationFrame(loop);
        };
        loop();
    }
    css(el, styles) { for (let k in styles) el.style[k] = styles[k]; }

    // 7. 外部接口
    toggle() {
        if (this.isActive) this.exit();
        else {
            if (!app.mainSwiper) return;
            const index = app.mainSwiper.activeIndex;
            const slide = app.mainSwiper.slides[index];
            if (!slide) return;
            const video = slide.querySelector('video');
            const data = app.fullPlaylist[index];
            if (video || this._hasGalleryImages(data)) this.enter(video, data);
            else app.interaction.showToast('当前作品不支持横屏');
        }
    }

    syncBtnState() { /* 保持原逻辑 */
        if (!app.mainSwiper) return;
        const index = app.mainSwiper.activeIndex;
        const data = app.fullPlaylist[index];
        const slide = app.mainSwiper.slides[index];
        const video = slide ? slide.querySelector('video') : null;
        const btn = slide ? slide.querySelector('.landscape-toggle-btn') : null;
        if (!btn) return;
        let w = data ? data.width : 0;
        let h = data ? data.height : 0;
        if ((!w || !h) && video) { w = video.videoWidth; h = video.videoHeight; }
        btn.style.display = (w && h && w > h) ? 'flex' : 'none';
    }
}
