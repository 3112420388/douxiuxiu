/* v3 semantic split: class from js/app/04-data-media-landscape.js | keep script order */
        class MediaManager {
            constructor() {
                this.currentMedia = null;
                this.gallerySwiper = null;
                this.isSeeking = false;
                // 初始化运行时全局静音状态
                this.isGlobalMuted = CONFIG.DEFAULT_MUTED;

                // 音乐页状态
                this.isMusicPageActive = false;

                this.musicPageRefs = {
                    page: null,
                    seekBar: null,
                    currTimeEl: null,
                    miniVideo: null
                };
                this.lastUiSyncTime = 0;
                this.lastTimeTextSync = 0;
                this.lastMiniSyncTime = 0;
                this.lastMiniRate = 1;
                this.lastMediaSyncTime = 0;
                this._mediaEventHandlers = null;
                this.manualPauseOverlay = false;
                this.galleryAutoTimer = null;
            }

            _isMutedByLayer() {
                if (!CONFIG.MUTE_ON_PAGE_OPEN) return false;
                const activePage = document.querySelector('.page-layer.active:not(#music-manage-page):not(.left-side)');
                return !!activePage;
            }

            play(slide) {
                this.stop(); // 停止上一个

                const video = slide.querySelector('video');
                const audio = slide.querySelector('.bgm-audio');
                const galleryEl = slide.querySelector('.gallery-swiper');

                // 通用：应用静音设置
                const isMuted = this.isGlobalMuted || this._isMutedByLayer();

                // 如果当前在音乐页，优先播放音频，视频静音播放
                if (this.isMusicPageActive) {
                    if (audio) {
                        this.currentMedia = audio;
                        this._bindMediaEvents(audio);
                        audio.muted = this._isMutedByLayer(); // 离开首页时强制静音
                        audio.currentTime = video ? video.currentTime : 0;
                        audio.play().catch(e => console.log('Audio play failed', e));
                    }
                    if (video) {
                        video.muted = true; // 强制静音
                        video.play().catch(e => console.log('Background video play failed', e));
                    }
                }
                // 正常主页模式
                else {
                    // 1. 视频播放逻辑
                    if (video) {
                        this.currentMedia = video;
                        this._bindMediaEvents(video);
                        video.muted = isMuted;
                        video.playbackRate = CONFIG.DEFAULT_SPEED || 1.0;

                        if (audio) {
                            audio.pause();
                            audio.muted = isMuted;
                        }

                        video.play().catch(e => console.log('Video play failed', e));
                        const logFinalOnce = () => {
                            if (window.app && typeof app.syncVideoSrcWithData === 'function') {
                                app.syncVideoSrcWithData(video);
                            }
                        };
                        video.addEventListener('loadedmetadata', logFinalOnce, { once: true });
                        video.addEventListener('canplay', logFinalOnce, { once: true });
                        if (window.app && slide) {
                            const parent = slide.parentElement;
                            const index = parent ? Array.from(parent.children).indexOf(slide) : -1;
                            const data = (index >= 0 && window.app.fullPlaylist) ? window.app.fullPlaylist[index] : null;
                            if (data && data.is_random_api) {
                                let tries = 0;
                                const maxTries = 12; // 增加重试次数
                                const poll = setInterval(() => {
                                    tries += 1;
                                    const src = video.currentSrc || video.src || '';
                                    const finalUrl = (src && src.startsWith('http')) ? src : (data.url || '');

                                    // 优化：检查视频是否可播放
                                    if (video.readyState >= 2) { // HAVE_CURRENT_DATA
                                        console.log(`[RandomVideo] video readyState: ${video.readyState}, final url: ${finalUrl} (${data.source_api || 'api'})`);
                                        if (finalUrl && data._last_logged_url !== finalUrl) {
                                            console.log(`[RandomVideo] final url: ${finalUrl} (${data.source_api || 'api'})`);
                                            data._last_logged_url = finalUrl;
                                        }
                                        clearInterval(poll);
                                        return;
                                    }

                                    if (finalUrl && data._last_logged_url !== finalUrl) {
                                        console.log(`[RandomVideo] final url: ${finalUrl} (${data.source_api || 'api'})`);
                                        data._last_logged_url = finalUrl;

                                        // 如果获取到URL但视频仍未加载，尝试重新加载
                                        if (tries > 3 && video.readyState < 2) {
                                            console.log('[RandomVideo] retrying video load...');
                                            video.load();
                                        }
                                    }

                                    if (tries >= maxTries) {
                                        console.warn(`[RandomVideo] final url poll timeout after ${maxTries} tries`);

                                        // 超时后显示错误提示
                                        const container = video.closest('.media-container');
                                        if (container) {
                                            const errTip = container.querySelector('.video-error');

                                        }
                                        clearInterval(poll);
                                    }
                                }, 250);
                            }
                        }
                        setTimeout(logFinalOnce, 0);
                    }
                    // 2. 图集播放逻辑
                    else if (galleryEl) {
                        if (audio) {
                            this.currentMedia = audio;
                            this._bindMediaEvents(audio);
                            audio.muted = isMuted;
                            audio.play().catch(e => console.log('Audio play failed', e));
                        }
                        // 初始化 Swiper 轮播
                        if (galleryEl.swiper) {
                            this.gallerySwiper = galleryEl.swiper;
                            if (this.gallerySwiper.autoplay) this.gallerySwiper.autoplay.stop();

                            if (this.gallerySwiper.params.loop) {
                                this.gallerySwiper.slideToLoop(0, 0);
                            } else {
                                this.gallerySwiper.slideTo(0, 0);
                            }

                            this._scheduleGalleryStep(this.gallerySwiper);
                        }
                    }
                    // 3. 纯音乐逻辑 (无视频/图集时)
                    else if (audio) {
                        this.currentMedia = audio;
                        this._bindMediaEvents(audio);
                        audio.muted = isMuted;
                        audio.play().catch(e => console.log('Audio play failed', e));
                    }
                }

                // 进度条初始化
                const activeMedia = this.isMusicPageActive && audio ? audio : (video || audio);

                if (activeMedia) {
                    if (activeMedia.readyState >= 1) {
                        this.updateTotalTime(activeMedia.duration);
                    } else {
                        activeMedia.onloadedmetadata = () => this.updateTotalTime(activeMedia.duration);
                    }
                }

                if (this.currentMedia) {
                    this.lastMiniRate = this.currentMedia.playbackRate || 1;
                }

                if (this.isMusicPageActive) {
                    this.refreshMusicPageRefs(true);
                }

                this.startProgress(slide);
                this.updatePlayBtnState(true);
            }

            _bindMediaEvents(media) {
                if (!media) return;
                this._unbindMediaEvents();

                const slide = media.closest('.swiper-slide');
                const onPlay = () => {
                    if (slide) slide.classList.add('playing');
                    this.updatePlayBtnState(true);
                };
                const onPause = () => {
                    if (slide) slide.classList.remove('playing');
                    this.updatePlayBtnState(false);
                };
                const onEnded = () => {
                    if (slide) slide.classList.remove('playing');
                    this.updatePlayBtnState(false);
                };

                media.addEventListener('play', onPlay);
                media.addEventListener('pause', onPause);
                media.addEventListener('ended', onEnded);

                this._mediaEventHandlers = { media, onPlay, onPause, onEnded };
            }

            _unbindMediaEvents() {
                if (!this._mediaEventHandlers) return;
                const { media, onPlay, onPause, onEnded } = this._mediaEventHandlers;
                media.removeEventListener('play', onPlay);
                media.removeEventListener('pause', onPause);
                media.removeEventListener('ended', onEnded);
                this._mediaEventHandlers = null;
            }

            refreshMusicPageRefs(force = false) {
                const musicPage = document.getElementById('music-manage-page');
                if (!musicPage) return;

                const isOpen = this.isMusicPageActive || musicPage.classList.contains('active');
                if (!isOpen && !force) return;

                if (force || !this.musicPageRefs.page || this.musicPageRefs.page !== musicPage) {
                    this.musicPageRefs.page = musicPage;
                    this.musicPageRefs.seekBar = document.getElementById('music-seek-bar');
                    this.musicPageRefs.currTimeEl = document.getElementById('music-curr-time');
                }

                if (force || !this.musicPageRefs.miniVideo) {
                    this.musicPageRefs.miniVideo = document.querySelector('#music-mini-media video[data-mini-sync="true"]');
                }
            }

            _syncMiniVideo(curr) {
                const miniVideo = this.musicPageRefs.miniVideo;
                if (!miniVideo || !this.currentMedia) return;

                const now = performance.now();
                if (!this.isSeeking && now - this.lastMiniSyncTime < 120) return;
                this.lastMiniSyncTime = now;

                const targetTime = curr;
                const diff = Math.abs(miniVideo.currentTime - targetTime);
                if (!this.isSeeking && diff > 0.25) {
                    try {
                        miniVideo.currentTime = Math.min(targetTime, miniVideo.duration || targetTime);
                    } catch (e) { /* ignore */ }
                }

                if (this.currentMedia.paused) {
                    if (!miniVideo.paused) miniVideo.pause();
                } else if (miniVideo.paused) {
                    const p = miniVideo.play();
                    if (p) p.catch(() => { });
                }

                const rate = this.currentMedia.playbackRate || 1;
                if (this.lastMiniRate !== rate) {
                    miniVideo.playbackRate = rate;
                    this.lastMiniRate = rate;
                }
            }

            _syncMusicPageUI(curr, pct) {
                const musicPage = this.musicPageRefs.page;
                if (!musicPage) return;

                const now = performance.now();
                if (now - this.lastUiSyncTime < 50) return;
                this.lastUiSyncTime = now;

                const seekBar = this.musicPageRefs.seekBar;
                if (seekBar && !this.isSeeking) {
                    seekBar.value = pct;
                }

                const currTimeEl = this.musicPageRefs.currTimeEl;
                if (currTimeEl && now - this.lastTimeTextSync > 150) {
                    currTimeEl.innerText = this.formatTime(curr);
                    this.lastTimeTextSync = now;
                }

                this._syncMiniVideo(curr);
            }

            // --- 切换到音乐模式 ---
            switchToMusicMode() {
                if (this.isMusicPageActive) return;
                this.isMusicPageActive = true;

                if (!window.app.mainSwiper || !window.app.mainSwiper.slides) return;
                const slide = window.app.mainSwiper.slides[window.app.mainSwiper.activeIndex];

                const video = slide.querySelector('video');
                const audio = slide.querySelector('.bgm-audio');

                if (video && audio) {
                    const shouldKeepPlaying = this.currentMedia ? !this.currentMedia.paused : (!video.paused || !audio.paused);
                    if (Math.abs(audio.currentTime - video.currentTime) > 0.5) {
                        audio.currentTime = video.currentTime;
                    }

                    video.muted = true;
                    console.log('视频已静音')
                    if (shouldKeepPlaying && video.paused) {
                        video.play().catch(e => console.log('Background video play failed', e));
                    }

                    audio.muted = this._isMutedByLayer();
                    console.log('正在播放音乐')
                    if (shouldKeepPlaying) {
                        audio.play().catch(e => console.log('Music audio play failed', e));
                    } else {
                        audio.pause();
                    }

                    this.currentMedia = audio;
                    this._bindMediaEvents(audio);
                    this.lastMiniRate = audio.playbackRate || 1;
                    this.refreshMusicPageRefs(true);
                    this.updatePlayBtnState(shouldKeepPlaying);
                }
            }

            // --- 切换回视频模式 ---
            switchToVideoMode() {
                if (!this.isMusicPageActive) return;
                this.isMusicPageActive = false;

                if (!window.app.mainSwiper || !window.app.mainSwiper.slides) return;
                const slide = window.app.mainSwiper.slides[window.app.mainSwiper.activeIndex];

                const video = slide.querySelector('video');
                const audio = slide.querySelector('.bgm-audio');

                if (video && audio) {
                    const shouldKeepPlaying = this.currentMedia ? !this.currentMedia.paused : (!audio.paused || !video.paused);
                    if (Math.abs(video.currentTime - audio.currentTime) > 0.5) {
                        video.currentTime = audio.currentTime;
                    }

                    audio.muted = true;

                    console.log('音乐已静音')
                    video.muted = this.isGlobalMuted || this._isMutedByLayer();
                    console.log('视频正在播放')
                    if (shouldKeepPlaying && video.paused) {
                        video.play().catch(e => console.log('Video resume failed', e));
                    } else if (!shouldKeepPlaying) {
                        video.pause();
                    }

                    this.currentMedia = video;
                    this._bindMediaEvents(video);
                    this.lastMiniRate = video.playbackRate || 1;
                    this.updatePlayBtnState(shouldKeepPlaying);
                    this.syncActiveProgressNow();
                }
            }

            syncActiveProgressNow() {
                if (!window.app || !app.mainSwiper || !this.currentMedia) return;
                const slide = app.mainSwiper.slides[app.mainSwiper.activeIndex];
                if (!slide) return;
                const bars = slide.querySelectorAll('.progress-fill');
                if (bars.length && this.currentMedia.duration) {
                    const pct = (this.currentMedia.currentTime / this.currentMedia.duration) * 100;
                    bars.forEach(bar => { bar.style.width = `${pct}%`; });
                }
            }

            stop() {
                if (this.currentMedia) {
                    this.currentMedia.pause();
                    const container = this.currentMedia.closest('.swiper-slide');
                    if (container) {
                        const v = container.querySelector('video');
                        const a = container.querySelector('.bgm-audio');
                        if (v) v.pause();
                        if (a) a.pause();
                    }
                }

                this.currentMedia = null;
                this._unbindMediaEvents();
                this.manualPauseOverlay = false;

                if (this.gallerySwiper) {
                    if (this.gallerySwiper.autoplay) {
                        this.gallerySwiper.autoplay.stop();
                    }
                    if (this.gallerySwiper.el && this.gallerySwiper.el.restartAutoPlayTimer) {
                        clearTimeout(this.gallerySwiper.el.restartAutoPlayTimer);
                        this.gallerySwiper.el.restartAutoPlayTimer = null;
                    }
                    if (this.gallerySwiper.el) {
                        this.gallerySwiper.el.dataset.isManualInteracting = 'false';
                    }
                    this.gallerySwiper = null;
                }
                this._clearGalleryAutoTimer();
                if (window.app && app.galleryNextTimer) {
                    clearTimeout(app.galleryNextTimer);
                    app.galleryNextTimer = null;
                }
                document.querySelectorAll('.progress-fill').forEach(e => e.style.width = '0%');
                this.updatePlayBtnState(false);
            }

            _clearGalleryAutoTimer() {
                if (this.galleryAutoTimer) {
                    clearTimeout(this.galleryAutoTimer);
                    this.galleryAutoTimer = null;
                }
            }

            _getGalleryInterval() {
                return Math.max(1200, Number(CONFIG.GALLERY_AUTOPLAY_DELAY) || 2500);
            }

            _isActiveGallery(swiper) {
                if (!swiper || swiper.destroyed || !swiper.el) return false;
                const parentSlide = swiper.el.closest('.swiper-slide');
                return !!(parentSlide && parentSlide.classList.contains('swiper-slide-active'));
            }

            _isGalleryAutoNextEnabled() {
                return Number(CONFIG.GALLERY_AUTOPLAY_DELAY) > 0;
            }

            _getGalleryRealTotal(swiper) {
                if (!swiper || !swiper.el) return 0;
                const realSlides = swiper.el.querySelectorAll('.swiper-slide:not(.swiper-slide-duplicate)');
                return realSlides.length || (swiper.slides ? swiper.slides.length : 0);
            }

            getGalleryMusicWait(swiper, baseDelayMs = 3000) {
                const slide = swiper && swiper.el ? swiper.el.closest('.swiper-slide') : null;
                const audio = slide ? slide.querySelector('.bgm-audio') : null;
                if (!audio || audio.paused) return baseDelayMs;

                const duration = audio.duration;
                if (!isFinite(duration) || isNaN(duration) || duration <= 0) return baseDelayMs;

                const remainingMs = Math.max(0, (duration - audio.currentTime) * 1000);
                return Math.max(baseDelayMs, remainingMs);
            }

            _handleGalleryLast(swiper, baseDelayMs = 3000) {
                this._clearGalleryAutoTimer();
                if (!this._isActiveGallery(swiper)) return;
                if (!this._isGalleryAutoNextEnabled()) return;

                const delay = this.getGalleryMusicWait(swiper, baseDelayMs);
                this.galleryAutoTimer = setTimeout(() => {
                    if (!this._isActiveGallery(swiper) || !this._isGalleryAutoNextEnabled()) return;
                    const isTopLayer = !document.querySelector('.page-layer.active') && !document.querySelector('.comment-layer.active');
                    if (isTopLayer && window.app && typeof app.triggerAutoNext === 'function') {
                        app.triggerAutoNext();
                    }
                }, delay);
            }

            _scheduleGalleryStep(swiper, delayOverride) {
                this._clearGalleryAutoTimer();
                if (!this._isActiveGallery(swiper)) return;
                if (Number(CONFIG.GALLERY_AUTOPLAY_DELAY) <= 0) return;

                const total = this._getGalleryRealTotal(swiper);
                if (total <= 1) {
                    this._handleGalleryLast(swiper, 3000);
                    return;
                }

                const current = typeof swiper.realIndex === 'number' ? swiper.realIndex : swiper.activeIndex;
                if (current >= total - 1) {
                    this._handleGalleryLast(swiper, 3000);
                    return;
                }

                const delay = typeof delayOverride === 'number' ? delayOverride : this._getGalleryInterval();
                this.galleryAutoTimer = setTimeout(() => {
                    if (!this._isActiveGallery(swiper)) return;
                    const idx = typeof swiper.realIndex === 'number' ? swiper.realIndex : swiper.activeIndex;
                    if (idx >= total - 1) {
                        this._handleGalleryLast(swiper, 3000);
                    } else {
                        swiper.slideNext(300);
                    }
                }, delay);
            }

            resumeGalleryAfterInteraction(swiper, delayMs = 3000) {
                if (!swiper || swiper.destroyed) return;
                this._scheduleGalleryStep(swiper, delayMs);
            }
            startProgress(slide) {
                const bars = slide.querySelectorAll('.progress-fill');
                const syncVideo = slide.querySelector('video');
                const syncAudio = slide.querySelector('.bgm-audio');

                const update = () => {
                    if (this.currentMedia) {
                        if (!this.currentMedia.paused) {
                            const curr = this.currentMedia.currentTime;
                            const dur = this.currentMedia.duration || 1;
                            const pct = (curr / dur) * 100;

                            if (bars.length && !this.isSeeking) {
                                bars.forEach(bar => { bar.style.width = pct + '%'; });
                            }

                            if (this.isMusicPageActive && syncVideo && syncAudio && this.currentMedia === syncAudio) {
                                const now = performance.now();
                                if (now - this.lastMediaSyncTime > 200) {
                                    const drift = Math.abs(syncVideo.currentTime - syncAudio.currentTime);
                                    if (drift > 0.35) {
                                        try { syncVideo.currentTime = syncAudio.currentTime; } catch (e) { /* ignore */ }
                                    }
                                    this.lastMediaSyncTime = now;
                                }
                            }

                            const musicPage = document.getElementById('music-manage-page');
                            const isMusicPageOpen = this.isMusicPageActive || (musicPage && musicPage.classList.contains('active'));
                            if (isMusicPageOpen) {
                                this.refreshMusicPageRefs();
                                this._syncMusicPageUI(curr, pct);
                            }
                        }
                        requestAnimationFrame(update);
                    }
                };
                update();
            }


            seek(pct) {
                // 如果 mainSwiper 为空，直接返回（防止报错）
                if (!window.app.mainSwiper) return;

                const slide = window.app.mainSwiper.slides[window.app.mainSwiper.activeIndex];
                const video = slide.querySelector('video');
                const audio = slide.querySelector('.bgm-audio');
                let targetTime = 0;

                if (this.currentMedia && this.currentMedia.duration) {
                    targetTime = pct * this.currentMedia.duration;
                    this.currentMedia.currentTime = targetTime;
                }

                if (this.currentMedia === video && audio) audio.currentTime = targetTime;
                if (this.currentMedia === audio && video) video.currentTime = targetTime;

                const musicPage = document.getElementById('music-manage-page');
                const isMusicPageOpen = this.isMusicPageActive || (musicPage && musicPage.classList.contains('active'));
                if (isMusicPageOpen) {
                    this.refreshMusicPageRefs();
                    this._syncMusicPageUI(targetTime, pct * 100);
                }
            }

            // --- 之前缺失的方法 ---

            // 切换播放/暂停
            toggleCurrent() {
                if (this.currentMedia) {
                    if (this.currentMedia.paused) {
                        this.manualPauseOverlay = false;
                        const p = this.currentMedia.play();
                        if (p) p.catch(() => this.updatePlayBtnState(false));
                        this.updatePlayBtnState(true);
                    } else {
                        this.manualPauseOverlay = true;
                        this.currentMedia.pause();
                        this.updatePlayBtnState(false);
                    }
                }
            }

            // 点击屏幕时的切换逻辑
            toggle(slide) {

                // 如果当前有媒体对象
                if (this.currentMedia) {
                    if (!this.currentMedia.paused) {
                        // 正在播放 -> 暂停
                        this.manualPauseOverlay = true;
                        this.currentMedia.pause();

                        // 如果是音乐模式，需要同时暂停视频
                        if (this.isMusicPageActive) {
                            const video = slide.querySelector('video');
                            if (video) video.pause();
                        }

                        this.updatePlayBtnState(false);
                    } else {
                        // 暂停中 -> 播放
                        this.manualPauseOverlay = false;
                        this.currentMedia.play();

                        // 如果是音乐模式，需要同时播放视频（静音）
                        if (this.isMusicPageActive) {
                            const video = slide.querySelector('video');
                            if (video) video.play().catch(() => { });
                        }

                        this.updatePlayBtnState(true);
                    }
                }
            }

            updatePlayBtnState(isPlaying) {
                const btn = document.getElementById('music-toggle-btn');
                if (btn) {
                    btn.innerHTML = isPlaying
                        ? '<i class="fa-solid fa-pause"></i>'
                        : '<i class="fa-solid fa-play" style="padding-left:4px;"></i>';
                }
                this.updatePlayOverlay(isPlaying);
            }

            updatePlayOverlay(isPlaying, slide = null) {
                const targetSlide = slide || (window.app && app.mainSwiper && app.mainSwiper.slides ? app.mainSwiper.slides[app.mainSwiper.activeIndex] : null);
                if (!targetSlide) return;
                const overlay = targetSlide.querySelector('.play-overlay');
                if (!overlay) return;
                overlay.classList.toggle('show', !isPlaying && this.manualPauseOverlay);
            }

            updateTotalTime(duration) {
                const totalEl = document.getElementById('music-total-time');
                if (totalEl && duration && !isNaN(duration) && isFinite(duration) && duration > 0) {
                    totalEl.innerText = this.formatTime(duration);
                }
            }

            formatTime(seconds) {
                return formatDuration(seconds);
            }
        }

        // --- 1.5 自定义资源管理器 (仿照图集浏览完美版逻辑) ---
