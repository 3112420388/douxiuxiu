/**
 * js/api.js
 * 抖咻咻 API 接口管理模块
 * 包含：基础请求封装、加密验证、各模块接口集合、下载代理逻辑
 */

const Api = {
    config: {
        // 核心后台地址 (原 API_BASE)
        BASE_URL: 'http://dxx.zzxia.icu/',

        // 外部第三方解析 SDK 配置
        SDK: {
            BASE: '',
            KEY: ''
        },
        // 积分/口令验证密钥
        SECRET: 'DouXiuXiu_Secret_2025_#@!',
        REQUEST_TIMEOUT: 12000
    },

    _joinUrl(base, endpoint) {
        const safeBase = String(base || '').replace(/\/+$/, '');
        const safeEndpoint = String(endpoint || '').replace(/^\/+/, '');
        if (!safeBase) return safeEndpoint;
        if (!safeEndpoint) return safeBase;
        return `${safeBase}/${safeEndpoint}`;
    },

    _getRuntimeConfig() {
        // v4: keep compatible with both classic-script CONFIG and explicit window.CONFIG.
        try {
            if (typeof CONFIG !== 'undefined') return CONFIG;
        } catch (e) {
            // ignore TDZ / scope edge cases
        }
        return window.CONFIG || {};
    },

    _withTimeout(ms) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), ms || Api.config.REQUEST_TIMEOUT);
        return { controller, timer };
    },

    async _readJsonResponse(response) {
        const text = await response.text();
        let json = null;
        try {
            json = text ? JSON.parse(text) : {};
        } catch (e) {
            throw new Error(`响应不是合法 JSON: ${text.slice(0, 120)}`);
        }
        if (!response.ok) {
            throw new Error(json?.msg || json?.message || `HTTP ${response.status}`);
        }
        return json;
    },

    getSdkConfig() {
        const cfg = this._getRuntimeConfig();
        return {
            base: cfg.API_SDK_BASE || Api.config.SDK.BASE,
            key: cfg.API_SDK_KEY || Api.config.SDK.KEY,
            profilePath: cfg.API_SDK_PROFILE_PATH || 'dy/dyzy.php',
            searchPath: cfg.API_SDK_SEARCH_PATH || 'dy/dyzy.php',
            videoPath: cfg.API_SDK_VIDEO_PATH || 'dy/dyzy.php',
            keyParam: cfg.API_SDK_KEY_PARAM || 'key',
            urlParam: cfg.API_SDK_URL_PARAM || 'msg',
            searchParam: cfg.API_SDK_SEARCH_PARAM || 'msg',
            typeParam: cfg.API_SDK_TYPE_PARAM || 'type'
        };
    },

    /**
     * 核心请求方法 (替代原 apiFetch)
     */
    async fetch(endpoint, action, data = {}) {
        const formData = new FormData();
        formData.append('action', action);

        // 自动注入当前用户ID (依赖全局 app 对象)
        if (window.app && window.app.accountManager && window.app.accountManager.user) {
            const uid = window.app.accountManager.user.id;
            formData.append('user_id', uid);
            formData.append('uid', uid);
        }

        // 追加数据
        for (const key in data) {
            if (data[key] instanceof FileList || Array.isArray(data[key])) {
                // 处理文件数组 (如发帖时的 media[])
                if (Array.isArray(data[key])) {
                    data[key].forEach(file => formData.append(`${key}[]`, file));
                }
            } else if (data[key] !== undefined && data[key] !== null) {
                formData.append(key, data[key]);
            }
        }

        const url = endpoint.startsWith('http') ? endpoint : this._joinUrl(this.config.BASE_URL, endpoint);

        const timeout = this._withTimeout(this.config.REQUEST_TIMEOUT);
        try {
            const response = await window.fetch(url, {
                method: 'POST',
                body: formData,
                signal: timeout.controller.signal
            });
            return await this._readJsonResponse(response);
        } catch (e) {
            console.error(`[API Error] ${endpoint}/${action}:`, e);
            const isAbort = e && (e.name === 'AbortError' || String(e.message || '').includes('aborted'));
            return { code: 500, msg: isAbort ? '请求超时，请稍后重试' : '网络请求失败，请检查连接' };
        } finally {
            clearTimeout(timeout.timer);
        }
    },

    /**
     * 简单的 GET 请求封装
     */
    async get(url, options = {}) {
        const timeout = this._withTimeout(options.timeout || this.config.REQUEST_TIMEOUT);
        try {
            const res = await window.fetch(url, { ...options, signal: timeout.controller.signal });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            return res;
        } finally {
            clearTimeout(timeout.timer);
        }
    },

    async getJson(url, options = {}) {
        const timeout = this._withTimeout(options.timeout || this.config.REQUEST_TIMEOUT);
        try {
            const res = await window.fetch(url, { ...options, signal: timeout.controller.signal });
            return await this._readJsonResponse(res);
        } finally {
            clearTimeout(timeout.timer);
        }
    },

    // ================= 模块化接口 =================

    /** 账号与权限 */
    Auth: {
        async loginOrRegister(username, password, deviceId, isWebIde) {
            return Api.fetch('chat_api.php', 'login_or_register', {
                username, password, device_id: deviceId, is_webide: isWebIde
            });
        },
        // 更新资料 (昵称/头像)
        async updateProfile(userId, username, avatar) {
            return Api.fetch('chat_api.php', 'update_profile', {
                action: 'update_profile',
                user_id: userId,
                username, avatar
            });
        },
        // 获取用户信息
        async getUserInfo(userId) {
            return Api.fetch('chat_api.php', 'get_user_info', { user_id: userId });
        },
        // 获取他人主页信息
        async getUserProfile(targetId, currentId) {
            return Api.fetch('chat_api.php', 'get_user_profile', { target_id: targetId, current_id: currentId });
        },
        async adminOp(adminId, targetId, opType, val) {
            return Api.fetch('chat_api.php', 'user_op', {
                admin_id: adminId,
                target_id: targetId,
                op_type: opType,
                val: val
            });
        }
    },

    /** 聊天室 */
    Chat: {
        async getMessages(lastId) {
            return Api.fetch('chat_api.php', 'get_msgs', { last_id: lastId });
        },
        async sendMessage(uid, content, type, quoteData = {}) {
            const payload = { uid, content, type, ...quoteData };
            return Api.fetch('chat_api.php', 'send_msg', payload);
        },
        async deleteMessage(msgId, userId, isAdmin) {
            return Api.fetch('chat_api.php', 'delete_msg', {
                msg_id: msgId,
                user_id: userId,
                is_admin: isAdmin
            });
        }
    },

    /** 圈子/社区 */
    Circle: {
        async getCircles() {
            return Api.fetch('circle_api.php', 'get_circles');
        },
        async getCircleInfo(circleId, userId) {
            return Api.fetch('circle_api.php', 'get_circle_info', { circle_id: circleId, user_id: userId });
        },
        async joinToggle(circleId, userId, type) {
            return Api.fetch('circle_api.php', 'join_toggle', { circle_id: circleId, user_id: userId, type });
        },
        async getPostList(params) {
            // params: { page, circle_id, user_id, keyword }
            return Api.fetch('circle_api.php', 'get_post_list', params);
        },
        async toggleLike(postId, userId) {
            return Api.fetch('circle_api.php', 'toggle_like', { post_id: postId, user_id: userId });
        },
        async createPost(formData) {
            // 特殊处理：发帖通常包含文件，formData 由外部构建更方便，这里直接透传
            const url = Api._joinUrl(Api.config.BASE_URL, 'circle_api.php');
            try {
                const res = await window.fetch(url, { method: 'POST', body: formData });
                return await res.json();
            } catch (e) {
                return { code: 500, msg: '发布请求失败' };
            }
        },
        async manageCircle(data) {
            return Api.fetch('circle_api.php', 'manage_circle', data);
        },
        async createCircle(userId, name, desc) {
            return Api.fetch('circle_api.php', 'create_circle', { user_id: userId, name, desc });
        },
        async rewardPost(userId, postId, amount) {
            return Api.fetch('circle_api.php', 'reward_post', { user_id: userId, post_id: postId, amount });
        },
        async getUserPosts(userId, currentId = 0) { return Api.fetch('circle_api.php', 'get_user_posts', { target_user_id: userId, user_id: currentId || userId }); },
        async getUserCircles(userId) { return Api.fetch('circle_api.php', 'get_user_circles', { target_user_id: userId, user_id: userId }); },
        async getUserLikes(userId, currentId = 0) { return Api.fetch('circle_api.php', 'get_user_likes', { target_user_id: userId, user_id: currentId || userId }); },
        async getCoinHistory(userId) { return Api.fetch('circle_api.php', 'get_coin_history', { user_id: userId }); },
        async getComments(postId, page = 1) { return Api.fetch('circle_api.php', 'get_comments', { post_id: postId, page }); },
        async addComment(postId, userId, content, replyId = 0) { return Api.fetch('circle_api.php', 'add_comment', { post_id: postId, user_id: userId, content, reply_id: replyId || 0 }); },
        async deleteComment(commentId, userId) { return Api.fetch('circle_api.php', 'delete_comment', { comment_id: commentId, user_id: userId }); }
    },

    /** 外部第三方 SDK 接口 */
    External: {
        // 抖音主页解析 (支持 AbortSignal)
        async fetchDouyinProfile(url, signal) {
            const sdk = Api.getSdkConfig();
            const params = new URLSearchParams();
            // 有key时才带入key参数
            if (sdk.key && sdk.key.trim() !== '') {
                params.set(sdk.keyParam, sdk.key);
            }
            params.set(sdk.urlParam, url);
            const apiUrl = `${sdk.base}/${sdk.profilePath}?${params.toString()}`;
            const options = signal ? { signal } : {};
            const json = await Api.getJson(apiUrl, options);

            // 兼容新旧API格式：新API返回 {code:200, msg:"success", data:[...]}
            if (json && json.code === 200 && Array.isArray(json.data)) {
                // 对作品数据内部的参数名进行适配
                const adaptedData = json.data.map(item => this._adaptWorkItem(item));

                return {
                    ...json,
                    // 转换为旧格式兼容性
                    aweme_list: adaptedData,
                    has_more: json.pagination ? json.pagination.has_more : false,
                    next_url: json.pagination ? this._buildNextUrl(url, json.pagination) : null
                };
            }

            return json;
        },

        // 构建下一页URL（兼容新API格式）
        _buildNextUrl(originalUrl, pagination) {
            if (!pagination || !pagination.has_more) return null;

            // 基于新API的分页逻辑构建下一页URL
            // 如果pagination包含cursor或page信息，可以构建分页URL
            if (pagination.cursor) {
                // 基于游标的分页
                const urlObj = new URL(originalUrl);
                urlObj.searchParams.set('cursor', pagination.cursor);
                return urlObj.toString();
            } else if (pagination.page && pagination.pages > pagination.page) {
                // 基于页码的分页
                const urlObj = new URL(originalUrl);
                urlObj.searchParams.set('page', pagination.page + 1);
                return urlObj.toString();
            }

            return null;
        },

        // 适配作品信息参数名（兼容新旧API格式）
        _adaptWorkItem(item) {
            if (!item || typeof item !== 'object') return item;

            const adapted = { ...item };

            // 作者信息适配
            if (adapted.author_info) {
                // 新格式：author_info -> 旧格式：author
                if (adapted.author_info.nickname && !adapted.author) {
                    adapted.author = adapted.author_info.nickname;
                }
                if (adapted.author_info.avatar && !adapted.avatar) {
                    adapted.avatar = adapted.author_info.avatar;
                }
                // 适配更多作者信息字段
                if (adapted.author_info.unique_id && !adapted.unique_id) {
                    adapted.unique_id = adapted.author_info.unique_id;
                }
                if (adapted.author_info.signature && !adapted.signature) {
                    adapted.signature = adapted.author_info.signature;
                }
            }

            // 直接作者字段适配（如果API直接返回author字段）
            if (adapted.author && typeof adapted.author === 'object') {
                if (adapted.author.nickname && !adapted.author_name) {
                    adapted.author_name = adapted.author.nickname;
                }
                if (adapted.author.avatar && !adapted.avatar) {
                    adapted.avatar = adapted.author.avatar;
                }
            }

            // 适配您提供的新抖音数据格式
            // 作者信息适配
            if (adapted.author_uid && !adapted.author_id) {
                adapted.author_id = adapted.author_uid;
            }
            if (adapted.author_sec_uid && !adapted.author_sec_id) {
                adapted.author_sec_id = adapted.author_sec_uid;
            }
            if (adapted.author_avatar && !adapted.avatar) {
                adapted.avatar = adapted.author_avatar;
            }
            if (adapted.author_avatar_proxy && !adapted.avatar_proxy) {
                adapted.avatar_proxy = adapted.author_avatar_proxy;
            }
            if (adapted.author_avatar_download && !adapted.avatar_download) {
                adapted.avatar_download = adapted.author_avatar_download;
            }

            // 作品信息适配
            if (adapted.desc && !adapted.description) {
                adapted.description = adapted.desc;
            }
            if (adapted.aweme_id && !adapted.awemeId) {
                adapted.awemeId = adapted.aweme_id;
            }
            if (adapted.create_time && !adapted.createTime) {
                adapted.createTime = adapted.create_time;
            }
            if (adapted.share_url && !adapted.shareUrl) {
                adapted.shareUrl = adapted.share_url;
            }

            // 封面图适配
            if (adapted.cover && !adapted.cover_url) {
                adapted.cover_url = adapted.cover;
            }
            if (adapted.dynamic_cover && !adapted.cover_url) {
                adapted.cover_url = adapted.dynamic_cover;
            }
            if (adapted.cover_proxy && !adapted.cover_proxy_url) {
                adapted.cover_proxy_url = adapted.cover_proxy;
            }

            // 视频信息适配
            if (adapted.video_info) {
                if (adapted.video_info.duration && !adapted.duration) {
                    adapted.duration = adapted.video_info.duration;
                }
                if (adapted.video_info.play_addr && !adapted.play_addr) {
                    adapted.play_addr = adapted.video_info.play_addr;
                }
                if (adapted.video_info.download_addr && !adapted.download_addr) {
                    adapted.download_addr = adapted.video_info.download_addr;
                }
                // 适配更多视频信息
                if (adapted.video_info.width && !adapted.width) {
                    adapted.width = adapted.video_info.width;
                }
                if (adapted.video_info.height && !adapted.height) {
                    adapted.height = adapted.video_info.height;
                }
            }

            // 适配您提供的新抖音数据格式 - 视频信息
            if (adapted.duration && !adapted.video_duration) {
                adapted.video_duration = adapted.duration;
            }
            if (adapted.video && !adapted.video_url) {
                adapted.video_url = adapted.video;
            }
            if (adapted.video_proxy && !adapted.video_proxy_url) {
                adapted.video_proxy_url = adapted.video_proxy;
            }
            if (adapted.download_url && !adapted.video_download_url) {
                adapted.video_download_url = adapted.download_url;
            }

            // 图片信息适配
            if (adapted.images && Array.isArray(adapted.images)) {
                if (!adapted.image_urls) {
                    adapted.image_urls = adapted.images;
                }
            }
            if (adapted.images_proxy && Array.isArray(adapted.images_proxy)) {
                if (!adapted.image_proxy_urls) {
                    adapted.image_proxy_urls = adapted.images_proxy;
                }
            }
            if (adapted.download_urls && Array.isArray(adapted.download_urls)) {
                if (!adapted.image_download_urls) {
                    adapted.image_download_urls = adapted.download_urls;
                }
            }

            // 音乐信息适配
            if (adapted.music_info) {
                if (adapted.music_info.title && !adapted.music_title) {
                    adapted.music_title = adapted.music_info.title;
                }
                if (adapted.music_info.author && !adapted.music_author) {
                    adapted.music_author = adapted.music_info.author;
                }
                if (adapted.music_info.cover && !adapted.music_cover) {
                    adapted.music_cover = adapted.music_info.cover;
                }
                if (adapted.music_info.play_url && !adapted.music_play_url) {
                    adapted.music_play_url = adapted.music_info.play_url;
                }
                if (adapted.music_info.duration && !adapted.music_duration) {
                    adapted.music_duration = adapted.music_info.duration;
                }
            }

            // 适配您提供的新抖音数据格式 - 音乐信息
            if (adapted.music_title && !adapted.music_name) {
                adapted.music_name = adapted.music_title;
            }
            if (adapted.music_author && !adapted.music_artist) {
                adapted.music_artist = adapted.music_author;
            }
            if (adapted.music_url && !adapted.music_play_url) {
                adapted.music_play_url = adapted.music_url;
            }
            if (adapted.music_proxy && !adapted.music_proxy_url) {
                adapted.music_proxy_url = adapted.music_proxy;
            }
            if (adapted.music_download && !adapted.music_download_url) {
                adapted.music_download_url = adapted.music_download;
            }

            // 统计信息适配
            if (adapted.statistics) {
                if (adapted.statistics.digg_count !== undefined && adapted.digg_count === undefined) {
                    adapted.digg_count = adapted.statistics.digg_count;
                }
                if (adapted.statistics.comment_count !== undefined && adapted.comment_count === undefined) {
                    adapted.comment_count = adapted.statistics.comment_count;
                }
                if (adapted.statistics.share_count !== undefined && adapted.share_count === undefined) {
                    adapted.share_count = adapted.statistics.share_count;
                }
                if (adapted.statistics.collect_count !== undefined && adapted.collect_count === undefined) {
                    adapted.collect_count = adapted.statistics.collect_count;
                }
            }

            // 适配您提供的新抖音数据格式 - 统计信息
            if (adapted.digg_count !== undefined && adapted.like_count === undefined) {
                adapted.like_count = adapted.digg_count;
            }
            if (adapted.comment_count !== undefined && adapted.comment_count === undefined) {
                adapted.comment_count = adapted.comment_count;
            }
            if (adapted.share_count !== undefined && adapted.share_count === undefined) {
                adapted.share_count = adapted.share_count;
            }
            if (adapted.collect_count !== undefined && adapted.collect_count === undefined) {
                adapted.collect_count = adapted.collect_count;
            }
            if (adapted.play_count !== undefined && adapted.view_count === undefined) {
                adapted.view_count = adapted.play_count;
            }

            // 时间信息适配和格式化
            if (adapted.create_time && !adapted.create_time_formatted) {
                adapted.create_time_formatted = this._formatTime(adapted.create_time);
            }
            if (adapted.timestamp && !adapted.create_time_formatted) {
                adapted.create_time_formatted = this._formatTime(adapted.timestamp);
            }

            return adapted;
        },

        // 时间格式化工具函数
        _formatTime(timestamp) {
            return formatRelativeTime(timestamp);
        },

        // 抖音搜索
        async searchDouyin(keyword) {
            const sdk = Api.getSdkConfig();
            const params = new URLSearchParams();
            // 有key时才带入key参数
            if (sdk.key && sdk.key.trim() !== '') {
                params.set(sdk.keyParam, sdk.key);
            }
            params.set(sdk.searchParam, keyword);
            params.set(sdk.typeParam, '0');
            const apiUrl = `${sdk.base}/${sdk.searchPath}?${params.toString()}`;
            const json = await Api.getJson(apiUrl);

            // 兼容新旧API格式
            if (json && json.code === 200 && Array.isArray(json.data)) {
                // 对作品数据内部的参数名进行适配
                const adaptedData = json.data.map(item => this._adaptWorkItem(item));

                return {
                    ...json,
                    // 转换为旧格式兼容性
                    aweme_list: adaptedData
                };
            }

            return json;
        },

        // 单视频链接解析
        async parseVideo(url) {
            const sdk = Api.getSdkConfig();
            const params = new URLSearchParams();
            // 有key时才带入key参数
            if (sdk.key && sdk.key.trim() !== '') {
                params.set(sdk.keyParam, sdk.key);
            }
            params.set(sdk.urlParam, url);
            const apiUrl = `${sdk.base}/${sdk.videoPath}?${params.toString()}`;
            const json = await Api.getJson(apiUrl);

            // 兼容新旧API格式
            if (json && json.code === 200 && json.data) {
                // 对作品数据内部的参数名进行适配
                const adaptedData = this._adaptWorkItem(json.data);

                return {
                    ...json,
                    // 转换为旧格式兼容性
                    item_list: [adaptedData]
                };
            }

            return json;
        }
    },

    /**
     * 下载与文件处理
     * 专门用于 DownloadManager
     */
    Download: {
        /**
         * 获取文件的 Blob 数据
         * @param {string} url - 目标 URL
         * @param {boolean} useProxy - 是否使用代理 (视频通常需要，图片可能不需要)
         */
        async getBlob(url, useProxy = false) {
            // 获取代理前缀
            const proxyPrefix = Api.getProxyPrefix();
            const targetUrl = useProxy ? (proxyPrefix + encodeURIComponent(url)) : url;

            try {
                const res = await window.fetch(targetUrl);
                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                return await res.blob();
            } catch (e) {
                console.warn(`[Download] Blob fetch failed (Proxy: ${useProxy}): ${url}`, e);
                return null;
            }
        }
    },

    /**
     * 获取下载代理地址前缀
     * 对应 DownloadManager 中的 this.proxy
     */
    getProxyPrefix() {
        // 动态适配末尾斜杠
        const base = this.config.BASE_URL.endsWith('/') ? this.config.BASE_URL.slice(0, -1) : this.config.BASE_URL;
        // 假设代理脚本位于 API 根目录的同级或特定路径
        // 原有逻辑：BASE_URL + '/dyzl.php?url='
        return `${base}/dyzl.php?url=`;
    },

    /** 积分与加密工具 */
    Quota: {
        buf2hex(buffer) {
            return [...new Uint8Array(buffer)].map(x => x.toString(16).padStart(2, '0')).join('');
        },
        base64ToBuf(base64) {
            const binary_string = window.atob(base64);
            const len = binary_string.length;
            const bytes = new Uint8Array(len);
            for (let i = 0; i < len; i++) bytes[i] = binary_string.charCodeAt(i);
            return bytes;
        },
        async generateSign(token, timestamp) {
            const str = token + timestamp + Api.config.SECRET;
            const encoder = new TextEncoder();
            const data = encoder.encode(str);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            return this.buf2hex(hashBuffer);
        },
        async decryptData(encryptedBase64, ivBase64) {
            try {
                const encoder = new TextEncoder();
                const keyData = encoder.encode(Api.config.SECRET);
                const keyHashBuffer = await crypto.subtle.digest('SHA-256', keyData);
                const keyHashHex = this.buf2hex(keyHashBuffer);
                const rawKeyStr = keyHashHex.substring(0, 16);
                const rawKeyBytes = encoder.encode(rawKeyStr);
                const key = await crypto.subtle.importKey('raw', rawKeyBytes, { name: 'AES-CBC' }, false, ['decrypt']);
                const encryptedBuffer = this.base64ToBuf(encryptedBase64);
                const ivBuffer = this.base64ToBuf(ivBase64);
                const decryptedBuffer = await crypto.subtle.decrypt({ name: 'AES-CBC', iv: ivBuffer }, key, encryptedBuffer);
                const decoder = new TextDecoder();
                return JSON.parse(decoder.decode(decryptedBuffer));
            } catch (e) {
                console.error('解密失败:', e);
                return null;
            }
        },
        async verifyToken(token) {
            const timestamp = Math.floor(Date.now() / 1000);
            const sign = await this.generateSign(token, timestamp);
            const timeout = Api._withTimeout(Api.config.REQUEST_TIMEOUT);
            try {
                const response = await window.fetch(Api._joinUrl(Api.config.BASE_URL, 'verify_token.php'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ token, timestamp, sign }),
                    signal: timeout.controller.signal
                });
                return { raw: await Api._readJsonResponse(response), token, timestamp };
            } finally {
                clearTimeout(timeout.timer);
            }
        }
    }
};

// 挂载到全局
window.Api = Api;
window.API_BASE = Api.config.BASE_URL; // 兼容旧代码引用
