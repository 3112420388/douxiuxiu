const bind = (fn) => (typeof fn === 'function' ? fn : undefined);

const DEFAULT_NATIVE_CAPABILITY_POLICY = {
  allowLoadSource: false,
  allowExecJava: false,
  allowExecSh: false,
  allowInjectScript: false,
};

const getNativePolicy = () => ({
  ...DEFAULT_NATIVE_CAPABILITY_POLICY,
  ...(window.NATIVE_CAPABILITY_POLICY || {}),
});

const denyNative = (name) => {
  console.warn(`[nativeBridge] blocked high-risk native capability: ${name}`);
  try { window.webapp?.显示文本提示?.('该原生能力已被安全策略限制'); } catch {}
  return undefined;
};

const guardedNative = (policyKey, name, fn) => (...args) => {
  if (getNativePolicy()[policyKey] === true) return fn(...args);
  return denyNative(name);
};

export const getNative = () => {
  const webapp = window.webapp;
  const webide = window.webide;
  if (!webapp && !webide) return null;

  return {
    raw: {
      webapp,
      webide,
    },
    app: {
      name: () => webapp?.获取应用名称?.(),
      packageName: () => webapp?.获取应用包名?.(),
      versionName: () => webapp?.获取应用版名?.(),
      versionCode: () => webapp?.获取应用版号?.(),
      clipboard: () => webapp?.获取粘贴内容?.(),
      deviceId: () => webapp?.获取设备ID?.(),
      signature: () => webapp?.获取应用签名?.(),
    },
    floating: {
      start: (url, width, height, hideToolbar, x, y) =>
        webapp?.启动悬浮窗?.(url, width, height, hideToolbar, x, y),
      hasPermission: () => webapp?.判断悬浮窗权限?.(),
      openPermission: () => webapp?.打开悬浮窗权限?.(),
      close: () => webapp?.关闭悬浮窗?.(),
      minimize: () => webapp?.最小化悬浮窗?.(),
      setSize: (width, height) => webapp?.设置悬浮窗大小?.(width, height),
      setPosition: (x, y) => webapp?.设置悬浮窗位置?.(x, y),
      setFocusable: (enabled) => webapp?.设置悬浮窗焦点?.(enabled),
      showToolbar: (visible) => webapp?.悬浮窗工具条?.(visible),
    },
    control: {
      launchApp: (packageName) => webapp?.启动指定应用?.(packageName),
      hasApp: (packageName) => webapp?.判断指定应用?.(packageName),
      uninstallApp: (packageName) => webapp?.卸载指定应用?.(packageName),
      setDownloadConfirm: (enabled) => webapp?.隐藏下载提示?.(enabled),
      setDownloadEnabled: (enabled) => webapp?.关闭下载功能?.(enabled),
      listenExternalLink: (fnName) => webapp?.监听外部链接?.(fnName),
      loadSource: guardedNative('allowLoadSource', 'control.loadSource', (url, html) => webapp?.加载源代码?.(url, html)),
      openPage: (url) => webapp?.打开指定页面?.(url),
      openExternalBrowser: (url) => webapp?.外部浏览器打开?.(url),
      clearHistory: () => webapp?.清空浏览记录?.(),
      setLoadingEffect: (enabled) => webapp?.设置加载效果?.(enabled),
      setPullToRefresh: (enabled) => webapp?.设置下拉刷新?.(enabled),
      setBlockExternalOpen: (enabled) => webapp?.关闭跳转打开?.(enabled),
      setLoadFailedScript: (script) => webapp?.加载失败内容?.(script),
      setBackButtonScript: (script) => webapp?.自定义返回键?.(script),
      setVolumeKeyScript: (isUp, script) => webapp?.自定义声音键?.(isUp, script),
      setLandscape: (enabled) => webapp?.设置横屏模式?.(enabled),
      setPortrait: (enabled) => webapp?.设置竖屏模式?.(enabled),
      setFullscreen: (enabled) => webapp?.设置全屏模式?.(enabled),
      setDarkMode: (enabled) => webapp?.设置深色模式?.(enabled),
      setAppJumpPrompt: (enabled) => webapp?.应用跳转提示?.(enabled),
      openDefaultHome: () => webapp?.打开默认主页?.(),
      setLongPress: (fnName) => webapp?.设置长按事件?.(fnName),
      addShortcut: (name, iconBase64, script, id, isAppShortcut) =>
        webapp?.添加快捷方式?.(name, iconBase64, script, id, isAppShortcut),
      removeShortcut: (id) => webapp?.移除快捷方式?.(id),
      removeAllShortcuts: () => webapp?.移除全部快捷?.(),
      supportsShortcut: () => webapp?.判断快捷方式?.(),
    },
    permission: {
      hasStorage: () => webapp?.判断存储权限状态?.(),
      requestStorage: () => webapp?.申请存储权限?.(),
      onStorage: (fnName) => webapp?.存储权限回调?.(fnName),
      hasInstall: () => webapp?.判断安装权限?.(),
      openInstallPermission: () => webapp?.打开安装权限?.(),
      isVpnEnabled: () => webapp?.判断抓包状态?.(),
      notify: (id, title, content, script) => webapp?.发送状态栏内容?.(id, title, content, script),
      removeNotify: (id) => webapp?.移除状态栏内容?.(id),
      clearNotify: () => webapp?.清空状态栏内容?.(),
      hasNotify: () => webapp?.判断通知权限?.(),
      openNotifySettings: () => webapp?.打开通知设置?.(),
      startPip: (wRatio, hRatio, fnName) => webapp?.启动画中画?.(wRatio, hRatio, fnName),
      openPipPermission: () => webapp?.打开画中画权限?.(),
      hasPipPermission: () => webapp?.判断画中画权限?.(),
      supportsPip: () => webapp?.判断画中画支持?.(),
      supportsDarkMode: () => webapp?.判断深色模式支持?.(),
      isDarkMode: () => webapp?.判断深色模式状态?.(),
    },
    system: {
      execJava: guardedNative('allowExecJava', 'system.execJava', (code) => webapp?.执行JAVA?.(code)),
      execSh: guardedNative('allowExecSh', 'system.execSh', (workdir, env, code, fnName) => webapp?.执行SH命令?.(workdir, env, code, fnName)),
      stopSh: () => webapp?.停止SH服务?.(),
      exit: () => webapp?.关闭应用退出?.(),
      goHome: () => webapp?.回到系统桌面?.(),
      setNoImage: (enabled) => webapp?.设置无图显示?.(enabled),
      toast: (message) => webapp?.显示文本提示?.(message),
      shareText: (text) => webapp?.分享文本内容?.(text),
      openDownloadManager: () => webapp?.打开下载管理?.(),
      setAutoInstall: (enabled) => webapp?.设置自动安装?.(enabled),
      openSystemSettings: () => webapp?.打开系统设置?.(),
      hasBatteryOptimize: () => webapp?.判断优化权限?.(),
      requestBatteryOptimize: () => webapp?.申请优化权限?.(),
      setBackground: (enabled) => webapp?.设置后台状态?.(enabled),
      systemVersion: () => webapp?.获取系统版本?.(),
      openAppDetail: () => webapp?.当前应用详情?.(),
      setStatusBarColor: (color) => webapp?.设置状态栏变色?.(color),
      setAutoPlay: (enabled) => webapp?.设置自动播放?.(enabled),
      setAutoFullscreen: (enabled) => webapp?.设置全屏横屏?.(enabled),
      getBrightness: () => webapp?.获取亮度参数?.(),
      setBrightness: (value) => webapp?.设置亮度参数?.(value),
      getVolume: () => webapp?.获取声音参数?.(),
      setVolume: (value) => webapp?.设置声音参数?.(value),
      setScreenOn: (enabled) => webapp?.设置屏幕常亮?.(enabled),
      setUserAgent: (ua) => webapp?.用户代理字符串?.(ua),
      injectScript: guardedNative('allowInjectScript', 'system.injectScript', (script) => webapp?.动态添加脚本?.(script)),
      intent: (action) => webapp?.意图跳转功能?.(action),
      sendBroadcast: (action, key, value) => webapp?.设置发送广播?.(action, key, value),
      receiveBroadcast: (action, key, fnName) => webapp?.设置接收广播?.(action, key, fnName),
      stopBroadcast: () => webapp?.关闭广播服务?.(),
      setDebug: (enabled) => webapp?.设置调试功能?.(enabled),
      clearCache: () => webapp?.设置清空缓存?.(),
      setCacheMode: (disableCache) => webapp?.设置缓存模式?.(disableCache),
    },
    network: {
      setIntercept: (rule) => webapp?.设置拦截参数?.(rule),
      getUrlScheme: () => webapp?.获取URL协议?.(),
    },
    file: {
      externalStorage: () => webapp?.获取外部存储目录?.(),
      externalFiles: () => webapp?.获取外部文件目录?.(),
      internalFiles: () => webapp?.获取内部文件目录?.(),
      pickDir: (fnName) =>
        webapp?.选择文件夹?.(fnName) ??
        webapp?.选择目录?.(fnName) ??
        webapp?.选择文件夹路径?.(fnName) ??
        webapp?.打开文件夹选择?.(fnName),
      list: (path) => webapp?.获取目录排列?.(path),
      read: (path) => webapp?.获取文件内容?.(path),
      size: (path) => webapp?.获取文件大小?.(path),
      save: (path, data) => webapp?.保存指定文件?.(path, data),
      append: (path, data) => webapp?.文件追加保存?.(path, data),
      remove: (path) => webapp?.删除指定文件?.(path),
      rename: (path, name) => webapp?.更改指定文件名?.(path, name),
      exists: (path) => webapp?.判断指定文件?.(path),
      share: (path) => webapp?.分享指定文件?.(path),
      open: (path) => webapp?.打开指定文件?.(path),
      getAsset: (name) => webapp?.获取应用文件?.(name),
      saveDownload: (name, data) => webapp?.保存下载文件?.(name, data),
    },
    storage: {
      setText: (key, value) => webapp?.存储指定文本?.(key, value),
      getText: (key, def) => webapp?.获取指定文本?.(key, def),
      setBool: (key, value) => webapp?.存储指定布尔?.(key, value),
      getBool: (key, def) => webapp?.获取指定布尔?.(key, def),
      remove: (key) => webapp?.删除指定存储?.(key),
      clear: () => webapp?.清空全部存储?.(),
    },
    plugin: {
      register: (id, script) => webide?.plugin?.(id, script),
    },
  };
};
