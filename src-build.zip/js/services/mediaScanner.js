const DEFAULT_AUDIO_FORMATS = [
  '.mp3',
  '.m4a',
  '.flac',
  '.wav',
  '.ogg',
  '.aac',
  '.wma',
  '.amr',
  '.aiff',
  '.aif',
  '.alac',
  '.opus',
  '.mid',
  '.midi',
  '.mp2',
  '.mp1',
  '.ac3',
  '.ape',
  '.dts',
  '.mka',
  '.pcm',
];
const DEFAULT_VIDEO_FORMATS = [
  '.mp4',
  '.mkv',
  '.avi',
  '.3gp',
  '.webm',
  '.mov',
  '.flv',
  '.f4v',
  '.wmv',
  '.mpg',
  '.mpeg',
  '.m4v',
  '.ts',
  '.mts',
  '.m2ts',
  '.vob',
  '.rm',
  '.rmvb',
];
const DEFAULT_IMAGE_FORMATS = [
  '.jpg',
  '.jpeg',
  '.png',
  '.gif',
  '.bmp',
  '.webp',
  '.heic',
  '.heif',
  '.tif',
  '.tiff',
  '.svg',
];
const DEFAULT_DOCUMENT_FORMATS = [
  '.pdf',
  '.doc',
  '.docx',
  '.ppt',
  '.pptx',
  '.xls',
  '.xlsx',
  '.wps',
  '.rtf',
];
const DEFAULT_TEXT_FORMATS = [
  '.txt',
  '.md',
  '.log',
  '.json',
  '.xml',
  '.csv',
  '.ini',
  '.yaml',
  '.yml',
];
const DEFAULT_IGNORE_DIRS = [
  '/Android/data',
  '/Android/obb',
  '/.thumbnail',
  '/cache',
  '/log',
  '/temp',
  '/backups',
  '/.git',
  '/node_modules',
  '/Code',
  '/Alipay',
  '/Tencent/MicroMsg',
  '/DingTalk',
  '/bilibili',
  // v4: do not ignore /DCIM/Camera by default; many user videos live there.
];

const MIN_AUDIO_SIZE = 1024 * 500;
const MIN_VIDEO_SIZE = 1024 * 1024 * 2;
const MIN_IMAGE_SIZE = 0;
const MIN_DOCUMENT_SIZE = 0;
const MIN_TEXT_SIZE = 0;

export const parseNativeList = (listStr) => {
  if (!listStr || listStr === 'null') return [];
  if (Array.isArray(listStr)) return listStr;
  if (typeof listStr === 'string') {
    const trimmed = listStr.trim();
    if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
      try {
        const parsed = JSON.parse(trimmed);
        if (Array.isArray(parsed)) return parsed;
      } catch {
        // fall through to split
      }
    }
  }
  return String(listStr)
    .split(/\\|\n/)
    .map((f) => f.trim())
    .filter((f) => f && f !== '.' && f !== '..' && f !== '/');
};

import { getNative } from './nativeBridge.js';

const ensureStoragePermission = (native) => {
  if (!native) return false;
  try {
    const has =
      (native.permission?.hasStorage?.()) ??
      (native.system?.hasStorage?.());
    if (has === false) {
      if (native.permission?.requestStorage) {
        native.permission.requestStorage();
      } else if (native.system?.requestStorage) {
        native.system.requestStorage();
      }
      return false;
    }
  } catch {
    // ignore permission check failures
  }
  return true;
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const normalizePath = (value) => String(value || '').replace(/\\/g, '/').replace(/\/+$/, '');

const isIgnoredPath = (path, ignoreDirs) => {
  if (!path) return false;
  const normalizedPath = normalizePath(path);
  return (ignoreDirs || []).some((dir) => {
    const normalizedDir = normalizePath(dir);
    if (!normalizedDir) return false;
    return normalizedPath === normalizedDir || normalizedPath.startsWith(`${normalizedDir}/`);
  });
};

const getTypeByName = (name, audioFormats, videoFormats, imageFormats, documentFormats, textFormats) => {
  const lower = name.toLowerCase();
  if (audioFormats.some((ext) => lower.endsWith(ext))) return 'audio';
  if (videoFormats.some((ext) => lower.endsWith(ext))) return 'video';
  if (imageFormats.some((ext) => lower.endsWith(ext))) return 'image';
  if (documentFormats.some((ext) => lower.endsWith(ext))) return 'document';
  if (textFormats.some((ext) => lower.endsWith(ext))) return 'text';
  return null;
};

/**
 * @typedef {Object} ScanResult
 * @property {string} path
 * @property {'audio'|'video'|'image'|'document'|'text'} type
 * @property {number} size
 * @property {string} name
 */

/**
 * @typedef {Object} ScanOptions
 * @property {boolean} [recursive=true]
 * @property {string[]} [audioFormats]
 * @property {string[]} [videoFormats]
 * @property {string[]} [imageFormats]
 * @property {string[]} [documentFormats]
 * @property {string[]} [textFormats]
 * @property {string[]} [ignoreDirs]
 * @property {number} [minAudioSize]
 * @property {number} [minVideoSize]
 * @property {number} [minImageSize]
 * @property {number} [minDocumentSize]
 * @property {number} [minTextSize]
 * @property {(info: ScanResult) => void} [onItem]
 * @property {(info: { scanned: number; total?: number; path?: string }) => void} [onProgress]
 * @property {() => boolean} [shouldPause]
 * @property {() => boolean} [shouldCancel]
 * @property {number} [maxDepth=12]
 * @property {number} [maxFiles=10000]
 * @property {number} [maxDurationMs=120000]
 * @property {number} [batchSize=100]
 * @property {(items: ScanResult[]) => void} [onBatch]
 */

const awaitIfPaused = async (options) => {
  while (options.shouldPause?.()) {
    if (options.shouldCancel?.()) return false;
    await sleep(150);
  }
  return true;
};

const scanDirectoryInternal = async (native, dirPath, options, results, depth = 0) => {
  if (options.shouldCancel?.()) return;
  if (results.length >= options.maxFiles) return;
  if (Date.now() - options._startedAt > options.maxDurationMs) return;
  if (depth > options.maxDepth) return;
  if (!(await awaitIfPaused(options))) return;
  if (isIgnoredPath(dirPath, options.ignoreDirs)) return;

  const cleanPath = dirPath.replace(/\/$/, '');
  try {
    if (native.file?.exists?.(cleanPath) === false) return;
  } catch {
    // ignore exists check failures
  }

  let items = [];
  try {
    const listStr = native.file?.list?.(cleanPath);
    items = parseNativeList(listStr);
  } catch {
    return;
  }
  if (!items.length) return;

  for (const item of items) {
    if (options.shouldCancel?.()) return;
    if (!(await awaitIfPaused(options))) return;
    const isDir = item.endsWith('/');
    const name = isDir ? item.slice(0, -1) : item;
    const fullPath = `${cleanPath}/${name}`;
    const type = getTypeByName(
      name,
      options.audioFormats,
      options.videoFormats,
      options.imageFormats,
      options.documentFormats,
      options.textFormats
    );

    if (type && !isDir) {
      let size = -1;
      try {
        size = native.file?.size?.(fullPath);
      } catch {
        size = -1;
      }

      if (type === 'audio' && typeof size === 'number' && size >= 0 && size < options.minAudioSize) {
        continue;
      }
      if (type === 'video' && typeof size === 'number' && size >= 0 && size < options.minVideoSize) {
        continue;
      }
      if (type === 'image' && typeof size === 'number' && size >= 0 && size < options.minImageSize) {
        continue;
      }
      if (type === 'document' && typeof size === 'number' && size >= 0 && size < options.minDocumentSize) {
        continue;
      }
      if (type === 'text' && typeof size === 'number' && size >= 0 && size < options.minTextSize) {
        continue;
      }

      const info = { path: fullPath, type, size, name };
      results.push(info);
      options._batch.push(info);
      if (options.onItem) options.onItem(info);
      if (options.onBatch && options._batch.length >= options.batchSize) {
        options.onBatch(options._batch.splice(0, options._batch.length));
      }
      if (options.onProgress) options.onProgress({ scanned: results.length, path: fullPath });
      if (results.length >= options.maxFiles) return;
    } else if (options.recursive && isDir) {
      if (!(await awaitIfPaused(options))) return;
      await sleep(0);
      await scanDirectoryInternal(native, fullPath, options, results, depth + 1);
    }
  }
};

/**
 * Scan one or more directories for audio/video files.
 * @param {string[]|string} paths
 * @param {ScanOptions} [options]
 * @returns {Promise<ScanResult[]>}
 */
export const scanMedia = async (paths, options = {}) => {
  const native = getNative();
  if (!native || !ensureStoragePermission(native)) return [];

  const merged = {
    recursive: true,
    audioFormats: DEFAULT_AUDIO_FORMATS,
    videoFormats: DEFAULT_VIDEO_FORMATS,
    imageFormats: DEFAULT_IMAGE_FORMATS,
    documentFormats: DEFAULT_DOCUMENT_FORMATS,
    textFormats: DEFAULT_TEXT_FORMATS,
    ignoreDirs: DEFAULT_IGNORE_DIRS,
    minAudioSize: MIN_AUDIO_SIZE,
    minVideoSize: MIN_VIDEO_SIZE,
    minImageSize: MIN_IMAGE_SIZE,
    minDocumentSize: MIN_DOCUMENT_SIZE,
    minTextSize: MIN_TEXT_SIZE,
    maxDepth: 12,
    maxFiles: 10000,
    maxDurationMs: 120000,
    batchSize: 100,
    _startedAt: Date.now(),
    _batch: [],
    ...options,
  };

  const targetPaths = Array.isArray(paths) ? paths : [paths];
  const results = [];

  for (const path of targetPaths) {
    if (merged.shouldCancel?.()) break;
    if (!(await awaitIfPaused(merged))) break;
    await scanDirectoryInternal(native, path, merged, results, 0);
  }

  if (merged.onBatch && merged._batch.length) {
    merged.onBatch(merged._batch.splice(0, merged._batch.length));
  }

  return results;
};

export const MEDIA_SCAN_DEFAULTS = {
  AUDIO_FORMATS: DEFAULT_AUDIO_FORMATS,
  VIDEO_FORMATS: DEFAULT_VIDEO_FORMATS,
  IMAGE_FORMATS: DEFAULT_IMAGE_FORMATS,
  DOCUMENT_FORMATS: DEFAULT_DOCUMENT_FORMATS,
  TEXT_FORMATS: DEFAULT_TEXT_FORMATS,
  IGNORE_DIRS: DEFAULT_IGNORE_DIRS,
  MIN_AUDIO_SIZE,
  MIN_VIDEO_SIZE,
  MIN_IMAGE_SIZE,
  MIN_DOCUMENT_SIZE,
  MIN_TEXT_SIZE,
  MAX_DEPTH: 12,
  MAX_FILES: 10000,
  MAX_DURATION_MS: 120000,
};
