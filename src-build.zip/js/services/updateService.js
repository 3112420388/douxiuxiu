/**
 * DxxSystem Core Module v5.5
 * Added: VPN/Packet Capture detection & Strict Signature Enforcement
 */
(function (window, document) {
    'use strict';

    const escapeHTML = (value) => String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\"/g, '&quot;')
        .replace(/'/g, '&#39;');
    const normalizeRichTextSource = (value) => {
        if (Array.isArray(value)) return value.map(v => String(v ?? '')).join('\n');
        if (value && typeof value === 'object') {
            if (Array.isArray(value.lines)) return value.lines.map(v => String(v ?? '')).join('\n');
            if (Array.isArray(value.list)) return value.list.map(v => '- ' + String(v ?? '')).join('\n');
            return JSON.stringify(value, null, 2);
        }
        return String(value ?? '');
    };
    const formatRichText = (value) => {
        let html = escapeHTML(normalizeRichTextSource(value));
        // v4 为安全把更新说明整体转义，导致远程说明中的 <br>/<p>/<ul>/<li> 等格式全部失效。
        // 这里仅恢复无脚本能力的基础排版标签，不恢复 style/on*/href 等属性。
        html = html.replace(/&lt;(\/?)(br|p|div|ul|ol|li|b|strong|i|em|h1|h2|h3|h4)(?:\s+[^&]*?)?\s*\/?&gt;/gi, (m, slash, tag) => {
            tag = String(tag || '').toLowerCase();
            if (tag === 'br') return '<br>';
            return '<' + (slash ? '/' : '') + tag + '>';
        });
        html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        html = html.replace(/^\s*[-*]\s+(.+)$/gm, '• $1');
        html = html.replace(/\n/g, '<br>');
        return html;
    };
    const safeLines = formatRichText;
    // --- 配置常量 ---
    const CONFIG = {
        // 安全配置
        SECURITY: {
            OFFICIAL_SIGNATURE: '0D6E54A998BDBE9C9A162FCD398D3912',
            ERROR_PAGE: '404.html', // 签名错误或抓包时跳转的页面
            CHECK_TIMEOUT: 3000
        },
        // 更新配置
        UPDATE: {
            // 推荐使用多个源以提高可用性（按优先级顺序）
            HOSTS: [
                'https://raw.githubusercontent.com/hillmis/versionControl/main',
                'https://ghproxy.com/https://raw.githubusercontent.com/hillmis/versionControl/main',
                'https://cdn.jsdelivr.net/gh/hillmis/versionControl@main',
                'https://raw.gitmirror.com/hillmis/versionControl/main',
                'https://raw.fastgit.org/hillmis/versionControl/main'
            ],
            CHECK_INTERVAL: 3000000,
            MIN_VISIBLE_CHECK: 2000
        },
        // 公告配置
        ANNOUNCEMENT: {
            HOSTS: [
                'https://raw.githubusercontent.com/hillmis/versionControl/main',
                'https://ghproxy.com/https://raw.githubusercontent.com/hillmis/versionControl/main',
                'https://cdn.jsdelivr.net/gh/hillmis/versionControl@main',
                'https://raw.gitmirror.com/hillmis/versionControl/main',
                'https://raw.fastgit.org/hillmis/versionControl/main'
            ],
            CACHE_DURATION: 3600000, // 1小时缓存
            CHECK_ON_STARTUP: true
        },
        // 接口
        API: {
            HITOKOTO: 'https://www.wudada.online/Api/ScSj'
        },
        // 资源
        ASSETS: {
            ALIPAY: 'https://s3.bmp.ovh/imgs/2025/05/07/1565fff5085e314b.png',
            WECHAT: 'https://s3.bmp.ovh/imgs/2026/01/13/33a0542b1403bb94.jpg'
        }
    };

    class SystemApp {
        constructor() {
            // 初始化状态
            this.state = {
                localCode: typeof webapp !== 'undefined' ? webapp.getcode() : '100',
                currentSign: typeof webapp !== 'undefined' ? webapp.getsign() : '',
                currentVersion: typeof webapp !== 'undefined' ? webapp.getpage() : '1.0.0',
                appName: typeof webapp !== 'undefined' ? webapp.getname() : document.title,
                latestUpdateData: null,
                lastCheckTimestamp: 0,
                hitokoto: '天若有情天亦老，人间正道是沧桑',
                announcements: [],
                lastAnnouncementCheck: 0,
                shownAnnouncementIds: new Set(JSON.parse(localStorage.getItem('shownAnnouncementIds') || '[]'))
            };

            // 绑定上下文
            this.handleImageClick = this.handleImageClick.bind(this);
            this.checkUpdate = this.checkUpdate.bind(this);
            this.openSponsor = this.openSponsor.bind(this);
            this.handleCancelUpdate = this.handleCancelUpdate.bind(this);
            this.openAnnouncementPopup = this.openAnnouncementPopup.bind(this);
            this.getAnnouncements = this.getAnnouncements.bind(this);
            this.checkPopupAnnouncements = this.checkPopupAnnouncements.bind(this);

            // 初始化
            this._initSecurity(); // 优先执行安全检查
            this._initHooks();

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => this._onReady());
            } else {
                this._onReady();
            }
        }

        // --- 生命周期 ---
        _onReady() {
            this._fetchHitokoto();
            this._initVisibilityListener();
            this._verifyIntegrity(); // 再次校验，防止初始化时DOM未加载导致校验跳过

            // --- 修改部分：确保所有内容加载完成后再显示公告 ---
            if (CONFIG.ANNOUNCEMENT.CHECK_ON_STARTUP) {
                // 如果页面已经加载完成（complete），直接执行
                if (document.readyState === 'complete') {
                    this.checkPopupAnnouncements();
                } else {
                    // 否则监听 window 的 load 事件
                    window.addEventListener('load', () => {
                        // 建议增加一个小延迟（如 500ms），确保浏览器渲染压力降低，视觉上更平滑
                        setTimeout(() => {
                            this.checkPopupAnnouncements();
                        }, 500);
                    });
                }
            }
        }

        _initHooks() {
            window.handleImageClick = this.handleImageClick;

        }

        _initVisibilityListener() {
            document.addEventListener('visibilitychange', () => {
                if (document.hidden) {
                    if (this.state.latestUpdateData?.forceUpdate && typeof webapp !== 'undefined') {
                        webapp.secede();
                    }
                } else {
                    const timeSinceLastCheck = Date.now() - this.state.lastCheckTimestamp;
                    if (timeSinceLastCheck > CONFIG.UPDATE.MIN_VISIBLE_CHECK) {
                        this.checkUpdate();
                    }
                }
            });
        }

        // --- 安全模块 (核心修改) ---
        _initSecurity() {
            this._verifyIntegrity();
        }

        _verifyIntegrity() {
            // 1. VPN / 抓包检测 (新增)
            if (typeof webapp !== 'undefined') {
                try {
                    // 调用原生接口判断抓包/VPN状态
                    // 对应 nativeBridge.ts 中的: raw?.['判断抓包状态']?.()
                    if (webapp['判断抓包状态'] && webapp['判断抓包状态']()) {
                        this._handleTampering('非法环境：检测到VPN或抓包代理');
                        // 发现抓包立即跳转 404 或退出
                        window.location.replace(CONFIG.SECURITY.ERROR_PAGE);
                        return false;
                    }
                } catch (e) {
                    // 忽略接口不存在的错误，兼容旧版本
                }
            }

            // 2. 调试模式检测
            if (typeof window.devtools === 'object' || window.outerWidth - window.innerWidth > 100) {
                this._handleTampering('调试模式检测');
            }

            // 3. 签名校验 (修改：不匹配则强制跳转)
            try {
                if (this.state.currentSign && this.state.currentSign !== CONFIG.SECURITY.OFFICIAL_SIGNATURE) {
                    console.warn(`[Security] Signature Mismatch! Expected: ${CONFIG.SECURITY.OFFICIAL_SIGNATURE}, Got: ${this.state.currentSign}`);
                    // 强制跳转到 404 页面
                    window.location.replace(CONFIG.SECURITY.ERROR_PAGE);
                    return false;
                }
                return true;
            } catch (e) {
                this._handleTampering('校验异常');
                return false;
            }
        }

        _handleTampering(reason) {
            console.warn(`[安全警报] ${reason}`);
            if (typeof webapp !== 'undefined') {
                webapp.toast(`安全警告: ${reason}`);
            }
        }

        // --- 数据获取模块 ---
        _fetchHitokoto() {
            const fetchPoem = () => {
                return fetch(CONFIG.API.HITOKOTO)
                    .then(res => res.ok ? res.json() : Promise.reject())
                    .then(data => {
                        const text = data.data || this.state.hitokoto;
                        return text.length > 12 ? fetchPoem() : text;
                    })
                    .catch(() => this.state.hitokoto);
            };

            fetchPoem().then(text => {
                this.state.hitokoto = text;
                const poemEl = document.querySelector('.poem-text');
                if (poemEl) poemEl.textContent = text;
            });
        }

        // --- 更新模块 ---
        _compareVersions(local, remote) {
            const currentNum = Number(local);
            const latestNum = Number(remote);
            if (isNaN(currentNum) || isNaN(latestNum)) return false;
            return latestNum > currentNum;
        }

        async _fetchJsonFromHosts({ hosts, names, validate, logPrefix, failMessage }) {
            const sourceHosts = Array.isArray(hosts) && hosts.length > 0
                ? hosts
                : [];
            const tryUrls = [];
            for (const host of sourceHosts) {
                const base = String(host || '').replace(/\/$/, '');
                if (!base) continue;
                for (const name of names) {
                    tryUrls.push(`${base}/${name}.json?t=${Date.now()}`);
                }
            }

            let lastErr = null;
            for (const url of tryUrls) {
                console.log(`[${logPrefix || 'RemoteJson'}] 尝试获取数据: ${url}`);
                try {
                    const response = await fetch(url);
                    if (!response.ok) {
                        lastErr = new Error(`HTTP错误: ${response.status} @ ${url}`);
                        continue;
                    }
                    const data = await response.json();
                    const validation = validate ? validate(data) : true;
                    if (validation !== true) {
                        lastErr = new Error(validation || '数据格式无效');
                        continue;
                    }
                    return data;
                } catch (err) {
                    lastErr = err;
                }
            }
            throw lastErr || new Error(failMessage || '远程数据获取失败');
        }

        async _fetchRemoteUpdateData() {
            const hosts = Array.isArray(CONFIG.UPDATE.HOSTS) && CONFIG.UPDATE.HOSTS.length > 0
                ? CONFIG.UPDATE.HOSTS
                : [String(CONFIG.UPDATE.HOST || '').replace(/\/$/, '')];
            const candidateNames = [encodeURIComponent(this.state.appName), 'xueleme'];
            return this._fetchJsonFromHosts({
                hosts,
                names: candidateNames,
                logPrefix: 'Update',
                failMessage: '无法获取更新数据',
                validate: (data) => data && data.versionCode && data.versionName ? true : '无效的版本数据格式'
            });
        }

        _extractUpdateTime(data) {
            if (!data) return null;
            return String(data.updadtetime || data.updateTime || data.updateDatetime || '').trim() || null;
        }

        async getUpdateLog() {
            try {
                const data = await this._fetchRemoteUpdateData();
                const updateTime = this._extractUpdateTime(data);
                return {
                    versionName: data.versionName,
                    versionCode: data.versionCode,
                    description: data.description || '',
                    downloadUrl: data.downloadUrl || '',
                    forceUpdate: Boolean(data.forceUpdate),
                    updateTime
                };
            } catch (error) {
                console.error('获取更新日志失败:', error);
                throw error;
            }
        }

        async checkUpdate() {
            try {
                const data = await this._fetchRemoteUpdateData();
                const localCode = this.state.localCode;
                const serverCode = data.versionCode;

                console.log('版本检查:', `本地:${localCode}`, `服务器:${serverCode}`);

                if (this._compareVersions(localCode, serverCode)) {
                    this._createUpdateDialog();
                    this._showUpdateUI(data);
                } else {
                    if (typeof webapp !== 'undefined') webapp.toast('版本检查: 已是最新版本');
                    else console.log('已是最新版本');
                }
            } catch (error) {
                console.error('更新检查失败:', error);
                if (typeof webapp !== 'undefined') webapp.toast('检查更新失败');
            } finally {
                this.state.lastCheckTimestamp = Date.now();
            }
        }

        async showUpdateLog() {
            try {
                const data = await this._fetchRemoteUpdateData();
                this._createUpdateDialog();
                this._showUpdateUI(data);
            } catch (error) {
                console.error('获取更新日志失败:', error);
                if (typeof webapp !== 'undefined') webapp.toast('获取更新日志失败');
            } finally {
                this.state.lastCheckTimestamp = Date.now();
            }
        }

        _createUpdateDialog() {
            if (document.getElementById('updateOverlay')) return;
            const dialog = document.createElement('div');
            dialog.innerHTML = `
        <div id="updateOverlay" style="display: none; position: fixed; top: 0; left: 0; width: 100vw; height: 100dvh; background: rgba(0,0,0,0.5); z-index: 9999; backdrop-filter: blur(4px); padding: 20px; box-sizing: border-box; display: flex; justify-content: center; align-items: center;">
            <div style="background: #ffffff; width: min(95%, 480px); height: 70vh; max-height: 600px; min-height: 350px; border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); overflow: hidden; display: flex; flex-direction: column; animation: modalSlide 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);">
                <div style="padding: 24px; background: #fff; border-bottom: 1px solid #f0f0f0; flex-shrink: 0;">
                    <div style="display: flex; align-items: center; gap: 16px; color: #1f2937;">
                        <div style="width: 48px; height: 48px; background: linear-gradient(135deg, #29c961, #22a350); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; box-shadow: 0 4px 12px rgba(41, 201, 97, 0.3);">
                            <svg viewBox="0 0 24 24" width="28" height="28" style="fill: currentColor"><path d="M14.8 3.8l2.6 5.1 5.8.9c.6.1.8.8.4 1.2l-4.2 4.3 1 5.7c.1.6-.5 1.1-1.1.8L12 18.3l-5 2.7c-.6.3-1.2-.2-1.1-.8l1-5.7-4.2-4.3c-.4-.4-.2-1.1.4-1.2l5.8-.9 2.6-5.1c.3-.6 1.1-.6 1.4 0z"/></svg>
                        </div>
                        <div>
                            <h3 style="margin: 0; font-size: 1.25rem; font-weight: 700; color: #111;">发现新版本</h3>
                            <p style="margin: 4px 0 0 0; font-size: 0.85rem; color: #666;">建议您立即更新</p>
                        </div>
                    </div>
                </div>
                <div id="updateContent" style="flex: 1; padding: 24px; overflow-y: auto; scrollbar-width: thin; background: #fff;"></div>
                <div style="padding: 20px 24px; background: #fff; border-top: 1px solid #f0f0f0; display: flex; gap: 12px; justify-content: flex-end; flex-shrink: 0;">
                    <button id="updateCancel" style="padding: 12px 24px; background: #f5f7fa; border: none; border-radius: 10px; color: #5c6b7f; font-weight: 600; cursor: pointer;">稍后再说</button>
                    <button id="updateConfirm" style="padding: 12px 32px; background: #29c961; border: none; border-radius: 10px; color: white; font-weight: 600; cursor: pointer; box-shadow: 0 4px 12px rgba(41, 201, 97, 0.25);">立即更新</button>
                </div>
            </div>
        </div>
        <style>@keyframes modalSlide { from { opacity: 0; transform: scale(0.95) translateY(10px); } to { opacity: 1; transform: scale(1) translateY(0); } } #updateContent::-webkit-scrollbar { width: 6px; } #updateContent::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.1); border-radius: 10px; }</style>`;
            document.body.appendChild(dialog);
            document.getElementById('updateCancel').addEventListener('click', () => this.handleCancelUpdate());
        }

        handleCancelUpdate() {
            const el = document.getElementById('updateOverlay');
            if (el) el.style.display = 'none';
            if (typeof webapp !== 'undefined') webapp.toast('已延迟更新');
            this.state.lastCheckTimestamp = Date.now();
        }

        _showUpdateUI(data) {
            this.state.latestUpdateData = data;
            const overlay = document.getElementById('updateOverlay');
            const content = document.getElementById('updateContent');

            content.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(0,0,0,0.03); padding: 12px 15px; border-radius: 10px; margin-bottom: 15px;">
                    <div style="text-align: center;">
                        <div style="font-size: 11px; color: #888;">当前版本</div>
                        <div style="font-size: 14px; color: #333; font-weight: bold;">v${escapeHTML(this.state.currentVersion)}</div>
                    </div>
                    <div style="color: #666;">➔</div>
                    <div style="text-align: center;">
                        <div style="font-size: 11px; color: #888;">最新版本</div>
                        <div style="font-size: 14px; color: #29c961; font-weight: bold;">v${escapeHTML(data.versionName)}</div>
                    </div>
                </div>
                <div style="font-size: 14px; line-height: 1.6; color: #444; white-space: pre-wrap;">${safeLines(data.description || '')}</div>
                ${data.forceUpdate ? `<div style="margin-top: 15px; padding: 10px; background: #fff1f0; border-radius: 8px; color: #ff4d4f; font-size: 12px;">本次为强制更新</div>` : ''}
            `;

            if (data.forceUpdate) {
                const cancelBtn = document.getElementById('updateCancel');
                if (cancelBtn) cancelBtn.style.display = 'none';
            } else {
                document.getElementById('updateCancel').style.display = 'block';
            }

            const confirmBtn = document.getElementById('updateConfirm');
            confirmBtn.onclick = () => {
                this._checkPermissionAndDownload(data.downloadUrl);
                overlay.style.display = 'none';
            };
            overlay.style.display = 'flex';
        }

        async _checkPermissionAndDownload(url) {
            try {
                if (typeof webapp !== 'undefined') {
                    if (!webapp.bestow()) {
                        webapp.rights();
                    }
                    webapp.browse(url);
                } else {
                    window.open(url, '_blank');
                }
            } catch (error) {
                console.error('下载失败:', error);
            }
        }

        openSponsor() {
            const oldPopup = document.getElementById('SponsorPopup');
            if (oldPopup) oldPopup.remove();

            const popup = document.createElement('div');
            popup.id = 'SponsorPopup';
            popup.style.display = 'none';
            popup.style.opacity = '0';
            popup.className = 'popup-container';

            popup.innerHTML = `
        <style>
            .popup-container { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 9999; background: rgba(0, 0, 0, 0.6); backdrop-filter: blur(5px); display: flex; justify-content: center; align-items: center; transition: all 0.3s; }
            .content-container { background: rgba(30, 30, 30, 0.95); width: 85%; max-width: 400px; border-radius: 20px; padding: 30px 20px; display: flex; flex-direction: column; align-items: center; box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5); transform: scale(0.95); transition: all 0.3s; border: 1px solid rgba(255,255,255,0.1); }
            .popup-container[style*="opacity: 1"] .content-container { transform: scale(1); }
            .logo-box-animated { width: 70px; height: 70px; border-radius: 18px; overflow: hidden; margin-bottom: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.3); animation: floatLogo 3s ease-in-out infinite; }
            @keyframes floatLogo { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }
            .popup-title { font-size: 20px; color: #fff; font-weight: 700; margin: 0; }
            .poem-text { text-align: center; color: rgba(255,255,255,0.5); font-size: 13px; font-style: italic; margin-bottom: 15px; font-family: serif; }
            .Sponsor-list-item { background: rgba(255, 255, 255, 0.05); border-radius: 12px; padding: 12px 15px; width: 100%; box-sizing: border-box; display: flex; align-items: center; cursor: pointer; transition: 0.2s; margin-bottom: 8px; }
            .Sponsor-list-item:active { transform: scale(0.98); background: rgba(255,255,255,0.1); }
            .donate-section { margin-top: 15px; padding-top: 20px; border-top: 1px dashed rgba(255,255,255,0.1); width: 100%; text-align: center; }
            .qr-container { display: flex; justify-content: center; gap: 20px; margin-top: 15px; }
            .qr-img-wrapper { width: 90px; height: 90px; background: #fff; padding: 5px; border-radius: 10px; cursor: pointer; transition: 0.2s; }
            .qr-img-wrapper:active { opacity: 0.8; transform: scale(0.95); }
            .qr-img { width: 100%; height: 100%; object-fit: contain; }
            .qr-label { font-size: 12px; font-weight: bold; margin-top: 5px; }
        </style>
        
        <div class="content-container">
            <div class="Sponsor-logo-section" style="display:flex;flex-direction:column;align-items:center;">
                <div class="logo-box-animated">
                    <img src="https://q1.qlogo.cn/g?b=qq&nk=180782569&s=640" alt="Logo" style="width: 100%; height: 100%; object-fit: cover;">
                </div>
                <h2 style="margin-bottom:5px;color:white">hillmis✦山雾</h2>
            </div>

            <div class="text-container" style="width:100%;">
                <div class="poem-text">${this.state.hitokoto}</div>
                
                <div class="Sponsor-list-group">
                    <div class="Sponsor-list-item">
                        <div style="color:#eee;">
                            <div style="font-size:14px;font-weight:500;"></div>
                            <div style="font-size:11px;color:rgba(255,255,255,0.5);margin-top:2px;">
                                我是一个前端和UI设计爱好者，用AI编程工具实现心中想法，为大家带来免费好用的软件，希望在实现自己灵光一现的奇思妙想的同时可以给您带来方便和乐趣。
                            </div>
                        </div>
                    </div>
                    <div class="Sponsor-list-item" id="visitAuthorBtn" style="justify-content:center;">
                        <div style="font-size:12px;color:rgba(255,255,255,0.7);">点击发现更多奇思妙想</div>
                    </div>
                </div>

                <div class="donate-section">
                    <div style="color:#ccc;font-size:13px;font-weight:500;">☕ 请开发者喝杯咖啡支持一下</div>
                    
                    <div class="qr-container">
                        <div style="display:flex;flex-direction:column;align-items:center;">
                            <div class="qr-img-wrapper" id="alipayQr"><img src="${CONFIG.ASSETS.ALIPAY}" class="qr-img"></div>
                            <div class="qr-label" style="color: #1677ff;">支付宝</div>
                        </div>
                        
                        <div style="display:flex;flex-direction:column;align-items:center;">
                            <div class="qr-img-wrapper" id="wechatQr"><img src="${CONFIG.ASSETS.WECHAT}" class="qr-img"></div>
                            <div class="qr-label" style="color: #07c160;">微信</div>
                        </div>
                    </div>
                    
                    <p style="text-align:center;color:rgba(255,255,255,0.3);font-size:11px;margin-top:15px;">点击图片保存赞赏码 · 感谢您的支持</p>
                </div>
            </div>
        </div>`;

            document.body.appendChild(popup);

            popup.addEventListener('click', (e) => {
                if (e.target === popup) this._closeSponsorPopup(popup);
            });

            document.getElementById('visitAuthorBtn').addEventListener('click', () => {
                const url = 'https://link3.cc/liu13';
                if (typeof webapp !== 'undefined') webapp.browse(url);
                else window.open(url, '_blank');
                this._closeSponsorPopup(popup);
            });

            document.getElementById('alipayQr').addEventListener('click', () => this.handleImageClick(2, CONFIG.ASSETS.ALIPAY));
            document.getElementById('wechatQr').addEventListener('click', () => this.handleImageClick(1, CONFIG.ASSETS.WECHAT));

            requestAnimationFrame(() => {
                popup.style.display = 'flex';
                requestAnimationFrame(() => {
                    popup.style.opacity = '1';
                });
            });
        }

        _closeSponsorPopup(popup) {
            popup.style.opacity = '0';
            setTimeout(() => {
                if (popup.parentNode) popup.parentNode.removeChild(popup);
            }, 300);
        }

        // --- 公告模块 ---
        async _fetchRemoteAnnouncementData() {
            const hosts = Array.isArray(CONFIG.ANNOUNCEMENT.HOSTS) && CONFIG.ANNOUNCEMENT.HOSTS.length > 0
                ? CONFIG.ANNOUNCEMENT.HOSTS
                : [String(CONFIG.UPDATE.HOSTS[0] || '').replace(/\/$/, '')];
            return this._fetchJsonFromHosts({
                hosts,
                names: ['dxxannouncements'],
                logPrefix: 'Announcement',
                failMessage: '无法获取公告数据',
                validate: (data) => Array.isArray(data) ? true : '公告数据格式无效，应为数组'
            });
        }

        async getAnnouncements() {
            try {
                // 检查缓存
                const now = Date.now();
                if (this.state.announcements.length > 0 &&
                    (now - this.state.lastAnnouncementCheck) < CONFIG.ANNOUNCEMENT.CACHE_DURATION) {
                    return this.state.announcements;
                }

                const data = await this._fetchRemoteAnnouncementData();
                this.state.announcements = data;
                this.state.lastAnnouncementCheck = now;
                return data;
            } catch (error) {
                console.error('获取公告失败:', error);
                // 返回缓存数据或空数组
                return this.state.announcements || [];
            }
        }

        async checkPopupAnnouncements() {
            try {
                const announcements = await this.getAnnouncements();
                const popupAnnouncements = announcements.filter(ann =>
                    ann.popup && !this.state.shownAnnouncementIds.has(ann.id)
                );

                if (popupAnnouncements.length > 0) {
                    // 显示最新的弹窗公告
                    const latestPopup = popupAnnouncements[popupAnnouncements.length - 1];
                    this.openAnnouncementPopup(latestPopup);
                }
            } catch (error) {
                console.error('检查弹窗公告失败:', error);
            }
        }

        openAnnouncementPopup(announcement) {
            if (!announcement) return;

            const oldPopup = document.getElementById('AnnouncementPopup');
            if (oldPopup) oldPopup.remove();

            const popup = document.createElement('div');
            popup.id = 'AnnouncementPopup';
            popup.style.display = 'none';
            popup.style.opacity = '0';
            popup.className = 'popup-container';
            popup.dataset.announcementId = String(announcement.id || '');

            popup.innerHTML = `
        <style>
            .popup-container { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 10000; background: rgba(0, 0, 0, 0.6); backdrop-filter: blur(5px); display: flex; justify-content: center; align-items: center; transition: all 0.3s; }
            .content-container { background: rgba(30, 30, 30, 0.95); width: 85%; max-width: 400px; border-radius: 20px; padding: 30px 20px; display: flex; flex-direction: column; align-items: center; box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5); transform: scale(0.95); transition: all 0.3s; border: 1px solid rgba(255,255,255,0.1); }
            .popup-container[style*="opacity: 1"] .content-container { transform: scale(1); }
            .logo-box-animated { width: 70px; height: 70px; border-radius: 18px; overflow: hidden; margin-bottom: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.3); animation: floatLogo 3s ease-in-out infinite; }
            @keyframes floatLogo { 0%, 100% { transform: translateY(0); } 50% { transform: scale(1.05); } }
            .announcement-title { font-size: 18px; color: #fff; font-weight: 700; margin: 0 0 10px 0; text-align: center; }
            .announcement-content { font-size: 14px; color: rgba(255,255,255,0.9); line-height: 1.6; margin-bottom: 15px; white-space: pre-wrap; text-align: center; }
            .announcement-meta { font-size: 12px; color: rgba(255,255,255,0.5); text-align: center; margin-bottom: 20px; }
            .announcement-actions { display: flex; gap: 10px; width: 100%; justify-content: center; }
            .btn { padding: 12px 24px; border: none; border-radius: 12px; font-weight: 600; cursor: pointer; transition: 0.2s; }
            .btn-primary { background: #29c961; color: white; }
            .btn-primary:active { transform: scale(0.95); background: #22a350; }
            .btn-secondary { background: rgba(255,255,255,0.1); color: rgba(255,255,255,0.7); }
            .btn-secondary:active { transform: scale(0.95); background: rgba(255,255,255,0.2); }
        </style>
        
        <div class="content-container">
           

            <h2 class="announcement-title">📢 系统通知</h2>
            
            <div class="announcement-content">${safeLines(announcement.content || '')}</div>
            
            <div class="announcement-meta">
                <div>发布时间: ${announcement.publishTime}</div>
                <div>发布者: ${escapeHTML(announcement.author || '系统')}</div>
            </div>

            <div class="announcement-actions">
                <button class="btn btn-secondary" id="announcementClose">知道了</button>
            </div>
        </div>`;

            document.body.appendChild(popup);

            this._setAnnouncementBackHandler('popup');

            // 显示弹窗
            setTimeout(() => {
                popup.style.display = 'flex';
                setTimeout(() => popup.style.opacity = '1', 10);
            }, 100);

            // 绑定事件
            popup.addEventListener('click', (e) => {
                if (e.target === popup) this._closeAnnouncementPopup(popup, announcement.id);
            });

            document.getElementById('announcementClose').addEventListener('click', () => {
                this._closeAnnouncementPopup(popup, announcement.id);
            });
        }

        _closeAnnouncementPopup(popup, announcementId) {
            popup.style.opacity = '0';
            setTimeout(() => {
                if (popup.parentNode) popup.parentNode.removeChild(popup);
            }, 300);

            // 标记为已显示
            if (announcementId) {
                this.state.shownAnnouncementIds.add(announcementId);
                localStorage.setItem('shownAnnouncementIds', JSON.stringify([...this.state.shownAnnouncementIds]));

                // 如果公告列表页面存在，刷新列表以显示已读状态
                const listPopup = document.getElementById('AnnouncementListPopup');
                if (listPopup) {
                    // 找到对应的公告项并标记为已读
                    const announcementItems = listPopup.querySelectorAll('.announcement-item');
                    announcementItems.forEach(item => {
                        const index = parseInt(item.getAttribute('data-index'));
                        // 这里需要重新获取公告数据来确定哪个是对应的公告项
                        // 由于我们无法直接从DOM获取公告ID，我们使用一个简单的方法：刷新整个列表
                    });

                    // 刷新公告列表以更新已读状态
                    this.getAnnouncements().then(announcements => {
                        this._refreshAnnouncementList(announcements);
                    });
                }
            }

            // 恢复返回键行为
            if (document.getElementById('AnnouncementListPopup')) {
                this._setAnnouncementBackHandler('list');
            } else {
                this._setAnnouncementBackHandler('clear');
            }
        }

        // 打开公告列表页面
        async openAnnouncementList() {
            try {
                const announcements = await this.getAnnouncements();
                this._showAnnouncementList(announcements);
            } catch (error) {
                console.error('打开公告列表失败:', error);
                if (typeof webapp !== 'undefined') webapp.toast('获取公告失败');
            }
        }

        _renderAnnouncementItem(announcement, index) {
            const publishDate = new Date(announcement.publishTime).toLocaleDateString();
            const isRead = this.state.shownAnnouncementIds.has(announcement.id);
            return `
                <div class="announcement-item ${isRead ? 'read' : 'unread'}" data-index="${index}">
                    <div class="announcement-item-header">
                        <div class="announcement-item-title">${escapeHTML(announcement.title || '系统公告')}</div>
                        <div class="announcement-item-date">${publishDate}</div>
                    </div>
                    <div class="announcement-item-content">${safeLines(announcement.content || '')}</div>
                    <div class="announcement-item-meta">
                        <span class="announcement-item-author">发布者: ${escapeHTML(announcement.author || '系统')}</span>
                        ${isRead ? '<span class="announcement-item-read-status">已读</span>' : '<span class="announcement-item-read-status unread">未读</span>'}
                    </div>
                </div>
            `;
        }

        _renderAnnouncementListBody(announcements) {
            if (!announcements || announcements.length === 0) {
                return `
                    <div class="announcement-empty">
                        <div class="announcement-empty-icon">📭</div>
                        <div class="announcement-empty-text">暂无公告</div>
                    </div>
                `;
            }
            return announcements.map((announcement, index) => this._renderAnnouncementItem(announcement, index)).join('');
        }

        _bindAnnouncementItemClicks(root, announcements) {
            if (!root || !announcements || announcements.length === 0) return;
            root.querySelectorAll('.announcement-item').forEach(item => {
                item.addEventListener('click', () => {
                    const index = parseInt(item.getAttribute('data-index'));
                    const announcement = announcements[index];
                    this.openAnnouncementPopup(announcement);
                });
            });
        }

        // 显示公告列表
        _showAnnouncementList(announcements) {
            const oldListPopup = document.getElementById('AnnouncementListPopup');
            if (oldListPopup) oldListPopup.remove();

            const listPopup = document.createElement('div');
            listPopup.id = 'AnnouncementListPopup';
            listPopup.style.display = 'none';
            listPopup.style.opacity = '0';
            listPopup.className = 'announcement-list-container';
            listPopup.innerHTML = `
                <div class="announcement-list-content">
                    <div class="announcement-list-header">
                        <h2 class="announcement-list-title">📢 系统通知</h2>
                        <button class="announcement-list-close" id="announcementListClose">×</button>
                    </div>
                    <div class="announcement-list-body">
                        ${this._renderAnnouncementListBody(announcements)}
                    </div>
                </div>
            `;

            document.body.appendChild(listPopup);
            this._setAnnouncementBackHandler('list');

            setTimeout(() => {
                listPopup.style.display = 'flex';
                setTimeout(() => listPopup.style.opacity = '1', 10);
            }, 100);

            document.getElementById('announcementListClose').addEventListener('click', () => {
                this._closeAnnouncementList(listPopup);
            });
            listPopup.addEventListener('click', (e) => {
                if (e.target === listPopup) this._closeAnnouncementList(listPopup);
            });
            this._bindAnnouncementItemClicks(listPopup, announcements);
        }

        // 刷新公告列表
        _refreshAnnouncementList(announcements) {
            const listPopup = document.getElementById('AnnouncementListPopup');
            if (!listPopup) return;
            const listBody = listPopup.querySelector('.announcement-list-body');
            if (!listBody) return;
            listBody.innerHTML = this._renderAnnouncementListBody(announcements);
            this._bindAnnouncementItemClicks(listBody, announcements);
        }

        // 关闭公告列表
        _closeAnnouncementList(listPopup) {
            listPopup.style.opacity = '0';
            setTimeout(() => {
                if (listPopup.parentNode) listPopup.parentNode.removeChild(listPopup);
            }, 300);

            this._setAnnouncementBackHandler('clear');
        }

        closeAnnouncementList() {
            const listPopup = document.getElementById('AnnouncementListPopup');
            if (listPopup) this._closeAnnouncementList(listPopup);
        }

        closeAnnouncementPopup() {
            const popup = document.getElementById('AnnouncementPopup');
            if (!popup) return;
            const id = popup.dataset ? popup.dataset.announcementId : '';
            this._closeAnnouncementPopup(popup, id || null);
        }

        _setAnnouncementBackHandler(mode) {
            if (typeof webapp === 'undefined' || typeof webapp.自定义返回键 !== 'function') return;
            if (mode === 'popup') {
                webapp.自定义返回键('if(window.DxxSystem&&DxxSystem.closeAnnouncementPopup){DxxSystem.closeAnnouncementPopup();}');
                return;
            }
            if (mode === 'list') {
                webapp.自定义返回键('if(window.DxxSystem&&DxxSystem.closeAnnouncementList){DxxSystem.closeAnnouncementList();}');
                return;
            }
            webapp.自定义返回键('');
        }

        async handleImageClick(elementType, imageUrl) {
            if (typeof webapp !== 'undefined') webapp.toast('正在保存图片...');
            try {
                const response = await fetch(imageUrl);
                const blob = await response.blob();
                const blobUrl = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = blobUrl;
                link.download = `donate_${Date.now()}.png`;
                document.body.appendChild(link);
                link.click();
                setTimeout(() => {
                    document.body.removeChild(link);
                    URL.revokeObjectURL(blobUrl);
                    if (typeof webapp !== 'undefined') {
                        if (imageUrl.includes('33a0542b1403bb94') || imageUrl.includes('wechat')) webapp.启动指定应用('com.tencent.mm');
                        else if (imageUrl.includes('1565fff5085e314b') || imageUrl.includes('alipay')) webapp.启动指定应用('com.eg.android.AlipayGphone');
                    }
                }, 2000);
            } catch (e) {
                if (typeof webapp !== 'undefined') webapp.toast('保存失败');
            }
        }
    }
    const appSystem = new SystemApp();
    window.DxxSystem = {
        checkUpdate: () => appSystem.checkUpdate(),
        showUpdateLog: () => appSystem.showUpdateLog(),
        openSponsor: () => appSystem.openSponsor(),
        getVersion: () => appSystem.state.currentVersion,
        getHitokoto: () => appSystem.state.hitokoto,
        getUpdateLog: () => appSystem.getUpdateLog(),
        verify: () => appSystem._verifyIntegrity(),
        // 公告相关接口
        getAnnouncements: () => appSystem.getAnnouncements(),
        openAnnouncementPopup: (announcement) => appSystem.openAnnouncementPopup(announcement),
        checkPopupAnnouncements: () => appSystem.checkPopupAnnouncements(),
        openAnnouncementList: () => appSystem.openAnnouncementList(),
        closeAnnouncementList: () => appSystem.closeAnnouncementList(),
        closeAnnouncementPopup: () => appSystem.closeAnnouncementPopup()
    };

})(window, document);
